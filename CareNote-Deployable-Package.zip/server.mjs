import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { DBService } from './db.mjs';
import { CareAgent } from './careAgent.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Robust process error handling to prevent server crashes
process.on('uncaughtException', (err) => {
  console.error('[UNCAUGHT EXCEPTION]', err);
});
process.on('unhandledRejection', (reason) => {
  console.error('[UNHANDLED REJECTION]', reason);
});

const PORT = process.env.PORT || 3000;
const ALT_PORT = 4002;
const PUBLIC_DIR = __dirname;
const REMOTE_STATIC_ORIGIN = 'https://app.oasisnotes.com';
const REMOTE_API_ORIGIN = 'https://api.oasisnotes.com';

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.mjs': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.otf': 'font/otf',
  '.eot': 'application/vnd.ms-fontobject',
  '.webp': 'image/webp',
};

// All permissions string for complete feature access
const ALL_PERMISSIONS = "PI:offl:app:f23:lrc1031a:jd:rc:tc:binf:fw4:aps:fw9:i9:onsfov:st:etracking:ic:asam:fprt:et:tr:staffsch:timesheet:perf:iass:nass:tp:fs:sp:ri:pn:discharge:sn:asamc:dp:ron:bhpn:spn:tn:aschedule:cn:ml:ari:rt:mppr:ft:dtf:cft:cf:df:uf:rv:em:mars:mr:ms:rmt:mc:icm:prn:ba:va:ma:ahis:co:inr:reassessment";

// In-Memory Fallback & Pricing configuration
const PRICING_PLANS = [
  {
    _id: "plan_basic",
    name: "Basic",
    perUser: 49,
    interval: "month",
    description: "Essential EHR and resident tracking for small care homes.",
    details: [
      "<ul><li>Core Electronic Health Records (EHR)</li><li>Patient Demographics & Face Sheets</li><li>Vitals Logging & History Tracking</li><li>Shift Notes & Logs</li><li>Standard Attendance & Calendar</li><li>Email Support</li></ul>"
    ]
  },
  {
    _id: "plan_growth",
    name: "Growth",
    perUser: 99,
    interval: "month",
    description: "Complete clinical suite for behavioral health and residential care facilities.",
    details: [
      "<ul><li>Everything in Basic plan</li><li>Full Clinical Progress Notes Library</li><li>Therapy Progress Tracking</li><li>Medication Administration Records (MARS) & Counts</li><li>Behavioral Health Treatment Plans & ASAM</li><li>Discharge Planning & Re-Certification of Need</li><li>Audit Trail & Priority Support</li></ul>"
    ]
  },
  {
    _id: "plan_enterprise",
    name: "Enterprise",
    perUser: 199,
    interval: "month",
    description: "Advanced multi-facility compliance, reporting, and dedicated SLA.",
    details: [
      "<ul><li>Everything in Growth plan</li><li>Multi-Facility Management & Central Billing</li><li>Custom Clinical Documentation Templates</li><li>HIPAA Compliance Officer Audit Logs</li><li>Unlimited Document & Attachment Storage</li><li>Dedicated Account Manager & 24/7 Phone Support</li></ul>"
    ]
  }
];

// Activity logs memory store
let ACTIVITY_LOGS = [
  {
    _id: "log_001",
    user: "Sheku Swaray",
    action: "Reviewed Resident Chart & Vitals",
    resident: "Sarah Connor (RES-1001)",
    formType: "Resident Chart",
    timestamp: new Date().toISOString()
  },
  {
    _id: "log_002",
    user: "Charles Smith",
    action: "Recorded Morning Vitals & MARs",
    resident: "Michael Scott (RES-1002)",
    formType: "Vital Signs",
    timestamp: new Date(Date.now() - 3600000 * 2).toISOString()
  }
];

// Ensure SQLite Database is initialized and seeded
DBService.seedIfEmpty();
console.log(`[SQLite] Database initialized at: ${path.join(PUBLIC_DIR, 'data', 'oasis.db')}`);

function setCorsHeaders(req, res) {
  const origin = (req && req.headers && req.headers.origin) ? req.headers.origin : '*';
  res.setHeader('Access-Control-Allow-Origin', origin);
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
  const reqHeaders = req && req.headers && req.headers['access-control-request-headers'];
  res.setHeader('Access-Control-Allow-Headers', reqHeaders || 'Content-Type, Authorization, timezone, Organization, organization, X-Requested-With, Accept, Origin, Cache-Control, Pragma');
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Max-Age', '86400');
  
  // Production Security Protections
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
}

function findLocalFile(pathname) {
  let safePath = path.normalize(path.join(PUBLIC_DIR, pathname));
  if (!safePath.toLowerCase().startsWith(PUBLIC_DIR.toLowerCase())) return null;

  if (fs.existsSync(safePath) && fs.statSync(safePath).isFile()) {
    return safePath;
  }

  const baseName = path.basename(pathname);
  for (const dir of ['assets', 'js', 'css', 'images', 'fonts']) {
    if (pathname.includes('/' + dir + '/')) {
      const sub = pathname.substring(pathname.indexOf('/' + dir + '/'));
      const directCandidate = path.normalize(path.join(PUBLIC_DIR, sub));
      if (fs.existsSync(directCandidate) && fs.statSync(directCandidate).isFile()) {
        return directCandidate;
      }
      const candidate = path.join(PUBLIC_DIR, dir, baseName);
      if (fs.existsSync(candidate) && fs.statSync(candidate).isFile()) {
        return candidate;
      }
    }
  }

  // Check images folder for root-level images like logo.png or fav.png
  if (pathname === '/logo.png' || pathname === '/favicon.ico' || pathname.endsWith('.png') || pathname.endsWith('.ico')) {
    const imgCandidate = path.join(PUBLIC_DIR, 'images', baseName);
    if (fs.existsSync(imgCandidate) && fs.statSync(imgCandidate).isFile()) {
      return imgCandidate;
    }
    const rootCandidate = path.join(PUBLIC_DIR, baseName);
    if (fs.existsSync(rootCandidate) && fs.statSync(rootCandidate).isFile()) {
      return rootCandidate;
    }
  }

  return null;
}

function serveLocalFile(filePath, req, res) {
  const ext = path.extname(filePath).toLowerCase();
  const contentType = MIME_TYPES[ext] || 'application/octet-stream';

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.statusCode = 500;
      res.end('Read Error');
      return;
    }
    res.statusCode = 200;
    res.setHeader('Content-Type', contentType);
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    setCorsHeaders(req, res);
    res.end(data);
  });
}

async function fetchAndCacheRemoteAsset(pathname, req, res) {
  const baseName = path.basename(pathname);
  const candidateUrls = [
    `${REMOTE_STATIC_ORIGIN}/assets/${baseName}`,
    `${REMOTE_STATIC_ORIGIN}${pathname}`
  ];

  for (const remoteUrl of candidateUrls) {
    try {
      const resp = await fetch(remoteUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
          'Referer': `${REMOTE_STATIC_ORIGIN}/`,
        }
      });

      if (resp.ok) {
        const contentType = resp.headers.get('content-type') || MIME_TYPES[path.extname(pathname)] || 'application/octet-stream';
        const buffer = Buffer.from(await resp.arrayBuffer());

        try {
          const cacheDir = path.join(PUBLIC_DIR, 'assets');
          fs.mkdirSync(cacheDir, { recursive: true });
          fs.writeFileSync(path.join(cacheDir, baseName), buffer);

          const ext = path.extname(baseName).toLowerCase();
          if (ext === '.js') {
            fs.mkdirSync(path.join(PUBLIC_DIR, 'js'), { recursive: true });
            fs.writeFileSync(path.join(PUBLIC_DIR, 'js', baseName), buffer);
          } else if (ext === '.css') {
            fs.mkdirSync(path.join(PUBLIC_DIR, 'css'), { recursive: true });
            fs.writeFileSync(path.join(PUBLIC_DIR, 'css', baseName), buffer);
          }
        } catch (saveErr) {
          console.error(`Failed to cache asset ${baseName}:`, saveErr.message);
        }

        res.statusCode = 200;
        res.setHeader('Content-Type', contentType);
        setCorsHeaders(req, res);
        res.end(buffer);
        return;
      }
    } catch (err) {
      console.error(`Error requesting remote asset ${remoteUrl}:`, err.message);
    }
  }

  res.statusCode = 404;
  res.setHeader('Content-Type', 'text/plain');
  res.end('Asset Not Found');
}

async function handleApiRequest(req, res, parsedUrl) {
  setCorsHeaders(req, res);
  if (req.method === 'OPTIONS') {
    res.statusCode = 204;
    return res.end();
  }

  let body = {};
  if (['POST', 'PUT', 'PATCH'].includes(req.method)) {
    try {
      const bodyChunks = [];
      for await (const chunk of req) {
        bodyChunks.push(chunk);
      }
      const rawBody = Buffer.concat(bodyChunks).toString('utf8');
      if (rawBody) {
        body = JSON.parse(rawBody);
      }
    } catch (e) {
      // Non-JSON or empty body
    }
  }

  const pathname = parsedUrl.pathname;
  const searchParams = parsedUrl.searchParams;
  console.log(`[API REQUEST] ${req.method} ${pathname} | Query: ${searchParams.toString()}`);

  // Helper response functions
  const json = (data, status = 200) => {
    res.statusCode = status;
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(data));
  };

  const error = (message, status = 400) => {
    res.statusCode = status;
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify({ success: false, message }));
  };

  // =========================================================================
  // CARE AGENTIC AI ASSISTANT ENDPOINT
  // =========================================================================
  if (pathname === '/api/v1/care/chat' || pathname === '/api/care/chat' || pathname.startsWith('/api/v1/care')) {
    const query = body.message || body.query || searchParams.get('q') || '';
    const result = await CareAgent.processMessage(query, body.context || {});
    return json(result);
  }

  // =========================================================================
  // CORE CLINICAL & SHIFT PROGRESS NOTE ENDPOINTS (PRIORITIZED FIRST)
  // =========================================================================

  // 1. Shift Progress Notes: Single Note by ID (Reopen / View / Edit)
  if (pathname.includes('/getProgressNoteById') || ((pathname.includes('/progress-note/') || pathname.includes('/progressNote/')) && req.method === 'GET')) {
    const id = pathname.split('/').pop();
    const note = DBService.getNoteById(id);
    if (!note) {
      return error("Shift Progress Note not found", 404);
    }
    return json({
      success: true,
      data: note
    });
  }

  // 2. Shift Progress Notes: Update Note by ID
  if ((pathname.includes('/editProgressNoteById') || pathname.includes('/progress-note/') || pathname.includes('/progressNote/')) && req.method === 'PUT') {
    const id = pathname.split('/').pop();
    if (!id) {
      return error("Missing note ID for update", 400);
    }
    const updatedNote = DBService.updateNote(id, {
      ...body,
      patientId: body.patientId,
      noteSummary: body.noteSummary || body.content,
      shiftTiming: body.shiftTiming || body.shift,
      status: body.saveAsDraft ? "Draft" : "Completed",
      date: body.date || body.noteDate
    });
    if (!updatedNote) {
      return error("Note not found or could not be updated", 404);
    }
    return json({
      success: true,
      message: body.saveAsDraft ? "Shift Progress Note draft updated!" : "Shift Progress Note updated successfully!",
      data: updatedNote
    });
  }

  // 3. Shift Progress Notes: Delete Note by ID
  if ((pathname.includes('/deleteProgressNote') || pathname.includes('/progress-note/') || pathname.includes('/progressNote/')) && req.method === 'DELETE') {
    const id = pathname.split('/').pop();
    const ok = DBService.deleteNote(id);
    if (!ok) {
      return error("Could not delete note", 404);
    }
    return json({
      success: true,
      message: "Shift Progress Note deleted successfully!"
    });
  }

  // 4. Shift Progress Notes: Create Note
  if ((pathname.includes('/createProgressNote') || pathname.endsWith('/progress-note') || pathname.endsWith('/progressNote')) && req.method === 'POST') {
    if (!body.patientId) {
      const fallbackPatient = DBService.getAllPatients().docs[0];
      if (fallbackPatient) {
        body.patientId = fallbackPatient._id;
        body.residentName = body.residentName || fallbackPatient.name || `${fallbackPatient.firstName || ''} ${fallbackPatient.lastName || ''}`.trim();
      }
    }
    const newNote = DBService.addNote({
      ...body,
      patientId: body.patientId || DBService.getAllPatients().docs[0]?._id,
      title: body.shiftBeginning ? `Shift Progress Note (${body.shiftBeginning} - ${body.shiftEnd || ''})` : (body.title || "Daily Shift Progress Note"),
      type: body.noteType || body.type || "progressNote",
      author: DBService.getCurrentUser()?.name || "Charles Smith, BHT",
      content: body.noteSummary || body.content || "Shift Progress Note recorded.",
      shift: body.shiftTiming || body.shift || "Day Shift (07:00 - 15:00)",
      shiftTiming: body.shiftTiming || body.shift || "Day Shift (07:00 - 15:00)",
      status: body.saveAsDraft ? "Draft" : "Completed",
      date: body.date || body.noteDate || new Date().toISOString().split('T')[0],
      notesData: body
    });
    return json({
      success: true,
      message: body.saveAsDraft ? "Shift Progress Note saved as draft!" : "Shift Progress Note submitted successfully!",
      data: newNote
    });
  }

  // 5. Shift Progress Notes: List Notes with Pagination & Clean Empty State
  if ((pathname.includes('/progress-note') || pathname.includes('/progressNote')) && req.method === 'GET') {
    const patientId = searchParams.get('patientId');
    const notes = DBService.getNotes(patientId, 'progressNote');
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.max(1, parseInt(searchParams.get('limit') || '10', 10));
    const totalDocs = notes.length;
    const totalPages = Math.max(1, Math.ceil(totalDocs / limit));
    const start = (page - 1) * limit;
    const paginatedNotes = notes.slice(start, start + limit);

    return json({
      success: true,
      data: {
        docs: paginatedNotes,
        totalDocs: totalDocs,
        limit: limit,
        page: page,
        totalPages: totalPages
      }
    });
  }

  // 5b. Custom Clinical Forms & Templates API
  if (pathname.includes('/custom-forms') && req.method === 'GET') {
    const forms = DBService.getCustomForms();
    return json({
      success: true,
      data: forms
    });
  }

  if (pathname.includes('/custom-forms') && ['POST', 'PUT'].includes(req.method)) {
    const saved = DBService.upsertCustomForm(body);
    return json({
      success: true,
      message: "Custom clinical form saved successfully!",
      data: saved
    });
  }

  if (pathname.includes('/custom-forms') && req.method === 'DELETE') {
    const id = pathname.split('/').pop();
    DBService.deleteCustomForm(id);
    return json({
      success: true,
      message: "Custom form deleted successfully."
    });
  }

  if (pathname.includes('/clinical-templates') && req.method === 'GET') {
    const templates = DBService.getClinicalTemplates();
    return json({
      success: true,
      data: templates
    });
  }

  if (pathname.includes('/form-submissions') && req.method === 'POST') {
    const sub = DBService.addFormSubmission(body);
    return json({
      success: true,
      message: "Form response submitted successfully!",
      data: sub
    });
  }

  if (pathname.includes('/form-submissions') && req.method === 'GET') {
    const formId = searchParams.get('formId');
    const subs = DBService.getFormSubmissions(formId);
    return json({
      success: true,
      data: subs
    });
  }

  // 6. Shifts for Facility
  if ((pathname.startsWith('/api/v1/Shift') || pathname.startsWith('/api/v1/shift')) && req.method === 'GET') {
    const facilityId = pathname.split('/').pop() || searchParams.get('facilityId');
    const cleanId = (facilityId && !facilityId.toLowerCase().includes('shift')) ? facilityId : null;
    const shifts = DBService.getShifts(cleanId);
    return json({
      success: true,
      data: shifts
    });
  }

  // 7. Facilities List
  if (pathname.includes('/list-facility') || pathname.includes('/facility/list')) {
    return json({
      success: true,
      data: DBService.getAllFacilities()
    });
  }

  // 8. Signers & Employees List
  if (pathname.includes('/get-employee') || pathname.includes('/getEmployee')) {
    const users = DBService.getAllUsers();
    return json({
      success: true,
      data: users
    });
  }

  // 9. Patients & Residents List
  if (pathname.includes('/get-assigned-residents') || pathname.includes('/assignedResidents') || pathname.includes('/patient/list') || pathname.endsWith('/employee/getPatient')) {
    const query = searchParams.get('searchQuery') || searchParams.get('search') || '';
    const page = parseInt(searchParams.get('page') || '1', 10);
    const limit = parseInt(searchParams.get('limit') || '50', 10);
    const result = DBService.getAllPatients(query, limit, page);
    return json({
      success: true,
      data: result
    });
  }

  // 10. Single Patient / Resident by ID
  if (pathname.includes('/search/patient') || pathname.includes('/patient/getPatientById') || pathname.includes('/employee/getPatientById')) {
    const id = pathname.split('/').pop();
    const patient = DBService.getPatientById(id) || DBService.getAllPatients().docs[0];
    if (!patient) {
      return error("Resident not found", 404);
    }
    return json({
      success: true,
      data: patient
    });
  }

  // 1. Create Account / Register / Sign Up
  if (pathname.endsWith('/signup') || pathname.endsWith('/register') || pathname.endsWith('/createUser') || pathname.endsWith('/admin/addUser')) {
    const email = (body.email || `user_${Date.now()}@carenote.com`).toLowerCase().trim();
    const role = body.userType || (email.includes('employee') ? 'Employee' : email.includes('patient') ? 'Patient' : 'Admin');
    const fullName = body.name || [body.firstName, body.lastName].filter(Boolean).join(' ') || 'New User';
    const planName = body.tier || body.selectedPlan || body.plan || "Growth";

    const user = DBService.upsertUser({
      name: fullName,
      firstName: body.firstName || fullName.split(' ')[0] || 'User',
      lastName: body.lastName || fullName.split(' ').slice(1).join(' ') || '',
      email: email,
      password: body.password || 'password123',
      userType: role,
      accountType: 'adminstrator',
      companyName: body.companyName || body.facilityName || "CareNote Healthcare System",
      position: body.position || (role === 'Admin' ? 'Administrator' : 'Staff Clinician'),
      phone: body.phone || "(555) 234-5678",
      tier: planName
    });

    if (body.cardNumber || body.payment) {
      const cardNum = String(body.cardNumber || body.payment?.cardNumber || "4242");
      const last4 = cardNum.slice(-4) || "4242";
      const planCost = planName === 'Enterprise' ? 199 : planName === 'Basic' ? 49 : 99;
      const amount = body.billingCycle === 'annual' ? (planCost * 12 * 0.8) : planCost;
      DBService.addTransaction({
        userId: user._id,
        email: user.email,
        name: user.name,
        planName,
        amount,
        status: "succeeded",
        cardLast4: last4,
        cardBrand: cardNum.startsWith('4') ? 'Visa' : cardNum.startsWith('5') ? 'Mastercard' : 'Amex'
      });
    }

    return json({
      success: true,
      message: "Account created successfully.",
      data: user
    });
  }

  // 1b. Direct Payment & Subscription Checkout
  if (pathname.includes('/subscription/pay') || pathname.includes('/stripe/checkout') || pathname.includes('/payment/process')) {
    const email = (body.email || DBService.getCurrentUser()?.email || `user_${Date.now()}@carenote.com`).toLowerCase().trim();
    const planName = body.plan || body.tier || "Growth";
    const planCost = planName === 'Enterprise' ? 199 : planName === 'Basic' ? 49 : 99;
    const amount = body.billingCycle === 'annual' ? Math.round(planCost * 12 * 0.8) : planCost;
    const cardNum = String(body.cardNumber || "4242").replace(/\s+/g, '');
    const last4 = cardNum.slice(-4) || "4242";

    const user = DBService.upsertUser({
      email,
      name: body.name || "Subscriber",
      userType: body.userType || "Admin",
      tier: planName
    });

    const txn = DBService.addTransaction({
      userId: user._id,
      email: user.email,
      name: user.name,
      planName,
      amount,
      status: "succeeded",
      cardLast4: last4,
      cardBrand: cardNum.startsWith('4') ? 'Visa' : cardNum.startsWith('5') ? 'Mastercard' : 'Amex'
    });

    return json({
      success: true,
      message: `Payment of $${amount} for ${planName} Plan processed successfully!`,
      data: {
        transaction: txn,
        user
      }
    });
  }

  // 1c. Get Pricing Plans
  if (pathname.includes('/Pricing/getPricing') || (pathname.includes('/pricing') && req.method === 'GET')) {
    return json({
      success: true,
      data: PRICING_PLANS
    });
  }

  // 1d. Get Subscription Details
  if (pathname.includes('/get-subscription-details') || pathname.includes('/subscription/details')) {
    const currentTier = DBService.getCurrentUser()?.tier || "Growth";
    return json({
      success: true,
      data: {
        tier: currentTier,
        status: "active",
        subscription: {
          status: "active",
          cancel_at_period_end: false,
          current_period_start: Math.floor(Date.now() / 1000) - 86400 * 5,
          next_invoice_date: Math.floor(Date.now() / 1000) + 86400 * 25,
          trial_end: Math.floor(Date.now() / 1000) + 86400 * 25
        }
      }
    });
  }

  // 1e. Transactions List
  if (pathname.includes('/transactions')) {
    return json({
      success: true,
      data: DBService.getTransactions()
    });
  }

  // 2. Login / OTP Challenge
  if (pathname.endsWith('/otpChallenge') || pathname.endsWith('/login') || pathname.endsWith('/signIn')) {
    const inputEmail = (body.email || '').toLowerCase().trim();
    const inputPassword = body.password || '';

    let matchedUser = DBService.getUserByEmail(inputEmail);

    if (!matchedUser && (inputEmail.includes('swaray') || inputEmail.includes('sheku') || inputEmail === 'swaraysheku12@gmail.com')) {
      matchedUser = DBService.getUserByEmail('swaraysheku12@gmail.com');
    }

    if (!matchedUser && (inputEmail === 'employee@carenote.com' || inputEmail === 'employee@oasisnotes.com' || inputEmail.includes('charles'))) {
      matchedUser = DBService.getUserByEmail('charles.smith@carenote.com') || DBService.getUserByEmail('charles.smith@oasisnotes.com');
    }

    if (!matchedUser && (inputEmail === 'admin@carenote.com' || inputEmail === 'admin@oasisnotes.com' || inputEmail.includes('admin'))) {
      matchedUser = DBService.getUserByEmail('admin@carenote.com') || DBService.getUserByEmail('admin@oasisnotes.com');
    }

    if (!matchedUser) {
      if (inputEmail) {
        matchedUser = DBService.upsertUser({
          email: inputEmail,
          password: inputPassword || 'password123',
          name: inputEmail.split('@')[0],
          userType: inputEmail.includes('admin') ? 'Admin' : 'Employee'
        });
      } else {
        matchedUser = DBService.getCurrentUser() || DBService.getAllUsers()[0];
      }
    }

    DBService.setCurrentUser(matchedUser.email);

    return json({
      success: true,
      message: "Login successful.",
      token: "mock-carenote-jwt-token",
      accessToken: "mock-carenote-jwt-token",
      data: matchedUser
    });
  }

  // 3. OTP Verify Challenge
  if (pathname.endsWith('/otpVerifyChallenge')) {
    const user = DBService.getCurrentUser() || DBService.getAllUsers()[0];
    return json({
      success: true,
      message: "OTP Verified.",
      token: "mock-carenote-jwt-token",
      data: user
    });
  }

  // 4. User Profiles (Admin & Employee)
  if (pathname.toLowerCase().endsWith('/admin/getprofile') || pathname.toLowerCase().endsWith('/employee/getprofile') || pathname.toLowerCase().endsWith('/getprofile')) {
    const user = DBService.getCurrentUser() || DBService.getAllUsers()[0];
    return json({
      success: true,
      data: user
    });
  }

  // 5. Token Refresh (Maintains authenticated session on /Home reload)
  if (pathname.endsWith('/refresh-token') || pathname.endsWith('/refreshToken')) {
    const user = DBService.getCurrentUser() || DBService.getAllUsers()[0];
    return json({
      success: true,
      token: "mock-carenote-jwt-token",
      accessToken: "mock-carenote-jwt-token",
      data: user
    });
  }

  // 5b. Update Active Organization
  if (pathname.endsWith('/updateActiveOrganization') || pathname.endsWith('/setActiveOrg')) {
    const orgId = body.activeOrganizationId || body.orgId;
    const user = DBService.getCurrentUser();
    if (user && orgId) {
      user.activeOrganizationId = orgId;
      DBService.upsertUser(user);
    }
    return json({
      success: true,
      message: "Organization updated successfully",
      data: { activeOrganizationId: orgId }
    });
  }

  // 5c. Logout
  if (pathname.endsWith('/logout') || pathname.endsWith('/signOut')) {
    return json({
      success: true,
      message: "Logged out successfully."
    });
  }

  // 5d. Pricing Plans
  if (pathname.toLowerCase().includes('pricing') || pathname.endsWith('/getPricing')) {
    return json({
      success: true,
      data: PRICING_PLANS
    });
  }

  // 5e. Subscription Details & Stripe
  if (pathname.includes('subscription') || pathname.includes('get-subscription-details')) {
    return json({
      success: true,
      data: {
        tier: "Growth",
        subscription: {
          status: "active",
          trial_end: Math.floor(Date.now() / 1000) + 86400 * 365,
          current_period_start: Math.floor(Date.now() / 1000) - 86400 * 30,
          next_invoice_date: Math.floor(Date.now() / 1000) + 86400 * 30,
          cancel_at_period_end: false
        }
      }
    });
  }

  if (pathname.includes('/stripe/')) {
    return json({
      success: true,
      message: "Subscription status active.",
      data: {
        url: "https://billing.stripe.com/session/mock",
        status: "active"
      }
    });
  }

  // 5f. Patient Profile & Allergies
  if (pathname.toLowerCase().includes('patient/getprofile') || pathname.toLowerCase().includes('patientallergies')) {
    return json({
      success: true,
      data: {
        allergies: "NKA (No Known Allergies)"
      },
      patientDetail: {
        allergies: "NKA (No Known Allergies)"
      }
    });
  }

  // 5g. Notifications & Array endpoints
  if (pathname.includes('Notification') || pathname.includes('notification')) {
    return json({
      success: true,
      data: []
    });
  }

  if (pathname.includes('Schedule') || pathname.includes('schedule')) {
    return json({
      success: true,
      data: []
    });
  }

  if (pathname.includes('contact') || pathname.includes('Contact')) {
    return json({
      success: true,
      data: []
    });
  }

  // 6. Dashboards
  if (pathname.endsWith('/employee/dashboard') || pathname.endsWith('/dashboard')) {
    const patients = DBService.getAllPatients();
    const vitals = DBService.getVitalsByPatient();
    const notes = DBService.getNotes();
    return json({
      success: true,
      data: {
        patients: patients.totalDocs,
        appointments: 3,
        pendingNotes: notes.length,
        vitals: vitals.length,
        recentPatients: patients.docs
      }
    });
  }

  if (pathname.endsWith('/admin/getDashboardInfo')) {
    const patients = DBService.getAllPatients();
    const users = DBService.getAllUsers();
    return json({
      success: true,
      data: {
        totalResidents: patients.totalDocs,
        activeBeds: 24,
        totalEmployees: users.length,
        complianceRate: 98.4,
        pendingAuthorizations: 2,
        notesCompletedToday: 14,
        upcomingAppointments: 5
      }
    });
  }

  if (pathname.endsWith('/admin/getAdmitDetails')) {
    const patients = DBService.getAllPatients();
    return json({
      success: true,
      data: {
        docs: patients.docs,
        totalDocs: patients.totalDocs,
        limit: 10,
        page: 1,
        totalPages: 1
      }
    });
  }

  // 7. Facilities
  if (pathname.endsWith('/list-facility')) {
    return json({
      success: true,
      data: DBService.getAllFacilities()
    });
  }

  // Shifts (getAll and list)
  if ((pathname.includes('/Shift') || pathname.includes('/shift')) && req.method === 'GET') {
    return json({
      success: true,
      data: [
        { _id: "shift_01", start: "07:00", end: "15:00", type: "Morning (7:00 AM - 3:00 PM)", timeTaken: 8 },
        { _id: "shift_02", start: "15:00", end: "23:00", type: "Evening (3:00 PM - 11:00 PM)", timeTaken: 8 },
        { _id: "shift_03", start: "23:00", end: "07:00", type: "Night (11:00 PM - 7:00 AM)", timeTaken: 8 }
      ]
    });
  }

  // Staff Schedule
  if (pathname.includes('StaffSchedule') || pathname.includes('staff-schedule')) {
    return json({
      success: true,
      data: []
    });
  }

  // 8. Assigned Residents / Patients List (/Home & /patient-list)
  if (pathname.includes('/get-assigned-residents') || pathname.includes('/assignedResidents') || pathname.includes('/patient/list')) {
    const query = searchParams.get('searchQuery') || searchParams.get('search') || '';
    const page = parseInt(searchParams.get('page') || '1', 10);
    const limit = parseInt(searchParams.get('limit') || '50', 10);
    const result = DBService.getAllPatients(query, limit, page);
    return json({
      success: true,
      data: result
    });
  }

  // 9. Single Patient Search / Details
  if (pathname.includes('/search/patient') || pathname.includes('/patient/getPatientById') || pathname.includes('/employee/getPatientById')) {
    const id = pathname.split('/').pop();
    const patient = DBService.getPatientById(id) || DBService.getAllPatients().docs[0];
    return json({
      success: true,
      data: patient
    });
  }

  // Patient Sub-Resources
  if (pathname.includes('/search/documents')) {
    return json({
      success: true,
      data: [
        { _id: "doc1", documentName: "Initial Assessment", date: "2024-01-16", author: "Dr. Reed", type: "assessment" },
        { _id: "doc2", documentName: "Face Sheet & Emergency Contacts", date: "2024-01-15", author: "Staff Nurse", type: "facesheet" },
        { _id: "doc3", documentName: "Treatment Plan", date: "2024-01-18", author: "Dr. Reed", type: "treatment" }
      ]
    });
  }

  // Vitals Endpoints
  if (pathname.includes('/search/vitals') || pathname.includes('/getPatientVitals')) {
    const patientId = searchParams.get('patientId') || pathname.split('/').pop();
    const vitals = DBService.getVitalsByPatient(patientId && !patientId.includes('getPatientVitals') && !patientId.includes('vitals') ? patientId : null);
    return json({
      success: true,
      data: {
        docs: vitals,
        totalDocs: vitals.length,
        limit: 50,
        page: 1,
        totalPages: 1
      }
    });
  }

  if (pathname.includes('/create-vital') || pathname.includes('/createPatientVitals')) {
    const newVital = DBService.addVital({
      ...body,
      recordedBy: DBService.getCurrentUser()?.name || "Charles Smith, BHT"
    });
    return json({
      success: true,
      message: "Vitals recorded successfully in database.",
      data: newVital
    });
  }

  // Medications Endpoints
  if (pathname.includes('/search/medications') || pathname.includes('/getPatientMedications')) {
    const patientId = searchParams.get('patientId') || pathname.split('/').pop();
    const meds = DBService.getMedications(patientId && !patientId.includes('getPatientMedications') && !patientId.includes('medications') ? patientId : null);
    return json({
      success: true,
      data: meds
    });
  }

  if (pathname.includes('/search/appointments')) {
    return json({
      success: true,
      data: [
        {
          _id: "appt001",
          patientName: "Sarah Connor",
          provider: "Dr. Evelyn Reed, MD",
          serviceType: "Psychiatric Evaluation & Medication Follow-up",
          date: new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0],
          time: "10:30 AM",
          status: "Confirmed"
        }
      ]
    });
  }

  if (pathname.includes('/search/intake')) {
    return json({
      success: true,
      data: {
        faceSheet: true,
        initialAssessment: true,
        nursingAssessment: true,
        residentIntake: true,
        safetyPlan: true
      }
    });
  }

  // 10. Employees / Staff List (for Signers dropdown & user listings)
  if (pathname.includes('/get-employee') || pathname.includes('/getEmployee')) {
    const users = DBService.getAllUsers();
    return json({
      success: true,
      data: users
    });
  }

  if (pathname.includes('/admin/listEmployees') || pathname.includes('/users') || pathname.includes('/admin/getUser')) {
    const users = DBService.getAllUsers();
    return json({
      success: true,
      data: {
        docs: users,
        totalDocs: users.length,
        limit: 50,
        page: 1,
        totalPages: 1
      }
    });
  }

  // 11. Activity Logs & Form Types
  if (pathname.includes('/activity-logs/form-type')) {
    return json({
      success: true,
      data: [
        "Resident Intake",
        "Face Sheet",
        "Initial Assessment",
        "Nursing Assessment",
        "Shift Progress Note",
        "Treatment Plan",
        "Incident Report",
        "Vital Signs",
        "Discharge Summary"
      ]
    });
  }

  if (pathname.includes('/activity-logs')) {
    return json({
      success: true,
      data: {
        docs: ACTIVITY_LOGS,
        totalDocs: ACTIVITY_LOGS.length,
        limit: 10,
        page: 1,
        totalPages: 1
      }
    });
  }


  // 13. Generic Form / Document Submissions
  if (['POST', 'PUT'].includes(req.method)) {
    // If creating or updating a patient/resident
    if (pathname.includes('patient') || pathname.includes('resident') || pathname.includes('face-sheet') || pathname.includes('intake')) {
      const savedPatient = DBService.upsertPatient(body);
      return json({
        success: true,
        message: "Resident chart updated successfully in database.",
        data: savedPatient
      });
    }

    // Generic success for any other POST/PUT
    return json({
      success: true,
      message: "Action completed successfully.",
      data: { ...body, _id: `item_${Date.now()}` }
    });
  }

  // 14. Generic API Fallback for any unmapped GET
  return json({
    success: true,
    data: {
      docs: [],
      totalDocs: 0,
      page: 1,
      limit: 10,
      totalPages: 1
    }
  });
}

async function requestHandler(req, res) {
  setCorsHeaders(req, res);
  if (req.method === 'OPTIONS') {
    res.statusCode = 204;
    return res.end();
  }

  const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = decodeURIComponent(parsedUrl.pathname);

  const acceptHeader = req.headers['accept'] || '';
  const isExplicitJson = acceptHeader.includes('application/json');
  const hasAuthHeader = !!(req.headers['authorization'] || req.headers['timezone'] || req.headers['organization']);
  const isMutation = ['POST', 'PUT', 'DELETE', 'PATCH'].includes(req.method);

  // Dedicated API prefixes and endpoints in CareNote
  const isApiPrefix = pathname.startsWith('/api/') ||
    pathname.startsWith('/v1/') ||
    pathname.startsWith('/admin/') ||
    pathname.startsWith('/employee/') ||
    pathname.startsWith('/patient/') ||
    pathname.startsWith('/Shift/') ||
    pathname.startsWith('/shift/') ||
    pathname.startsWith('/Pricing/') ||
    pathname.startsWith('/pricing/') ||
    pathname.startsWith('/StaffSchedule/') ||
    pathname.startsWith('/staff-schedule/') ||
    pathname.startsWith('/search/') ||
    pathname.startsWith('/auth/') ||
    pathname.startsWith('/stripe/') ||
    pathname.startsWith('/subscription/') ||
    pathname.startsWith('/activity-logs') ||
    pathname.startsWith('/custom-forms') ||
    pathname.startsWith('/clinical-templates') ||
    pathname.startsWith('/form-submissions');

  const isApiKeyword = pathname.includes('/get') ||
    pathname.includes('/list') ||
    pathname.includes('/search') ||
    pathname.includes('/create') ||
    pathname.includes('/edit') ||
    pathname.includes('/update') ||
    pathname.includes('/delete') ||
    pathname.includes('otpChallenge') ||
    pathname.includes('otpVerify') ||
    pathname.includes('refreshToken') ||
    pathname.includes('login') ||
    pathname.includes('logout') ||
    pathname.includes('progress-note') ||
    pathname.includes('progressNote');

  // SPA Page routes that should return index.html for browser navigation (GET with text/html)
  const isSpaPage = !isMutation && !isExplicitJson && !hasAuthHeader && (
    acceptHeader.includes('text/html') ||
    pathname === '/' ||
    pathname === '/Home' ||
    pathname === '/home' ||
    pathname === '/dashboard' ||
    pathname === '/patient-list' ||
    pathname === '/employee-list' ||
    pathname === '/schedule' ||
    pathname === '/activity-schedule' ||
    pathname === '/tracking-log' ||
    pathname === '/employee-performance' ||
    pathname === '/skills-knowledge-training' ||
    pathname === '/on-site' ||
    pathname === '/list-clinical-oversight' ||
    pathname === '/receipts' ||
    pathname === '/special-notes' ||
    pathname === '/appendix-list' ||
    pathname === '/discharge-summary' ||
    pathname === '/staff-note' ||
    pathname === '/view-employement-application' ||
    pathname.startsWith('/employee/patient-chart') ||
    pathname.startsWith('/employee/training') ||
    pathname.startsWith('/patient-tracking') ||
    pathname.startsWith('/therapy-log') ||
    pathname.startsWith('/milega-log') ||
    pathname.startsWith('/vitals') ||
    pathname.startsWith('/reassessment-list') ||
    pathname.startsWith('/medications') ||
    pathname.startsWith('/basic-information') ||
    pathname.startsWith('/employment') ||
    pathname.startsWith('/get-time-of-request') ||
    pathname.startsWith('/scheduleGroup') ||
    pathname.startsWith('/employee-tracking') ||
    pathname.startsWith('/progree-note') ||
    pathname.startsWith('/view-') ||
    pathname.startsWith('/create-') ||
    pathname.startsWith('/edit-') ||
    pathname.startsWith('/update-')
  );

  const isApi = (isApiPrefix || isApiKeyword || isMutation || isExplicitJson || hasAuthHeader) && !isSpaPage;

  // 1. Handle API requests
  if (isApi) {
    try {
      return await handleApiRequest(req, res, parsedUrl);
    } catch (apiErr) {
      console.error(`[API ERROR] ${req.method} ${pathname}:`, apiErr);
      if (!res.headersSent) {
        res.statusCode = 500;
        res.setHeader('Content-Type', 'application/json');
        setCorsHeaders(req, res);
        res.end(JSON.stringify({ success: false, message: apiErr.message || "Internal server error" }));
      }
      return;
    }
  }

  // 2. Direct or fuzzy local file
  if (pathname === '/subscription' || pathname === '/pricing' || pathname === '/plans') {
    const subPage = path.join(PUBLIC_DIR, 'subscription.html');
    if (fs.existsSync(subPage)) {
      return serveLocalFile(subPage, req, res);
    }
  }

  const localFile = findLocalFile(pathname);
  if (localFile) {
    return serveLocalFile(localFile, req, res);
  }

  // 3. Static asset / file requests with extension or in assets/
  const ext = path.extname(pathname);
  if (pathname.startsWith('/assets/') || pathname.startsWith('/js/') || pathname.startsWith('/css/') || pathname.startsWith('/fonts/') || pathname.startsWith('/images/') || ext !== '') {
    return fetchAndCacheRemoteAsset(pathname, req, res);
  }

  // 4. SPA Navigation fallback: serve index.html (for /Home, /dashboard, /patient-list, /employment, etc.)
  const indexPath = path.join(PUBLIC_DIR, 'index.html');
  if (fs.existsSync(indexPath)) {
    return serveLocalFile(indexPath, req, res);
  }

  res.statusCode = 404;
  res.end('404 Not Found');
}

// Export requestHandler for serverless environments (e.g. Vercel)
export { requestHandler };
export default requestHandler;

// Only bind HTTP listeners when running standalone outside of serverless environments
if (!process.env.VERCEL) {
  // Main server on PORT 3000
  const server = http.createServer(requestHandler);

  server.listen(PORT, () => {
    console.log(`\n=================================================`);
    console.log(`  CareNote Platform Server running at:`);
    console.log(`  >>> http://localhost:${PORT}/ <<<`);
    console.log(`=================================================\n`);
  });

  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      const nextPort = Number(PORT) + 1;
      console.log(`Port ${PORT} is busy, retrying on ${nextPort}...`);
      server.listen(nextPort);
    } else {
      console.error('Server error:', err);
    }
  });

  // Also start on ALT_PORT (4002) for direct API proxy compatibility
  try {
    const altServer = http.createServer(requestHandler);
    altServer.listen(ALT_PORT, () => {
      console.log(`  Secondary API listener active at http://localhost:${ALT_PORT}/`);
    });
    altServer.on('error', (err) => {
      console.log(`  (Port ${ALT_PORT} not bound: ${err.message})`);
    });
  } catch (e) {
    // Ignore
  }
}

