import{Go as e,Xo as t}from"./authSlice-DgGx7gH_.js";import{n,r,t as i}from"./printHelpers-Dep5Ei1Z.js";var a=t(e()),o=({getApiData:e,patientDetail:t})=>{let o=a.useRef(),s=r({content:()=>i(o.current.cloneNode(!0),e?.data?.patientId||e?.patientId,t),documentTitle:n(e?.data?.patientId||e?.patientId,t),pageStyle:`
     .hide-print-btn{
        display:none;
        }
        @page {
          margin: 12mm 9mm!important;
        }   
        .view-details-grid 
        {
          page-break-inside: avoid;
        }
        .card {
          page-break-inside: avoid;
        }
      `}),c=a.useRef(),l=r({content:()=>i(c.current.cloneNode(!0),e?.data?.patientId||e?.patientId,t),documentTitle:n(e?.data?.patientId||e?.patientId),pageStyle:`
     .hide-print-btn{
        display:none;
        }
         @page {
          margin: 12mm 9mm!important;
        }   
        .view-details-grid 
        {
          page-break-inside: avoid;
        }
        .card {
          page-break-inside: avoid;
        }
      `}),u=a.useRef(),d=r({content:()=>i(u.current.cloneNode(!0),e?.data?.patientId||e?.patientId,t),documentTitle:n(e?.data?.patientId||e?.patientId),pageStyle:`
     .hide-print-btn{
        display:none;
        }
         @page {
          margin: 12mm 9mm!important;
        }   
        .view-details-grid 
        {
          page-break-inside: avoid;
        }
        .card {
          page-break-inside: avoid;
        }
      `}),f=a.useRef(),p=r({content:()=>i(f.current.cloneNode(!0),e?.data?.patientId||e?.patientId,t),documentTitle:n(e?.data?.patientId||e?.patientId),pageStyle:`
     .hide-print-btn{
        display:none;
        }
         @page {
          margin: 12mm 9mm!important;
        }   
        .view-details-grid 
        {
          page-break-inside: avoid;
        }
        .card {
          page-break-inside: avoid;
        }
      `}),m=a.useRef(),h=r({content:()=>i(m.current.cloneNode(!0),e?.data?.patientId||e?.patientId,t),documentTitle:n(e?.data?.patientId||e?.patientId),pageStyle:`
     .hide-print-btn{
        display:none;
        }
         @page {
          margin: 12mm 9mm!important;
        }   
        .view-details-grid 
        {
          page-break-inside: avoid;
        }
        .card {
          page-break-inside: avoid;
        }
      `}),g=a.useRef(),_=r({content:()=>i(g.current.cloneNode(!0),e?.data?.patientId||e?.patientId,t),documentTitle:n(e?.data?.patientId||e?.patientId),pageStyle:`
     .hide-print-btn{
        display:none;
        }
         @page {
          margin: 12mm 9mm!important;
        }   
        .view-details-grid 
        {
          page-break-inside: avoid;
        }
        .card {
          page-break-inside: avoid;
        }
      `}),v=a.useRef(),y=r({content:()=>i(v.current.cloneNode(!0),e?.data?.patientId||e?.patientId,t),documentTitle:n(e?.data?.patientId||e?.patientId),pageStyle:`
     .hide-print-btn{
        display:none;
        }
         @page {
          margin: 12mm 9mm !important;
        }   
        .view-details-grid 
        {
          page-break-inside: avoid;
        }
        .card {
          page-break-inside: avoid;
        }
      `}),b=a.useRef(),x=r({content:()=>i(b.current.cloneNode(!0),e?.data?.patientId||e?.patientId,t),documentTitle:n(e?.data?.patientId||e?.patientId),pageStyle:`
     .hide-print-btn{
        display:none;
        }
         @page {
          margin: 12mm 9mm !important;
        }   
        .view-details-grid 
        {
          page-break-inside: avoid;
        }
        .card {
          page-break-inside: avoid;
        }
      `}),S=a.useRef(),C=r({content:()=>i(S.current.cloneNode(!0),e?.data?.patientId||e?.patientId,t),documentTitle:n(e?.data?.patientId||e?.patientId),pageStyle:`
     .hide-print-btn{
        display:none;
        }
         @page {
          margin: 12mm 9mm !important;
        }   
        .view-details-grid 
        {
          page-break-inside: avoid;
        }
        .card {
          page-break-inside: avoid;
        }
      `});return{componentRef1:o,componentRef2:c,componentRef3:u,componentRef4:f,componentRef5:m,componentRef6:g,componentRef7:v,componentRef8:b,componentRef9:S,handlePrintUpdate1:()=>{let e=document.getElementsByClassName(`hidePrint`),t=document.getElementsByClassName(`formheading1-hide`),n=document.getElementsByClassName(`formsheading2`),r=document.getElementsByClassName(`file-upload-box`),i=document.getElementsByClassName(`increase-print-width`),a=document.getElementsByClassName(`form-field-child`),o=document.getElementsByClassName(`form-field-single-update`);for(let t=0;t<e.length;t++)e[t].style.display=`none`;for(let e=0;e<r.length;e++)r[e].style.justifyContent=`right`;for(let e=0;e<t.length;e++)t[e].style.display=`block`,t[e].style.marginTop=`1rem`;for(let e=0;e<i.length;e++)i[e].style.width=`100%`,i[e].style.margin=`auto`;for(let e=0;e<n.length;e++)n[e].style.backgroundColor=`white`;for(let e=0;e<a.length;e++){let t=a[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`none`}for(let e=0;e<o.length;e++){let t=o[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`none`}s(),setTimeout(()=>{for(let t=0;t<e.length;t++)e[t].style.display=`block`;for(let e=0;e<r.length;e++)r[e].style.justifyContent=`space-between`;for(let e=0;e<t.length;e++)t[e].style.display=`none`;for(let e=0;e<n.length;e++)n[e].style.backgroundColor=`#1a9fb2`;for(let e=0;e<i.length;e++)i[e].style.width=`100%`;for(let e=0;e<a.length;e++){let t=a[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`1px solid black`}for(let e=0;e<o.length;e++){let t=o[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`1px solid black`}},500)},handlePrintUpdate2:()=>{let e=document.getElementsByClassName(`hidePrint`),t=document.getElementsByClassName(`addButton`),n=document.getElementsByClassName(`file-upload-box`),r=document.getElementsByClassName(`increase-print-width`),i=document.getElementsByClassName(`form-field-child`),a=document.getElementsByClassName(`form-field-single-update`);for(let t=0;t<e.length;t++)e[t].style.display=`none`;for(let e=0;e<t.length;e++)t[e].style.display=`none`;for(let e=0;e<n.length;e++)n[e].style.justifyContent=`right`;for(let e=0;e<r.length;e++)r[e].style.width=`100%`,r[e].style.margin=`auto`;for(let e=0;e<i.length;e++){let t=i[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`none`}for(let e=0;e<a.length;e++){let t=a[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`none`}l(),setTimeout(()=>{for(let t=0;t<e.length;t++)e[t].style.display=`block`;for(let e=0;e<t.length;e++)t[e].style.display=`block`,t[e].style.justifyContent=`center`;for(let e=0;e<n.length;e++)n[e].style.justifyContent=`space-between`;for(let e=0;e<r.length;e++)r[e].style.width=`100%`;for(let e=0;e<i.length;e++){let t=i[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`1px solid black`}for(let e=0;e<a.length;e++){let t=a[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`1px solid black`}},1e3)},handlePrintUpdate3:()=>{let e=document.getElementsByClassName(`hidePrint`),t=document.getElementsByClassName(`file-upload-box`),n=document.getElementsByClassName(`increase-print-width`),r=document.getElementsByClassName(`form-field-child`),i=document.getElementsByClassName(`form-field-single-update`);for(let t=0;t<e.length;t++)e[t].style.display=`none`;for(let e=0;e<t.length;e++)t[e].style.justifyContent=`right`;for(let e=0;e<n.length;e++)n[e].style.width=`100%`,n[e].style.margin=`auto`;for(let e=0;e<r.length;e++){let t=r[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`none`}for(let e=0;e<i.length;e++){let t=i[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`none`}d(),setTimeout(()=>{for(let t=0;t<e.length;t++)e[t].style.display=`block`;for(let e=0;e<t.length;e++)t[e].style.justifyContent=`space-between`;for(let e=0;e<n.length;e++)n[e].style.width=`100%`;for(let e=0;e<r.length;e++){let t=r[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`1px solid black`}for(let e=0;e<i.length;e++){let t=i[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`1px solid black`}},1e3)},handlePrintUpdate4:()=>{let e=document.getElementsByClassName(`hidePrint`),t=document.getElementsByClassName(`file-upload-box`),n=document.getElementsByClassName(`increase-print-width`),r=document.getElementsByClassName(`form-field-child`),i=document.getElementsByClassName(`form-field-single-update`);for(let t=0;t<e.length;t++)e[t].style.display=`none`;for(let e=0;e<t.length;e++)t[e].style.justifyContent=`right`;for(let e=0;e<n.length;e++)n[e].style.width=`100%`,n[e].style.margin=`auto`;for(let e=0;e<r.length;e++){let t=r[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`none`}for(let e=0;e<i.length;e++){let t=i[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`none`}p(),setTimeout(()=>{for(let t=0;t<e.length;t++)e[t].style.display=`block`;for(let e=0;e<t.length;e++)t[e].style.justifyContent=`space-between`;for(let e=0;e<n.length;e++)n[e].style.width=`100%`;for(let e=0;e<r.length;e++){let t=r[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`1px solid black`}for(let e=0;e<i.length;e++){let t=i[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`1px solid black`}},1e3)},handlePrintUpdate5:()=>{let e=document.getElementsByClassName(`hidePrint`),t=document.getElementsByClassName(`file-upload-box`),n=document.getElementsByClassName(`increase-print-width`),r=document.getElementsByClassName(`form-field-child`),i=document.getElementsByClassName(`form-field-single-update`);for(let t=0;t<e.length;t++)e[t].style.display=`none`;for(let e=0;e<t.length;e++)t[e].style.justifyContent=`right`;for(let e=0;e<n.length;e++)n[e].style.width=`100%`,n[e].style.margin=`auto`;for(let e=0;e<r.length;e++){let t=r[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`none`}for(let e=0;e<i.length;e++){let t=i[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`none`}h(),setTimeout(()=>{for(let t=0;t<e.length;t++)e[t].style.display=`block`;for(let e=0;e<t.length;e++)t[e].style.justifyContent=`space-between`;for(let e=0;e<n.length;e++)n[e].style.width=`100%`;for(let e=0;e<r.length;e++){let t=r[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`1px solid black`}for(let e=0;e<i.length;e++){let t=i[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`1px solid black`}},1e3)},handlePrintUpdate6:()=>{let e=document.getElementsByClassName(`hidePrint`),t=document.getElementsByClassName(`file-upload-box`),n=document.getElementsByClassName(`increase-print-width`),r=document.getElementsByClassName(`form-field-child`),i=document.getElementsByClassName(`form-field-single-update`);for(let t=0;t<e.length;t++)e[t].style.display=`none`;for(let e=0;e<t.length;e++)t[e].style.justifyContent=`right`;for(let e=0;e<n.length;e++)n[e].style.width=`100%`,n[e].style.margin=`auto`;for(let e=0;e<r.length;e++){let t=r[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`none`}for(let e=0;e<i.length;e++){let t=i[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`none`}_(),setTimeout(()=>{for(let t=0;t<e.length;t++)e[t].style.display=`block`;for(let e=0;e<t.length;e++)t[e].style.justifyContent=`space-between`;for(let e=0;e<n.length;e++)n[e].style.width=`100%`;for(let e=0;e<r.length;e++){let t=r[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`1px solid black`}for(let e=0;e<i.length;e++){let t=i[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`1px solid black`}},1e3)},handlePrintUpdate7:()=>{let e=document.getElementsByClassName(`hidePrint`),t=document.getElementsByClassName(`file-upload-box`),n=document.getElementsByClassName(`increase-print-width`),r=document.getElementsByClassName(`form-field-child`),i=document.getElementsByClassName(`form-field-single-update`);for(let t=0;t<e.length;t++)e[t].style.display=`none`;for(let e=0;e<n.length;e++)n[e].style.width=`100%`,n[e].style.margin=`auto`;for(let e=0;e<t.length;e++)t[e].style.justifyContent=`right`;for(let e=0;e<r.length;e++){let t=r[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`none`}for(let e=0;e<i.length;e++){let t=i[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`none`}y(),setTimeout(()=>{for(let t=0;t<e.length;t++)e[t].style.display=`block`;for(let e=0;e<t.length;e++)t[e].style.justifyContent=`space-between`;for(let e=0;e<n.length;e++)n[e].style.width=`100%`;for(let e=0;e<r.length;e++){let t=r[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`1px solid black`}for(let e=0;e<i.length;e++){let t=i[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`1px solid black`}},1e3)},handlePrintUpdate8:()=>{let e=document.getElementsByClassName(`hidePrint`),t=document.getElementsByClassName(`file-upload-box`),n=document.getElementsByClassName(`form-actions`),r=document.getElementsByClassName(`increase-print-width`),i=document.getElementsByClassName(`form-field-child`),a=document.getElementsByClassName(`form-field-single-update`);for(let t=0;t<e.length;t++)e[t].style.display=`none`;for(let e=0;e<t.length;e++)t[e].style.justifyContent=`right`;for(let e=0;e<n.length;e++)n[e].style.display=`flex`,n[e].style.justifyContent=`center`,n[e].style.alignItems=`center`;for(let e=0;e<r.length;e++)r[e].style.width=`100%`,r[e].style.margin=`auto`;for(let e=0;e<i.length;e++){let t=i[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`none`}for(let e=0;e<a.length;e++){let t=a[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`none`}x(),setTimeout(()=>{for(let t=0;t<e.length;t++)e[t].style.display=`block`;for(let e=0;e<t.length;e++)t[e].style.justifyContent=`space-between`;for(let e=0;e<n.length;e++)n[e].style.display=`block`,n[e].style.justifyContent=`center`,n[e].style.alignItems=`center`;for(let e=0;e<r.length;e++)r[e].style.width=`100%`;for(let e=0;e<i.length;e++){let t=i[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`1px solid black`}for(let e=0;e<a.length;e++){let t=a[e].getElementsByTagName(`input`);for(let e=0;e<t.length;e++)t[e].style.borderBottom=`1px solid black`}},1e3)},handlePrintUpdate9:()=>{C()}}};export{o as t};