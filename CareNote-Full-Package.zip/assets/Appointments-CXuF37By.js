import{$a as e,D as t,Dr as n,Ga as r,Gi as i,Go as a,Ho as o,Lr as s,Mo as c,O as l,Or as u,Po as d,Va as f,Wi as p,Xo as m,ai as h,b as g,c as _,co as v,io as y,ko as b}from"./authSlice-DgGx7gH_.js";import{P as ee,a as te,n as ne,t as x}from"./Row-DeJt2hhu.js";import{i as re,l as ie}from"./Modal-DJGr1nh6.js";import{n as ae,t as oe}from"./Table-63g8S91d.js";import{K as S,k as se,mt as ce}from"./index-CBt-Uili.js";import{t as le}from"./AppointmentsCard-3mrXUkjM.js";/* empty css             */var ue=`data:image/svg+xml,%3csvg%20width='24'%20height='39'%20viewBox='0%200%2024%2039'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M12.0416%200.00683594C12.0416%2011.1153%200.734375%2019.105%200.734375%2027.0952C0.734375%2033.23%205.79667%2038.2032%2012.0416%2038.2032C18.2857%2038.2032%2023.3476%2033.23%2023.3476%2027.0952C23.3476%2019.105%2012.0416%2011.1153%2012.0416%200.00683594ZM16.5902%2032.8176H7.49128V30.395L16.5902%2030.3966V32.8176ZM16.5902%2024.4358L13.2753%2024.4341V27.6946H10.8054V24.4341H7.49086V22.0114H10.8054V18.7543H13.2753V22.0114H16.5902V24.4358Z'%20fill='%23478F96'/%3e%3c/svg%3e`,de=`data:image/svg+xml,%3csvg%20width='36'%20height='36'%20viewBox='0%200%2036%2036'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M17.9996%2035.0436C8.59781%2035.0436%200.956055%2027.3977%200.956055%2018.0001C0.956055%208.5983%208.60193%200.956543%2017.9996%200.956543C27.3972%200.956543%2035.0431%208.60242%2035.0431%2018.0001C35.0431%2018.7667%2034.9936%2019.5375%2034.8906%2020.2918C34.7875%2021.0625%2034.0745%2021.6025%2033.3078%2021.4994C32.537%2021.3964%2031.9971%2020.6874%2032.1001%2019.9167C32.1826%2019.286%2032.2279%2018.643%2032.2279%2018.0042C32.2279%2010.1604%2025.8433%203.77583%2017.9996%203.77583C10.1558%203.77583%203.77534%2010.1563%203.77534%2018.0001C3.77534%2025.8438%2010.16%2032.2284%2018.0037%2032.2284C19.6606%2032.2284%2021.2805%2031.9481%2022.822%2031.3917C23.5516%2031.1279%2024.3594%2031.5112%2024.6232%2032.2408C24.887%2032.9703%2024.5037%2033.7782%2023.7742%2034.042C21.9235%2034.7056%2019.9821%2035.0436%2017.9996%2035.0436Z'%20fill='%23018FFB'/%3e%3cpath%20d='M28.0159%2030.3775H31.2021C31.5195%2030.3775%2031.7626%2030.46%2031.9275%2030.6248C32.0965%2030.7938%2032.1789%2031.0164%2032.1789%2031.2967C32.1789%2031.5522%2032.113%2031.7666%2031.9811%2031.9397C31.8492%2032.1128%2031.6513%2032.2035%2031.3793%2032.2035H26.8907C26.5857%2032.2035%2026.3466%2032.0963%2026.1735%2031.882C26.0004%2031.6676%2025.918%2031.4121%2025.918%2031.1236C25.918%2030.9381%2025.9716%2030.6908%2026.0828%2030.3817C26.1941%2030.0725%2026.3095%2029.8335%2026.4456%2029.6562C26.9855%2028.939%2027.4719%2028.3331%2027.9088%2027.822C28.3416%2027.3109%2028.6548%2026.9771%2028.8403%2026.8163C29.1742%2026.5154%2029.4544%2026.2145%2029.6729%2025.9137C29.8914%2025.6128%2030.0645%2025.2995%2030.1799%2024.9821C30.2953%2024.6606%2030.353%2024.3556%2030.353%2024.0465C30.353%2023.7168%2030.2912%2023.42%2030.1675%2023.1603C30.0439%2022.8965%2029.8749%2022.6946%2029.6605%2022.5503C29.4462%2022.406%2029.2154%2022.3318%2028.9598%2022.3318C28.4281%2022.3318%2028.0077%2022.6286%2027.7027%2023.2221C27.6615%2023.2963%2027.5914%2023.5107%2027.4966%2023.8569C27.4018%2024.2031%2027.2946%2024.471%2027.1751%2024.6565C27.0515%2024.842%2026.8783%2024.9327%2026.6475%2024.9327C26.4456%2024.9327%2026.2766%2024.8502%2026.1405%2024.6771C26.0086%2024.504%2025.9386%2024.2732%2025.9386%2023.9805C25.9386%2023.622%2026.0045%2023.251%2026.1282%2022.8677C26.2518%2022.4802%2026.4456%2022.1299%2026.6929%2021.8125C26.9443%2021.4951%2027.2617%2021.2437%2027.645%2021.0458C28.0283%2020.8521%2028.4776%2020.7573%2028.9969%2020.7573C29.6193%2020.7573%2030.151%2020.881%2030.5921%2021.1283C30.8765%2021.2973%2031.1279%2021.5199%2031.3422%2021.8084C31.5607%2022.0969%2031.7255%2022.4308%2031.8451%2022.8141C31.9687%2023.1933%2032.0223%2023.5849%2032.0223%2023.997C32.0223%2024.64%2031.8987%2025.2212%2031.6472%2025.7488C31.3958%2026.2722%2031.1402%2026.6844%2030.8806%2026.9812C30.6209%2027.278%2030.184%2027.7478%2029.5699%2028.3826C28.9557%2029.0173%2028.5394%2029.512%2028.3086%2029.8623C28.2179%2030.0148%2028.1149%2030.1797%2028.0159%2030.3775Z'%20fill='%23018FFB'/%3e%3c/svg%3e`,fe=`data:image/svg+xml,%3csvg%20width='25'%20height='42'%20viewBox='0%200%2025%2042'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M19.853%202.98047H4.95456C4.122%202.98047%203.4209%203.71078%203.4209%204.57803V22.3794C3.4209%2023.2467%204.122%2023.977%204.95456%2023.977H19.853C20.6855%2023.977%2021.3866%2023.2467%2021.3866%2022.3794V4.57803C21.3866%203.71078%2020.6855%202.98047%2019.853%202.98047ZM8.67915%2017.1303H5.17365V15.761H8.67915V17.1303ZM14.3756%2017.1303H10.4319V15.761H14.3756V17.1303ZM19.6339%2017.1303H16.1284V15.761H19.6339V17.1303Z'%20fill='%23E79B38'/%3e%3cpath%20d='M21.6059%200.241211H3.20203C1.88746%200.241211%200.791992%201.38233%200.791992%202.75166V25.0262C0.791992%2026.3499%201.274%2027.5823%202.10656%2028.5409L4.34131%2031.0969L4.38513%2031.1426C5.91879%2032.8771%206.09407%2033.0597%206.48844%2033.0597H9.99394V39.0848L10.6074%2041.2757H14.2444L14.8578%2039.0848V33.1053H18.3633C18.7577%2033.1053%2018.933%2032.9227%2020.4666%2031.1882L22.7452%2028.5409C23.5778%2027.5823%2024.0598%2026.3043%2024.0598%2025.0262V2.75166C24.016%201.38233%2022.9205%200.241211%2021.6059%200.241211ZM7.36481%2031.736V30.3666H9.99394V31.736H7.36481ZM13.0613%2037.6698V34.9311H11.7467V37.6698H11.3085V30.3666H13.4994V37.6698H13.0613ZM11.5714%2039.952L11.3085%2039.0391H13.4556L13.1927%2039.952H11.5714ZM14.814%2030.3666H17.4431V31.736H14.814V30.3666ZM22.7014%2025.0262C22.7014%2025.9848%2022.3508%2026.8976%2021.7374%2027.628L19.5026%2030.1841L19.4588%2030.2297C19.2397%2030.5036%2018.9768%2030.7774%2018.7577%2031.0057V29.6363C18.7577%2029.2712%2018.451%2028.9517%2018.1004%2028.9517H6.70753C6.35698%2028.9517%206.05025%2029.2712%206.05025%2029.6363V31.0057C5.83115%2030.7318%205.56824%2030.4579%205.34915%2030.2297L3.07057%2027.628C2.45711%2026.8976%202.10656%2025.9848%202.10656%2025.0262V2.75166C2.10656%202.11264%202.58856%201.61055%203.20203%201.61055H21.6059C22.2194%201.61055%2022.7014%202.11264%2022.7014%202.75166V25.0262Z'%20fill='%23E79B38'/%3e%3cpath%20d='M7.55837%2025.5494C6.94233%2026.1911%206.74812%2027.0292%207.12459%2027.4214C7.50106%2027.8135%208.30564%2027.6112%208.92168%2026.9695C9.53771%2026.3278%209.73192%2025.4897%209.35546%2025.0976C8.97899%2024.7054%208.1744%2024.9077%207.55837%2025.5494Z'%20fill='%23E79B38'/%3e%3cpath%20d='M15.447%2025.5494C14.831%2026.1911%2014.6368%2027.0292%2015.0133%2027.4214C15.3897%2027.8135%2016.1943%2027.6112%2016.8103%2026.9695C17.4264%2026.3278%2017.6206%2025.4897%2017.2441%2025.0976C16.8677%2024.7054%2016.0631%2024.9077%2015.447%2025.5494Z'%20fill='%23E79B38'/%3e%3cpath%20d='M11.5037%2025.5494C10.8876%2026.1911%2010.6934%2027.0292%2011.0699%2027.4214C11.4464%2027.8135%2012.251%2027.6112%2012.867%2026.9695C13.483%2026.3278%2013.6772%2025.4897%2013.3008%2025.0976C12.9243%2024.7054%2012.1197%2024.9077%2011.5037%2025.5494Z'%20fill='%23E79B38'/%3e%3c/svg%3e`,pe=`data:image/svg+xml,%3csvg%20width='29'%20height='39'%20viewBox='0%200%2029%2039'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M24.3668%207.98043C23.5199%207.98043%2022.6921%208.24521%2021.9879%208.74127C21.2838%209.23734%2020.735%209.94241%2020.4109%2010.7673C20.0868%2011.5923%2020.002%2012.5%2020.1672%2013.3757C20.3324%2014.2515%2020.7403%2015.0559%2021.3391%2015.6872C21.9379%2016.3186%2022.7009%2016.7486%2023.5315%2016.9228C24.3621%2017.097%2025.223%2017.0076%2026.0054%2016.6659C26.7878%2016.3242%2027.4566%2015.7455%2027.927%2015.0031C28.3975%2014.2607%2028.6487%2013.3879%2028.6487%2012.495C28.6487%2011.2976%2028.1976%2010.1494%2027.3945%209.30271C26.5915%208.45607%2025.5024%207.98043%2024.3668%207.98043ZM24.3668%2014.4298C24.0039%2014.4298%2023.6491%2014.3163%2023.3473%2014.1037C23.0455%2013.8911%2022.8103%2013.5889%2022.6714%2013.2354C22.5325%2012.8819%2022.4962%2012.4928%2022.567%2012.1175C22.6378%2011.7422%2022.8126%2011.3975%2023.0692%2011.1269C23.3259%2010.8563%2023.6528%2010.672%2024.0088%2010.5974C24.3648%2010.5227%2024.7338%2010.561%2025.0691%2010.7075C25.4044%2010.8539%2025.691%2011.1019%2025.8926%2011.4201C26.0943%2011.7382%2026.2019%2012.1123%2026.2019%2012.495C26.2019%2013.0081%2026.0086%2013.5002%2025.6644%2013.8631C25.3203%2014.2259%2024.8535%2014.4298%2024.3668%2014.4298ZM11.5212%2023.6201V13.1399C11.5212%2012.7978%2011.3923%2012.4697%2011.1629%2012.2278C10.9335%2011.9859%2010.6223%2011.85%2010.2978%2011.85C9.97339%2011.85%209.66221%2011.9859%209.43278%2012.2278C9.20335%2012.4697%209.07446%2012.7978%209.07446%2013.1399V23.6201C7.92122%2023.9341%206.91617%2024.6807%206.2477%2025.72C5.57922%2026.7594%205.29322%2028.0201%205.4433%2029.2659C5.59338%2030.5117%206.16923%2031.657%207.06293%2032.4871C7.95662%2033.3172%209.10679%2033.7752%2010.2978%2033.7752C11.4889%2033.7752%2012.6391%2033.3172%2013.5328%2032.4871C14.4265%2031.657%2015.0023%2030.5117%2015.1524%2029.2659C15.3025%2028.0201%2015.0165%2026.7594%2014.348%2025.72C13.6795%2024.6807%2012.6745%2023.9341%2011.5212%2023.6201ZM10.2978%2031.1981C9.81392%2031.1981%209.34086%2031.0468%208.93849%2030.7633C8.53612%2030.4799%208.22251%2030.077%208.03732%2029.6056C7.85213%2029.1342%207.80368%2028.6155%207.89809%2028.1151C7.9925%2027.6147%208.22553%2027.155%208.56772%2026.7942C8.90991%2026.4334%209.34588%2026.1877%209.82051%2026.0882C10.2951%2025.9886%2010.7871%2026.0397%2011.2342%2026.235C11.6813%2026.4302%2012.0634%2026.7609%2012.3323%2027.1851C12.6011%2027.6094%2012.7446%2028.1081%2012.7446%2028.6184C12.7446%2029.3025%2012.4868%2029.9587%2012.028%2030.4425C11.5691%2030.9263%2010.9468%2031.1981%2010.2978%2031.1981ZM16.4148%2020.5567V6.69056C16.4148%204.98009%2015.7703%203.33967%2014.6232%202.13018C13.476%200.920694%2011.9202%200.241211%2010.2978%200.241211C8.67554%200.241211%207.11967%200.920694%205.97252%202.13018C4.82537%203.33967%204.18091%204.98009%204.18091%206.69056V20.5567C2.59802%2021.8929%201.44785%2023.7144%200.889331%2025.7696C0.330813%2027.8248%200.39153%2030.0122%201.06309%2032.0295C1.73465%2034.0467%202.9839%2035.7942%204.63819%2037.0305C6.29248%2038.2668%208.27013%2038.9309%2010.2978%2038.9309C12.3256%2038.9309%2014.3032%2038.2668%2015.9575%2037.0305C17.6118%2035.7942%2018.861%2034.0467%2019.5326%2032.0295C20.2042%2030.0122%2020.2649%2027.8248%2019.7064%2025.7696C19.1479%2023.7144%2017.9977%2021.8929%2016.4148%2020.5567ZM10.2978%2036.3576C8.73488%2036.3577%207.21268%2035.8318%205.95286%2034.8565C4.69303%2033.8812%203.76137%2032.5074%203.2935%2030.935C2.82564%2029.3627%202.846%2027.674%203.35163%2026.1147C3.85726%2024.5554%204.82175%2023.207%206.10469%2022.2657C6.26703%2022.1462%206.39943%2021.987%206.49053%2021.8016C6.58163%2021.6163%206.62869%2021.4104%206.62768%2021.2016V6.69056C6.62768%205.66428%207.01436%204.68003%207.70265%203.95433C8.39094%203.22864%209.32446%202.82095%2010.2978%202.82095C11.2712%202.82095%2012.2048%203.22864%2012.893%203.95433C13.5813%204.68003%2013.968%205.66428%2013.968%206.69056V21.2016C13.968%2021.4093%2014.0155%2021.6139%2014.1066%2021.798C14.1976%2021.9822%2014.3295%2022.1404%2014.491%2022.2593C15.7766%2023.1996%2016.7436%2024.5483%2017.251%2026.1089C17.7583%2027.6694%2017.7795%2029.36%2017.3113%2030.9341C16.8431%2032.5082%2015.9102%2033.8833%2014.6485%2034.859C13.3868%2035.8346%2011.8625%2036.3597%2010.2978%2036.3576Z'%20fill='%23FF6666'/%3e%3c/svg%3e`,me=`data:image/svg+xml,%3csvg%20width='37'%20height='37'%20viewBox='0%200%2037%2037'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cg%20clip-path='url(%23clip0_821_2291)'%3e%3cpath%20d='M23.7342%202.43652C22.5014%202.43652%2021.502%203.43596%2021.502%204.66879C21.502%205.90161%2022.5014%206.90105%2023.7342%206.90105C24.967%206.90105%2025.9665%205.90161%2025.9665%204.66879C25.9725%203.43587%2024.9731%202.43652%2023.7342%202.43652Z'%20fill='%233346D3'/%3e%3cpath%20d='M23.7345%200.419434C21.3885%200.419434%2019.4854%202.32852%2019.4854%204.66854C19.4854%207.01449%2021.3944%208.92367%2023.7405%208.92367C26.0865%208.92367%2027.9956%207.01458%2027.9956%204.66854C27.9955%202.32852%2026.0804%200.419434%2023.7345%200.419434ZM23.7345%206.90673C22.5016%206.90673%2021.5022%205.90729%2021.5022%204.67447C21.5022%203.44164%2022.5016%202.4422%2023.7345%202.4422C24.9673%202.4422%2025.9667%203.44164%2025.9667%204.67447C25.9727%205.90729%2024.9733%206.90673%2023.7345%206.90673Z'%20fill='%233346D3'/%3e%3cpath%20d='M28.6411%2013.3165C28.6411%2012.5565%2028.0247%2011.94%2027.2646%2011.94H26.7559L24.6613%2017.027C24.3022%2017.8828%2023.1352%2017.829%2022.7941%2017.027L20.6995%2011.9341H20.1968C19.4368%2011.9341%2018.8203%2012.5505%2018.8203%2013.3046V24.3342H28.6351V13.3165H28.6411Z'%20fill='%233346D3'/%3e%3cpath%20d='M20.4005%2034.7418H22.7226V30.0498C22.7226%2029.4932%2023.1714%2029.0384%2023.734%2029.0384C24.2906%2029.0384%2024.7454%2029.4872%2024.7454%2030.0498V34.7418H27.0674V26.3633H20.3945V34.7418H20.4005Z'%20fill='%233346D3'/%3e%3cpath%20d='M27.2707%209.91748H26.0916C25.6847%209.91748%2025.3136%2010.1688%2025.164%2010.5399L23.7457%2013.987L22.3213%2010.5399C22.1657%2010.1628%2021.8007%209.91748%2021.3937%209.91748H20.2088C18.3356%209.91748%2016.8154%2011.4436%2016.8154%2013.3108V25.352C16.8154%2025.9085%2017.2642%2026.3634%2017.8268%2026.3634H18.3894V35.7473C18.3894%2036.3039%2018.8382%2036.7587%2019.4008%2036.7587H28.0905C28.6471%2036.7587%2029.1019%2036.3099%2029.1019%2035.7473V26.3633H29.6585C30.215%2026.3633%2030.6699%2025.9145%2030.6699%2025.3519V13.3167C30.67%2011.4435%2029.1439%209.91748%2027.2707%209.91748ZM27.0791%2034.7418H24.7571V30.0498C24.7571%2029.4932%2024.3083%2029.0384%2023.7457%2029.0384C23.1891%2029.0384%2022.7343%2029.4872%2022.7343%2030.0498V34.7418H20.4123V26.3633H27.0852V34.7418H27.0791ZM18.8263%2024.3464V13.3167C18.8263%2012.5567%2019.4428%2011.9402%2020.2028%2011.9402H20.7115L22.8062%2017.0332C23.1473%2017.8352%2024.3143%2017.8889%2024.6734%2017.0332L26.768%2011.9462H27.2767C28.0367%2011.9462%2028.6532%2012.5626%2028.6532%2013.3227V24.3524H18.8263V24.3464Z'%20fill='%233346D3'/%3e%3cpath%20d='M12.5488%202.43643C13.1054%202.43643%2013.5602%201.98763%2013.5602%201.42505C13.5602%200.862471%2013.0994%200.413574%2012.5488%200.413574H7.16861C6.61205%200.413574%206.15723%200.862379%206.15723%201.42496V35.7469C6.15723%2036.3035%206.60603%2036.7583%207.16861%2036.7583H12.5488C13.1054%2036.7583%2013.5602%2036.3095%2013.5602%2035.7469C13.5602%2035.1904%2013.1114%2034.7355%2012.5488%2034.7355H8.18601V31.9049H12.5488C13.1054%2031.9049%2013.5602%2031.4561%2013.5602%2030.8935C13.5602%2030.3309%2013.1114%2029.8821%2012.5488%2029.8821H8.18601V26.9137H10.2687C10.8252%2026.9137%2011.2801%2026.4648%2011.2801%2025.9023C11.2801%2025.3398%2010.8313%2024.8909%2010.2687%2024.8909H8.18601V22.078H12.5488C13.1054%2022.078%2013.5602%2021.6292%2013.5602%2021.0666C13.5602%2020.5101%2013.1114%2020.0552%2012.5488%2020.0552H8.18601V17.0868H10.2687C10.8252%2017.0868%2011.2801%2016.638%2011.2801%2016.0754C11.2801%2015.5189%2010.8313%2015.0641%2010.2687%2015.0641H8.18601V12.2573H12.5488C13.1054%2012.2573%2013.5602%2011.8085%2013.5602%2011.2459C13.5602%2010.6893%2013.1114%2010.2345%2012.5488%2010.2345H8.18601V7.26006H10.2687C10.8252%207.26006%2011.2801%206.81126%2011.2801%206.24868C11.2801%205.6861%2010.8313%205.2373%2010.2687%205.2373H8.18601V2.3945H12.5488V2.43643Z'%20fill='%233346D3'/%3e%3c/g%3e%3cdefs%3e%3cclipPath%20id='clip0_821_2291'%3e%3crect%20width='36.3448'%20height='36.3448'%20fill='white'%20transform='translate(0.241211%200.413574)'/%3e%3c/clipPath%3e%3c/defs%3e%3c/svg%3e`,he=`data:image/svg+xml,%3csvg%20width='35'%20height='34'%20viewBox='0%200%2035%2034'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20fill-rule='evenodd'%20clip-rule='evenodd'%20d='M17.5783%203.03174C25.7378%20-1.31917%2030.7276%201.17964%2032.819%205.46371C33.9367%207.75342%2034.8368%2011.8153%2034.3027%2016.0537H26.7415L25.7543%2013.9113C25.3459%2012.8992%2023.9789%2012.793%2023.4469%2013.7699L22.6413%2015.248L20.9912%208.41143C20.7259%207.03489%2018.8352%206.95315%2018.4783%208.32336L16.7112%2015.0959L16.1259%2012.84C15.8657%2011.8221%2014.605%2011.4892%2013.9182%2012.2976L10.7186%2016.0537H0.853474C0.319334%2011.8153%201.21939%207.75342%202.33753%205.46371C4.42857%201.17964%209.41835%20-1.31917%2017.5783%203.03174ZM33.7612%2018.7449C32.0126%2024.9597%2022.9999%2032.2131%2017.5783%2033.2135C12.1567%2032.2127%203.14394%2024.9601%201.39542%2018.7454H11.293C11.7179%2018.7454%2012.0947%2018.5313%2012.3301%2018.2021L14.2573%2015.9399L15.4586%2020.5952C15.7994%2021.923%2017.6082%2021.9094%2017.9507%2020.5997L19.6771%2013.988L20.9227%2019.1496C21.2145%2020.3663%2022.7992%2020.5261%2023.3285%2019.4246L24.4727%2017.3241L24.774%2017.9776C24.9947%2018.4586%2025.4547%2018.7395%2025.9346%2018.74L33.7612%2018.7449Z'%20fill='%23CA6B6E'/%3e%3c/svg%3e`,ge=`data:image/svg+xml,%3csvg%20width='39'%20height='39'%20viewBox='0%200%2039%2039'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cg%20clip-path='url(%23clip0_821_2254)'%3e%3cpath%20d='M12.8004%2034.3706H2.81026C1.29834%2034.3706%200.0683594%2033.1406%200.0683594%2031.6286V25.5519C0.0683594%2017.7678%206.40107%2011.4351%2014.1852%2011.4351C14.9347%2011.4351%2015.5423%2012.0427%2015.5423%2012.7921V31.6286C15.5423%2033.1406%2014.3123%2034.3706%2012.8004%2034.3706Z'%20fill='%23E971FD'/%3e%3cpath%20d='M36.0162%2034.3706H26.0261C24.5142%2034.3706%2023.2842%2033.1406%2023.2842%2031.6287V12.7921C23.2842%2012.0426%2023.8918%2011.4351%2024.6412%2011.4351C32.4253%2011.4351%2038.7581%2017.7679%2038.7581%2025.5519V31.6286C38.7581%2033.1406%2037.5281%2034.3706%2036.0162%2034.3706Z'%20fill='%23E971FD'/%3e%3cpath%20d='M32.1112%2025.6956L30.4342%2024.427L32.1112%2023.1583C33.5438%2022.0745%2031.9031%2019.9123%2030.4738%2020.9937L28.1847%2022.7253L20.7701%2017.1163V6.15828C20.7701%205.40882%2020.1625%204.80127%2019.4131%204.80127C18.6637%204.80127%2018.0561%205.40889%2018.0561%206.15828V17.1164L10.6415%2022.7255L8.35257%2020.9939C6.92287%2019.9122%205.28324%2022.0751%206.71514%2023.1585L8.39217%2024.4271L6.71514%2025.6957C5.28248%2026.7796%206.92309%2028.9416%208.35257%2027.8603L19.4132%2019.4932L30.4738%2027.8603C31.9073%2028.9447%2033.5367%2026.774%2032.1112%2025.6956Z'%20fill='%23D23EEB'/%3e%3cpath%20d='M32.1112%2025.6956L30.4341%2024.427L32.1112%2023.1583C33.5437%2022.0745%2031.903%2019.9123%2030.4737%2020.9937L28.1847%2022.7253L20.7701%2017.1163V6.15828C20.7701%205.40882%2020.1625%204.80127%2019.4131%204.80127V19.4931L30.4737%2027.8602C31.9073%2028.9447%2033.5366%2026.774%2032.1112%2025.6956Z'%20fill='%23D23EEB'/%3e%3c/g%3e%3cdefs%3e%3cclipPath%20id='clip0_821_2254'%3e%3crect%20width='38.6897'%20height='38.6897'%20fill='white'%20transform='translate(0.0683594%200.241211)'/%3e%3c/clipPath%3e%3c/defs%3e%3c/svg%3e`,_e=`data:image/svg+xml,%3csvg%20width='34'%20height='34'%20viewBox='0%200%2034%2034'%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%3e%3cpath%20d='M30.2867%201.36768H3.71202C2.41701%201.36768%201.36719%202.41749%201.36719%203.7125V30.2872C1.36719%2031.5823%202.41701%2032.632%203.71202%2032.632H30.2867C31.5818%2032.632%2032.6316%2031.5823%2032.6316%2030.2872V3.7125C32.6316%202.41749%2031.5818%201.36768%2030.2867%201.36768Z'%20stroke='%232EAF4A'%20stroke-width='2'%20stroke-linejoin='round'/%3e%3cpath%20d='M7.62012%2013.134C10.2189%2010.0076%2013.3453%208.44434%2016.9994%208.44434C20.6535%208.44434%2023.78%2010.0076%2026.3787%2013.134'%20stroke='%232EAF4A'%20stroke-width='2'%20stroke-linecap='round'/%3e%3cpath%20d='M18.3449%2020.1261C18.3449%2020.8688%2017.7429%2021.4709%2017.0001%2021.4709C16.2573%2021.4709%2015.6553%2020.8688%2015.6553%2020.1261C15.6553%2019.3833%2016.2573%2018.7812%2017.0001%2018.7812C17.7429%2018.7812%2018.3449%2019.3833%2018.3449%2020.1261Z'%20fill='white'%20stroke='%232EAF4A'%20stroke-width='2'/%3e%3cpath%20d='M13.0918%2014.6548L17.0063%2020.126'%20stroke='%232EAF4A'%20stroke-width='2'%20stroke-linecap='round'/%3e%3c/svg%3e`,C=m(a()),w=b(),ve=()=>{let[e,t]=(0,C.useState)([]),[n,r]=(0,C.useState)(``),i=c(_);return(0,C.useEffect)(()=>{i&&r(i)},[i]),(0,C.useEffect)(()=>{n&&h.vitalData(n,t)},[n]),(0,w.jsx)(w.Fragment,{children:(0,w.jsx)(x,{children:(0,w.jsxs)(u,{xs:12,md:12,lg:12,children:[(0,w.jsx)(`div`,{className:`header-card-title mb-3`,children:(0,w.jsx)(`h5`,{className:`mb-0 page-name fw-bold`,children:`Vitals`})}),(0,w.jsxs)(x,{children:[(0,w.jsx)(u,{xs:12,md:6,lg:3,children:(0,w.jsx)(S,{body:!0,className:`mb-3 mb-lg-4 border-0 relative shadow-sm`,children:(0,w.jsxs)(`div`,{className:`vitals-card`,children:[(0,w.jsxs)(`div`,{className:`vitals-card-content d-flex gap-3 align-items-center`,children:[(0,w.jsx)(`span`,{className:`vitals-icon pulserate-bg d-inline-flex align-items-center justify-content-center`,children:(0,w.jsx)(`img`,{src:he,alt:`Icon`,className:`vitals-icon-image`})}),(0,w.jsxs)(`div`,{className:`vitals-unit`,children:[(0,w.jsx)(`span`,{className:`vitals-unit-count d-inline-block`,children:e?.[0]?.pulseRate}),(0,w.jsx)(`span`,{className:`vitals-unit-result d-inline-block ms-2`,children:`bpm`})]})]}),(0,w.jsx)(`h5`,{className:`vitals-name mt-3`,children:`Pulse/Heart Rate`})]})})}),(0,w.jsx)(u,{xs:12,md:6,lg:3,children:(0,w.jsx)(S,{body:!0,className:`mb-3 mb-lg-4 border-0 relative shadow-sm`,children:(0,w.jsxs)(`div`,{className:`vitals-card`,children:[(0,w.jsxs)(`div`,{className:`vitals-card-content d-flex gap-3 align-items-center`,children:[(0,w.jsx)(`span`,{className:`vitals-icon bloodpressure-bg d-inline-flex align-items-center justify-content-center`,children:(0,w.jsx)(`img`,{src:fe,alt:`Icon`,className:`vitals-icon-image`})}),(0,w.jsxs)(`div`,{className:`vitals-unit`,children:[(0,w.jsx)(`span`,{className:`vitals-unit-count d-inline-block`,children:e?.[0]?.bloodPressure}),(0,w.jsx)(`span`,{className:`vitals-unit-result d-inline-block ms-2`,children:`mmHg`})]})]}),(0,w.jsx)(`h5`,{className:`vitals-name mt-3`,children:`Blood Pressure Systolic/Diastolic`})]})})}),(0,w.jsx)(u,{xs:12,md:6,lg:3,children:(0,w.jsx)(S,{body:!0,className:`mb-3 mb-lg-4 border-0 relative shadow-sm`,children:(0,w.jsxs)(`div`,{className:`vitals-card`,children:[(0,w.jsxs)(`div`,{className:`vitals-card-content d-flex gap-3 align-items-center`,children:[(0,w.jsx)(`span`,{className:`vitals-icon bloodglucose-bg d-inline-flex align-items-center justify-content-center`,children:(0,w.jsx)(`img`,{src:ue,alt:`Icon`,className:`vitals-icon-image`})}),(0,w.jsxs)(`div`,{className:`vitals-unit`,children:[(0,w.jsx)(`span`,{className:`vitals-unit-count d-inline-block`,children:e?.[0]?.bloodGlucoseLevel}),(0,w.jsx)(`span`,{className:`vitals-unit-result d-inline-block ms-2`,children:`mm/dl`})]})]}),(0,w.jsx)(`h5`,{className:`vitals-name mt-3`,children:`Blood Glucose Level`})]})})}),(0,w.jsx)(u,{xs:12,md:6,lg:3,children:(0,w.jsx)(S,{body:!0,className:`mb-3 mb-lg-4 border-0 relative shadow-sm`,children:(0,w.jsxs)(`div`,{className:`vitals-card`,children:[(0,w.jsxs)(`div`,{className:`vitals-card-content d-flex gap-3 align-items-center`,children:[(0,w.jsx)(`span`,{className:`vitals-icon bodytemperature-bg d-inline-flex align-items-center justify-content-center`,children:(0,w.jsx)(`img`,{src:pe,alt:`Icon`,className:`vitals-icon-image`})}),(0,w.jsxs)(`div`,{className:`vitals-unit`,children:[(0,w.jsx)(`span`,{className:`vitals-unit-count d-inline-block`,children:e?.[0]?.bodyTemperature}),(0,w.jsx)(`span`,{className:`vitals-unit-result d-inline-block ms-2`,children:`° F`})]})]}),(0,w.jsx)(`h5`,{className:`vitals-name mt-3`,children:`Body Temperature`})]})})}),(0,w.jsx)(u,{xs:12,md:6,lg:3,children:(0,w.jsx)(S,{body:!0,className:`mb-3 mb-lg-4 border-0 relative shadow-sm`,children:(0,w.jsxs)(`div`,{className:`vitals-card`,children:[(0,w.jsxs)(`div`,{className:`vitals-card-content d-flex gap-3 align-items-center`,children:[(0,w.jsx)(`span`,{className:`vitals-icon respirationrate-bg d-inline-flex align-items-center justify-content-center`,children:(0,w.jsx)(`img`,{src:ge,alt:`Icon`,className:`vitals-icon-image`})}),(0,w.jsxs)(`div`,{className:`vitals-unit`,children:[(0,w.jsx)(`span`,{className:`vitals-unit-count d-inline-block`,children:e?.[0]?.respirationRate}),(0,w.jsx)(`span`,{className:`vitals-unit-result d-inline-block ms-2`,children:`bpm`})]})]}),(0,w.jsx)(`h5`,{className:`vitals-name mt-3`,children:`Respiration Rate`})]})})}),(0,w.jsx)(u,{xs:12,md:6,lg:3,children:(0,w.jsx)(S,{body:!0,className:`mb-3 mb-lg-4 border-0 relative shadow-sm`,children:(0,w.jsxs)(`div`,{className:`vitals-card`,children:[(0,w.jsxs)(`div`,{className:`vitals-card-content d-flex gap-3 align-items-center`,children:[(0,w.jsx)(`span`,{className:`vitals-icon bloodoxygen-bg d-inline-flex align-items-center justify-content-center`,children:(0,w.jsx)(`img`,{src:de,alt:`Icon`,className:`vitals-icon-image`})}),(0,w.jsxs)(`div`,{className:`vitals-unit`,children:[(0,w.jsx)(`span`,{className:`vitals-unit-count d-inline-block`,children:e?.[0]?.bloodOxygen}),(0,w.jsx)(`span`,{className:`vitals-unit-result d-inline-block ms-2`,children:`%`})]})]}),(0,w.jsx)(`h5`,{className:`vitals-name mt-3`,children:`Blood Oxygen`})]})})}),(0,w.jsx)(u,{xs:12,md:6,lg:3,children:(0,w.jsx)(S,{body:!0,className:`mb-3 mb-lg-4 border-0 relative shadow-sm`,children:(0,w.jsxs)(`div`,{className:`vitals-card`,children:[(0,w.jsxs)(`div`,{className:`vitals-card-content d-flex gap-3 align-items-center`,children:[(0,w.jsx)(`span`,{className:`vitals-icon weight-bg d-inline-flex align-items-center justify-content-center`,children:(0,w.jsx)(`img`,{src:_e,alt:`Icon`,className:`vitals-icon-image`})}),(0,w.jsxs)(`div`,{className:`vitals-unit`,children:[(0,w.jsx)(`span`,{className:`vitals-unit-count d-inline-block`,children:e?.[0]?.weight}),(0,w.jsx)(`span`,{className:`vitals-unit-result d-inline-block ms-2`,children:`lbs`})]})]}),(0,w.jsx)(`h5`,{className:`vitals-name mt-3`,children:`Weight`})]})})}),(0,w.jsx)(u,{xs:12,md:6,lg:3,children:(0,w.jsx)(S,{body:!0,className:`mb-3 mb-lg-4 border-0 relative shadow-sm`,children:(0,w.jsxs)(`div`,{className:`vitals-card`,children:[(0,w.jsxs)(`div`,{className:`vitals-card-content d-flex gap-3 align-items-center`,children:[(0,w.jsx)(`span`,{className:`vitals-icon height-bg d-inline-flex align-items-center justify-content-center`,children:(0,w.jsx)(`img`,{src:me,alt:`Icon`,className:`vitals-icon-image`})}),(0,w.jsxs)(`div`,{className:`vitals-unit`,children:[(0,w.jsx)(`span`,{className:`vitals-unit-count d-inline-block`,children:e?.[0]?.height}),(0,w.jsx)(`span`,{className:`vitals-unit-result d-inline-block ms-2`,children:`ft/inch`})]})]}),(0,w.jsx)(`h5`,{className:`vitals-name mt-3`,children:`Height`})]})})})]})]})})})},ye=()=>{},be={},xe={},Se=null,Ce={mark:ye,measure:ye};try{typeof window<`u`&&(be=window),typeof document<`u`&&(xe=document),typeof MutationObserver<`u`&&(Se=MutationObserver),typeof performance<`u`&&(Ce=performance)}catch{}var{userAgent:we=``}=be.navigator||{},T=be,E=xe,Te=Se,Ee=Ce;T.document;var D=!!E.documentElement&&!!E.head&&typeof E.addEventListener==`function`&&typeof E.createElement==`function`,De=~we.indexOf(`MSIE`)||~we.indexOf(`Trident/`),O=`classic`,Oe=`duotone`,k=`sharp`,A=`sharp-duotone`,ke=[O,Oe,k,A],Ae={classic:{900:`fas`,400:`far`,normal:`far`,300:`fal`,100:`fat`},sharp:{900:`fass`,400:`fasr`,300:`fasl`,100:`fast`},"sharp-duotone":{900:`fasds`}},je={kit:{fak:`kit`,"fa-kit":`kit`},"kit-duotone":{fakd:`kit-duotone`,"fa-kit-duotone":`kit-duotone`}},Me=[`kit`],Ne=/fa(s|r|l|t|d|b|k|kd|ss|sr|sl|st|sds)?[\-\ ]/,Pe=/Font ?Awesome ?([56 ]*)(Solid|Regular|Light|Thin|Duotone|Brands|Free|Pro|Sharp Duotone|Sharp|Kit)?.*/i,Fe={"Font Awesome 5 Free":{900:`fas`,400:`far`},"Font Awesome 5 Pro":{900:`fas`,400:`far`,normal:`far`,300:`fal`},"Font Awesome 5 Brands":{400:`fab`,normal:`fab`},"Font Awesome 5 Duotone":{900:`fad`}},Ie={"Font Awesome 6 Free":{900:`fas`,400:`far`},"Font Awesome 6 Pro":{900:`fas`,400:`far`,normal:`far`,300:`fal`,100:`fat`},"Font Awesome 6 Brands":{400:`fab`,normal:`fab`},"Font Awesome 6 Duotone":{900:`fad`},"Font Awesome 6 Sharp":{900:`fass`,400:`fasr`,normal:`fasr`,300:`fasl`,100:`fast`},"Font Awesome 6 Sharp Duotone":{900:`fasds`}},Le={classic:{"fa-brands":`fab`,"fa-duotone":`fad`,"fa-light":`fal`,"fa-regular":`far`,"fa-solid":`fas`,"fa-thin":`fat`},sharp:{"fa-solid":`fass`,"fa-regular":`fasr`,"fa-light":`fasl`,"fa-thin":`fast`},"sharp-duotone":{"fa-solid":`fasds`}},Re={classic:[`fas`,`far`,`fal`,`fat`],sharp:[`fass`,`fasr`,`fasl`,`fast`],"sharp-duotone":[`fasds`]},ze={classic:{fab:`fa-brands`,fad:`fa-duotone`,fal:`fa-light`,far:`fa-regular`,fas:`fa-solid`,fat:`fa-thin`},sharp:{fass:`fa-solid`,fasr:`fa-regular`,fasl:`fa-light`,fast:`fa-thin`},"sharp-duotone":{fasds:`fa-solid`}},Be={classic:{solid:`fas`,regular:`far`,light:`fal`,thin:`fat`,duotone:`fad`,brands:`fab`},sharp:{solid:`fass`,regular:`fasr`,light:`fasl`,thin:`fast`},"sharp-duotone":{solid:`fasds`}},Ve={classic:{fa:`solid`,fas:`solid`,"fa-solid":`solid`,far:`regular`,"fa-regular":`regular`,fal:`light`,"fa-light":`light`,fat:`thin`,"fa-thin":`thin`,fad:`duotone`,"fa-duotone":`duotone`,fab:`brands`,"fa-brands":`brands`},sharp:{fa:`solid`,fass:`solid`,"fa-solid":`solid`,fasr:`regular`,"fa-regular":`regular`,fasl:`light`,"fa-light":`light`,fast:`thin`,"fa-thin":`thin`},"sharp-duotone":{fa:`solid`,fasds:`solid`,"fa-solid":`solid`}},He=[`solid`,`regular`,`light`,`thin`,`duotone`,`brands`],Ue=[1,2,3,4,5,6,7,8,9,10],We=Ue.concat([11,12,13,14,15,16,17,18,19,20]),Ge={GROUP:`duotone-group`,SWAP_OPACITY:`swap-opacity`,PRIMARY:`primary`,SECONDARY:`secondary`},Ke=[...Object.keys(Re),...He,`2xs`,`xs`,`sm`,`lg`,`xl`,`2xl`,`beat`,`border`,`fade`,`beat-fade`,`bounce`,`flip-both`,`flip-horizontal`,`flip-vertical`,`flip`,`fw`,`inverse`,`layers-counter`,`layers-text`,`layers`,`li`,`pull-left`,`pull-right`,`pulse`,`rotate-180`,`rotate-270`,`rotate-90`,`rotate-by`,`shake`,`spin-pulse`,`spin-reverse`,`spin`,`stack-1x`,`stack-2x`,`stack`,`ul`,Ge.GROUP,Ge.SWAP_OPACITY,Ge.PRIMARY,Ge.SECONDARY].concat(Ue.map(e=>`${e}x`),We.map(e=>`w-${e}`)),qe={"Font Awesome Kit":{400:`fak`,normal:`fak`},"Font Awesome Kit Duotone":{400:`fakd`,normal:`fakd`}},Je={kit:{"fa-kit":`fak`},"kit-duotone":{"fa-kit-duotone":`fakd`}},Ye={kit:{fak:`fa-kit`},"kit-duotone":{fakd:`fa-kit-duotone`}},Xe={kit:{kit:`fak`},"kit-duotone":{"kit-duotone":`fakd`}},j=`___FONT_AWESOME___`,Ze=16,Qe=`fa`,$e=`svg-inline--fa`,M=`data-fa-i2svg`,et=`data-fa-pseudo-element`,tt=`data-fa-pseudo-element-pending`,nt=`data-prefix`,rt=`data-icon`,it=`fontawesome-i2svg`,at=`async`,ot=[`HTML`,`HEAD`,`STYLE`,`SCRIPT`],st=(()=>{try{return!0}catch{return!1}})(),ct=[O,k,A];function lt(e){return new Proxy(e,{get(e,t){return t in e?e[t]:e[O]}})}var ut={...Ve};ut[O]={...Ve[O],...je.kit,...je[`kit-duotone`]};var N=lt(ut),dt={...Be};dt[O]={...dt[O],...Xe.kit,...Xe[`kit-duotone`]};var ft=lt(dt),pt={...ze};pt[O]={...pt[O],...Ye.kit};var P=lt(pt),mt={...Le};mt[O]={...mt[O],...Je.kit};var ht=lt(mt),gt=Ne,_t=`fa-layers-text`,vt=Pe;lt({...Ae});var yt=[`class`,`data-prefix`,`data-icon`,`data-fa-transform`,`data-fa-mask`],bt=Ge,F=new Set;Object.keys(ft[O]).map(F.add.bind(F)),Object.keys(ft[k]).map(F.add.bind(F)),Object.keys(ft[A]).map(F.add.bind(F));var xt=[...Me,...Ke],St=T.FontAwesomeConfig||{};function Ct(e){var t=E.querySelector(`script[`+e+`]`);if(t)return t.getAttribute(e)}function wt(e){return e===``?!0:e===`false`?!1:e===`true`?!0:e}E&&typeof E.querySelector==`function`&&[[`data-family-prefix`,`familyPrefix`],[`data-css-prefix`,`cssPrefix`],[`data-family-default`,`familyDefault`],[`data-style-default`,`styleDefault`],[`data-replacement-class`,`replacementClass`],[`data-auto-replace-svg`,`autoReplaceSvg`],[`data-auto-add-css`,`autoAddCss`],[`data-auto-a11y`,`autoA11y`],[`data-search-pseudo-elements`,`searchPseudoElements`],[`data-observe-mutations`,`observeMutations`],[`data-mutate-approach`,`mutateApproach`],[`data-keep-original-source`,`keepOriginalSource`],[`data-measure-performance`,`measurePerformance`],[`data-show-missing-icons`,`showMissingIcons`]].forEach(e=>{let[t,n]=e,r=wt(Ct(t));r!=null&&(St[n]=r)});var Tt={styleDefault:`solid`,familyDefault:`classic`,cssPrefix:Qe,replacementClass:$e,autoReplaceSvg:!0,autoAddCss:!0,autoA11y:!0,searchPseudoElements:!1,observeMutations:!0,mutateApproach:`async`,keepOriginalSource:!0,measurePerformance:!1,showMissingIcons:!0};St.familyPrefix&&(St.cssPrefix=St.familyPrefix);var I={...Tt,...St};I.autoReplaceSvg||(I.observeMutations=!1);var L={};Object.keys(Tt).forEach(e=>{Object.defineProperty(L,e,{enumerable:!0,set:function(t){I[e]=t,Et.forEach(e=>e(L))},get:function(){return I[e]}})}),Object.defineProperty(L,"familyPrefix",{enumerable:!0,set:function(e){I.cssPrefix=e,Et.forEach(e=>e(L))},get:function(){return I.cssPrefix}}),T.FontAwesomeConfig=L;var Et=[];function Dt(e){return Et.push(e),()=>{Et.splice(Et.indexOf(e),1)}}var R=Ze,z={size:16,x:0,y:0,rotate:0,flipX:!1,flipY:!1};function Ot(e){if(!e||!D)return;let t=E.createElement(`style`);t.setAttribute(`type`,`text/css`),t.innerHTML=e;let n=E.head.childNodes,r=null;for(let e=n.length-1;e>-1;e--){let t=n[e],i=(t.tagName||``).toUpperCase();[`STYLE`,`LINK`].indexOf(i)>-1&&(r=t)}return E.head.insertBefore(t,r),e}var kt=`0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ`;function At(){let e=12,t=``;for(;e-- >0;)t+=kt[Math.random()*62|0];return t}function B(e){let t=[];for(let n=(e||[]).length>>>0;n--;)t[n]=e[n];return t}function jt(e){return e.classList?B(e.classList):(e.getAttribute(`class`)||``).split(` `).filter(e=>e)}function Mt(e){return`${e}`.replace(/&/g,`&amp;`).replace(/"/g,`&quot;`).replace(/'/g,`&#39;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`)}function Nt(e){return Object.keys(e||{}).reduce((t,n)=>t+`${n}="${Mt(e[n])}" `,``).trim()}function Pt(e){return Object.keys(e||{}).reduce((t,n)=>t+`${n}: ${e[n].trim()};`,``)}function Ft(e){return e.size!==z.size||e.x!==z.x||e.y!==z.y||e.rotate!==z.rotate||e.flipX||e.flipY}function It(e){let{transform:t,containerWidth:n,iconWidth:r}=e;return{outer:{transform:`translate(${n/2} 256)`},inner:{transform:`${`translate(${t.x*32}, ${t.y*32}) `} ${`scale(${t.size/16*(t.flipX?-1:1)}, ${t.size/16*(t.flipY?-1:1)}) `} ${`rotate(${t.rotate} 0 0)`}`},path:{transform:`translate(${r/2*-1} -256)`}}}function Lt(e){let{transform:t,width:n=Ze,height:r=Ze,startCentered:i=!1}=e,a=``;return i&&De?a+=`translate(${t.x/R-n/2}em, ${t.y/R-r/2}em) `:i?a+=`translate(calc(-50% + ${t.x/R}em), calc(-50% + ${t.y/R}em)) `:a+=`translate(${t.x/R}em, ${t.y/R}em) `,a+=`scale(${t.size/R*(t.flipX?-1:1)}, ${t.size/R*(t.flipY?-1:1)}) `,a+=`rotate(${t.rotate}deg) `,a}var Rt=`:root, :host {
  --fa-font-solid: normal 900 1em/1 "Font Awesome 6 Free";
  --fa-font-regular: normal 400 1em/1 "Font Awesome 6 Free";
  --fa-font-light: normal 300 1em/1 "Font Awesome 6 Pro";
  --fa-font-thin: normal 100 1em/1 "Font Awesome 6 Pro";
  --fa-font-duotone: normal 900 1em/1 "Font Awesome 6 Duotone";
  --fa-font-brands: normal 400 1em/1 "Font Awesome 6 Brands";
  --fa-font-sharp-solid: normal 900 1em/1 "Font Awesome 6 Sharp";
  --fa-font-sharp-regular: normal 400 1em/1 "Font Awesome 6 Sharp";
  --fa-font-sharp-light: normal 300 1em/1 "Font Awesome 6 Sharp";
  --fa-font-sharp-thin: normal 100 1em/1 "Font Awesome 6 Sharp";
  --fa-font-sharp-duotone-solid: normal 900 1em/1 "Font Awesome 6 Sharp Duotone";
}

svg:not(:root).svg-inline--fa, svg:not(:host).svg-inline--fa {
  overflow: visible;
  box-sizing: content-box;
}

.svg-inline--fa {
  display: var(--fa-display, inline-block);
  height: 1em;
  overflow: visible;
  vertical-align: -0.125em;
}
.svg-inline--fa.fa-2xs {
  vertical-align: 0.1em;
}
.svg-inline--fa.fa-xs {
  vertical-align: 0em;
}
.svg-inline--fa.fa-sm {
  vertical-align: -0.0714285705em;
}
.svg-inline--fa.fa-lg {
  vertical-align: -0.2em;
}
.svg-inline--fa.fa-xl {
  vertical-align: -0.25em;
}
.svg-inline--fa.fa-2xl {
  vertical-align: -0.3125em;
}
.svg-inline--fa.fa-pull-left {
  margin-right: var(--fa-pull-margin, 0.3em);
  width: auto;
}
.svg-inline--fa.fa-pull-right {
  margin-left: var(--fa-pull-margin, 0.3em);
  width: auto;
}
.svg-inline--fa.fa-li {
  width: var(--fa-li-width, 2em);
  top: 0.25em;
}
.svg-inline--fa.fa-fw {
  width: var(--fa-fw-width, 1.25em);
}

.fa-layers svg.svg-inline--fa {
  bottom: 0;
  left: 0;
  margin: auto;
  position: absolute;
  right: 0;
  top: 0;
}

.fa-layers-counter, .fa-layers-text {
  display: inline-block;
  position: absolute;
  text-align: center;
}

.fa-layers {
  display: inline-block;
  height: 1em;
  position: relative;
  text-align: center;
  vertical-align: -0.125em;
  width: 1em;
}
.fa-layers svg.svg-inline--fa {
  transform-origin: center center;
}

.fa-layers-text {
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  transform-origin: center center;
}

.fa-layers-counter {
  background-color: var(--fa-counter-background-color, #ff253a);
  border-radius: var(--fa-counter-border-radius, 1em);
  box-sizing: border-box;
  color: var(--fa-inverse, #fff);
  line-height: var(--fa-counter-line-height, 1);
  max-width: var(--fa-counter-max-width, 5em);
  min-width: var(--fa-counter-min-width, 1.5em);
  overflow: hidden;
  padding: var(--fa-counter-padding, 0.25em 0.5em);
  right: var(--fa-right, 0);
  text-overflow: ellipsis;
  top: var(--fa-top, 0);
  transform: scale(var(--fa-counter-scale, 0.25));
  transform-origin: top right;
}

.fa-layers-bottom-right {
  bottom: var(--fa-bottom, 0);
  right: var(--fa-right, 0);
  top: auto;
  transform: scale(var(--fa-layers-scale, 0.25));
  transform-origin: bottom right;
}

.fa-layers-bottom-left {
  bottom: var(--fa-bottom, 0);
  left: var(--fa-left, 0);
  right: auto;
  top: auto;
  transform: scale(var(--fa-layers-scale, 0.25));
  transform-origin: bottom left;
}

.fa-layers-top-right {
  top: var(--fa-top, 0);
  right: var(--fa-right, 0);
  transform: scale(var(--fa-layers-scale, 0.25));
  transform-origin: top right;
}

.fa-layers-top-left {
  left: var(--fa-left, 0);
  right: auto;
  top: var(--fa-top, 0);
  transform: scale(var(--fa-layers-scale, 0.25));
  transform-origin: top left;
}

.fa-1x {
  font-size: 1em;
}

.fa-2x {
  font-size: 2em;
}

.fa-3x {
  font-size: 3em;
}

.fa-4x {
  font-size: 4em;
}

.fa-5x {
  font-size: 5em;
}

.fa-6x {
  font-size: 6em;
}

.fa-7x {
  font-size: 7em;
}

.fa-8x {
  font-size: 8em;
}

.fa-9x {
  font-size: 9em;
}

.fa-10x {
  font-size: 10em;
}

.fa-2xs {
  font-size: 0.625em;
  line-height: 0.1em;
  vertical-align: 0.225em;
}

.fa-xs {
  font-size: 0.75em;
  line-height: 0.0833333337em;
  vertical-align: 0.125em;
}

.fa-sm {
  font-size: 0.875em;
  line-height: 0.0714285718em;
  vertical-align: 0.0535714295em;
}

.fa-lg {
  font-size: 1.25em;
  line-height: 0.05em;
  vertical-align: -0.075em;
}

.fa-xl {
  font-size: 1.5em;
  line-height: 0.0416666682em;
  vertical-align: -0.125em;
}

.fa-2xl {
  font-size: 2em;
  line-height: 0.03125em;
  vertical-align: -0.1875em;
}

.fa-fw {
  text-align: center;
  width: 1.25em;
}

.fa-ul {
  list-style-type: none;
  margin-left: var(--fa-li-margin, 2.5em);
  padding-left: 0;
}
.fa-ul > li {
  position: relative;
}

.fa-li {
  left: calc(-1 * var(--fa-li-width, 2em));
  position: absolute;
  text-align: center;
  width: var(--fa-li-width, 2em);
  line-height: inherit;
}

.fa-border {
  border-color: var(--fa-border-color, #eee);
  border-radius: var(--fa-border-radius, 0.1em);
  border-style: var(--fa-border-style, solid);
  border-width: var(--fa-border-width, 0.08em);
  padding: var(--fa-border-padding, 0.2em 0.25em 0.15em);
}

.fa-pull-left {
  float: left;
  margin-right: var(--fa-pull-margin, 0.3em);
}

.fa-pull-right {
  float: right;
  margin-left: var(--fa-pull-margin, 0.3em);
}

.fa-beat {
  animation-name: fa-beat;
  animation-delay: var(--fa-animation-delay, 0s);
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 1s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, ease-in-out);
}

.fa-bounce {
  animation-name: fa-bounce;
  animation-delay: var(--fa-animation-delay, 0s);
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 1s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.28, 0.84, 0.42, 1));
}

.fa-fade {
  animation-name: fa-fade;
  animation-delay: var(--fa-animation-delay, 0s);
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 1s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
}

.fa-beat-fade {
  animation-name: fa-beat-fade;
  animation-delay: var(--fa-animation-delay, 0s);
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 1s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
}

.fa-flip {
  animation-name: fa-flip;
  animation-delay: var(--fa-animation-delay, 0s);
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 1s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, ease-in-out);
}

.fa-shake {
  animation-name: fa-shake;
  animation-delay: var(--fa-animation-delay, 0s);
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 1s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, linear);
}

.fa-spin {
  animation-name: fa-spin;
  animation-delay: var(--fa-animation-delay, 0s);
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 2s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, linear);
}

.fa-spin-reverse {
  --fa-animation-direction: reverse;
}

.fa-pulse,
.fa-spin-pulse {
  animation-name: fa-spin;
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 1s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, steps(8));
}

@media (prefers-reduced-motion: reduce) {
  .fa-beat,
.fa-bounce,
.fa-fade,
.fa-beat-fade,
.fa-flip,
.fa-pulse,
.fa-shake,
.fa-spin,
.fa-spin-pulse {
    animation-delay: -1ms;
    animation-duration: 1ms;
    animation-iteration-count: 1;
    transition-delay: 0s;
    transition-duration: 0s;
  }
}
@keyframes fa-beat {
  0%, 90% {
    transform: scale(1);
  }
  45% {
    transform: scale(var(--fa-beat-scale, 1.25));
  }
}
@keyframes fa-bounce {
  0% {
    transform: scale(1, 1) translateY(0);
  }
  10% {
    transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);
  }
  30% {
    transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));
  }
  50% {
    transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);
  }
  57% {
    transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));
  }
  64% {
    transform: scale(1, 1) translateY(0);
  }
  100% {
    transform: scale(1, 1) translateY(0);
  }
}
@keyframes fa-fade {
  50% {
    opacity: var(--fa-fade-opacity, 0.4);
  }
}
@keyframes fa-beat-fade {
  0%, 100% {
    opacity: var(--fa-beat-fade-opacity, 0.4);
    transform: scale(1);
  }
  50% {
    opacity: 1;
    transform: scale(var(--fa-beat-fade-scale, 1.125));
  }
}
@keyframes fa-flip {
  50% {
    transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));
  }
}
@keyframes fa-shake {
  0% {
    transform: rotate(-15deg);
  }
  4% {
    transform: rotate(15deg);
  }
  8%, 24% {
    transform: rotate(-18deg);
  }
  12%, 28% {
    transform: rotate(18deg);
  }
  16% {
    transform: rotate(-22deg);
  }
  20% {
    transform: rotate(22deg);
  }
  32% {
    transform: rotate(-12deg);
  }
  36% {
    transform: rotate(12deg);
  }
  40%, 100% {
    transform: rotate(0deg);
  }
}
@keyframes fa-spin {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}
.fa-rotate-90 {
  transform: rotate(90deg);
}

.fa-rotate-180 {
  transform: rotate(180deg);
}

.fa-rotate-270 {
  transform: rotate(270deg);
}

.fa-flip-horizontal {
  transform: scale(-1, 1);
}

.fa-flip-vertical {
  transform: scale(1, -1);
}

.fa-flip-both,
.fa-flip-horizontal.fa-flip-vertical {
  transform: scale(-1, -1);
}

.fa-rotate-by {
  transform: rotate(var(--fa-rotate-angle, 0));
}

.fa-stack {
  display: inline-block;
  vertical-align: middle;
  height: 2em;
  position: relative;
  width: 2.5em;
}

.fa-stack-1x,
.fa-stack-2x {
  bottom: 0;
  left: 0;
  margin: auto;
  position: absolute;
  right: 0;
  top: 0;
  z-index: var(--fa-stack-z-index, auto);
}

.svg-inline--fa.fa-stack-1x {
  height: 1em;
  width: 1.25em;
}
.svg-inline--fa.fa-stack-2x {
  height: 2em;
  width: 2.5em;
}

.fa-inverse {
  color: var(--fa-inverse, #fff);
}

.sr-only,
.fa-sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}

.sr-only-focusable:not(:focus),
.fa-sr-only-focusable:not(:focus) {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}

.svg-inline--fa .fa-primary {
  fill: var(--fa-primary-color, currentColor);
  opacity: var(--fa-primary-opacity, 1);
}

.svg-inline--fa .fa-secondary {
  fill: var(--fa-secondary-color, currentColor);
  opacity: var(--fa-secondary-opacity, 0.4);
}

.svg-inline--fa.fa-swap-opacity .fa-primary {
  opacity: var(--fa-secondary-opacity, 0.4);
}

.svg-inline--fa.fa-swap-opacity .fa-secondary {
  opacity: var(--fa-primary-opacity, 1);
}

.svg-inline--fa mask .fa-primary,
.svg-inline--fa mask .fa-secondary {
  fill: black;
}

.fad.fa-inverse,
.fa-duotone.fa-inverse {
  color: var(--fa-inverse, #fff);
}`;function zt(){let e=Qe,t=$e,n=L.cssPrefix,r=L.replacementClass,i=Rt;if(n!==e||r!==t){let a=RegExp(`\\.${e}\\-`,`g`),o=RegExp(`\\--${e}\\-`,`g`),s=RegExp(`\\.${t}`,`g`);i=i.replace(a,`.${n}-`).replace(o,`--${n}-`).replace(s,`.${r}`)}return i}var Bt=!1;function Vt(){L.autoAddCss&&!Bt&&(Ot(zt()),Bt=!0)}var Ht={mixout(){return{dom:{css:zt,insertCss:Vt}}},hooks(){return{beforeDOMElementCreation(){Vt()},beforeI2svg(){Vt()}}}},V=T||{};V[j]||(V[j]={}),V[j].styles||(V[j].styles={}),V[j].hooks||(V[j].hooks={}),V[j].shims||(V[j].shims=[]);var H=V[j],Ut=[],Wt=function(){E.removeEventListener(`DOMContentLoaded`,Wt),Gt=1,Ut.map(e=>e())},Gt=!1;D&&(Gt=(E.documentElement.doScroll?/^loaded|^c/:/^loaded|^i|^c/).test(E.readyState),Gt||E.addEventListener(`DOMContentLoaded`,Wt));function Kt(e){D&&(Gt?setTimeout(e,0):Ut.push(e))}function qt(e){let{tag:t,attributes:n={},children:r=[]}=e;return typeof e==`string`?Mt(e):`<${t} ${Nt(n)}>${r.map(qt).join(``)}</${t}>`}function Jt(e,t,n){if(e&&e[t]&&e[t][n])return{prefix:t,iconName:n,icon:e[t][n]}}var Yt=function(e,t){return function(n,r,i,a){return e.call(t,n,r,i,a)}},Xt=function(e,t,n,r){var i=Object.keys(e),a=i.length,o=r===void 0?t:Yt(t,r),s,c,l;for(n===void 0?(s=1,l=e[i[0]]):(s=0,l=n);s<a;s++)c=i[s],l=o(l,e[c],c,e);return l};function Zt(e){let t=[],n=0,r=e.length;for(;n<r;){let i=e.charCodeAt(n++);if(i>=55296&&i<=56319&&n<r){let r=e.charCodeAt(n++);(r&64512)==56320?t.push(((i&1023)<<10)+(r&1023)+65536):(t.push(i),n--)}else t.push(i)}return t}function Qt(e){let t=Zt(e);return t.length===1?t[0].toString(16):null}function $t(e,t){let n=e.length,r=e.charCodeAt(t),i;return r>=55296&&r<=56319&&n>t+1&&(i=e.charCodeAt(t+1),i>=56320&&i<=57343)?(r-55296)*1024+i-56320+65536:r}function en(e){return Object.keys(e).reduce((t,n)=>{let r=e[n];return r.icon?t[r.iconName]=r.icon:t[n]=r,t},{})}function tn(e,t){let{skipHooks:n=!1}=arguments.length>2&&arguments[2]!==void 0?arguments[2]:{},r=en(t);typeof H.hooks.addPack==`function`&&!n?H.hooks.addPack(e,en(t)):H.styles[e]={...H.styles[e]||{},...r},e===`fas`&&tn(`fa`,t)}var{styles:U,shims:nn}=H,rn={[O]:Object.values(P[O]),[k]:Object.values(P[k]),[A]:Object.values(P[A])},an=null,on={},sn={},cn={},ln={},un={},dn={[O]:Object.keys(N[O]),[k]:Object.keys(N[k]),[A]:Object.keys(N[A])};function fn(e){return~xt.indexOf(e)}function pn(e,t){let n=t.split(`-`),r=n[0],i=n.slice(1).join(`-`);return r===e&&i!==``&&!fn(i)?i:null}var mn=()=>{let e=e=>Xt(U,(t,n,r)=>(t[r]=Xt(n,e,{}),t),{});on=e((e,t,n)=>(t[3]&&(e[t[3]]=n),t[2]&&t[2].filter(e=>typeof e==`number`).forEach(t=>{e[t.toString(16)]=n}),e)),sn=e((e,t,n)=>(e[n]=n,t[2]&&t[2].filter(e=>typeof e==`string`).forEach(t=>{e[t]=n}),e)),un=e((e,t,n)=>{let r=t[2];return e[n]=n,r.forEach(t=>{e[t]=n}),e});let t=`far`in U||L.autoFetchSvg,n=Xt(nn,(e,n)=>{let r=n[0],i=n[1],a=n[2];return i===`far`&&!t&&(i=`fas`),typeof r==`string`&&(e.names[r]={prefix:i,iconName:a}),typeof r==`number`&&(e.unicodes[r.toString(16)]={prefix:i,iconName:a}),e},{names:{},unicodes:{}});cn=n.names,ln=n.unicodes,an=bn(L.styleDefault,{family:L.familyDefault})};Dt(e=>{an=bn(e.styleDefault,{family:L.familyDefault})}),mn();function hn(e,t){return(on[e]||{})[t]}function gn(e,t){return(sn[e]||{})[t]}function W(e,t){return(un[e]||{})[t]}function _n(e){return cn[e]||{prefix:null,iconName:null}}function vn(e){let t=ln[e],n=hn(`fas`,e);return t||(n?{prefix:`fas`,iconName:n}:null)||{prefix:null,iconName:null}}function G(){return an}var yn=()=>({prefix:null,iconName:null,rest:[]});function bn(e){let{family:t=O}=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},n=N[t][e],r=ft[t][e]||ft[t][n],i=e in H.styles?e:null;return r||i||null}var xn={[O]:Object.keys(P[O]),[k]:Object.keys(P[k]),[A]:Object.keys(P[A])};function Sn(e){let{skipLookups:t=!1}=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},n={[O]:`${L.cssPrefix}-${O}`,[k]:`${L.cssPrefix}-${k}`,[A]:`${L.cssPrefix}-${A}`},r=null,i=O,a=ke.filter(e=>e!==Oe);a.forEach(t=>{(e.includes(n[t])||e.some(e=>xn[t].includes(e)))&&(i=t)});let o=e.reduce((e,o)=>{let s=pn(L.cssPrefix,o);if(U[o]?(o=rn[i].includes(o)?ht[i][o]:o,r=o,e.prefix=o):dn[i].indexOf(o)>-1?(r=o,e.prefix=bn(o,{family:i})):s?e.iconName=s:o!==L.replacementClass&&!a.some(e=>o===n[e])&&e.rest.push(o),!t&&e.prefix&&e.iconName){let t=r===`fa`?_n(e.iconName):{},n=W(e.prefix,e.iconName);t.prefix&&(r=null),e.iconName=t.iconName||n||e.iconName,e.prefix=t.prefix||e.prefix,e.prefix===`far`&&!U.far&&U.fas&&!L.autoFetchSvg&&(e.prefix=`fas`)}return e},yn());return(e.includes(`fa-brands`)||e.includes(`fab`))&&(o.prefix=`fab`),(e.includes(`fa-duotone`)||e.includes(`fad`))&&(o.prefix=`fad`),!o.prefix&&i===k&&(U.fass||L.autoFetchSvg)&&(o.prefix=`fass`,o.iconName=W(o.prefix,o.iconName)||o.iconName),!o.prefix&&i===A&&(U.fasds||L.autoFetchSvg)&&(o.prefix=`fasds`,o.iconName=W(o.prefix,o.iconName)||o.iconName),(o.prefix===`fa`||r===`fa`)&&(o.prefix=G()||`fas`),o}var Cn=class{constructor(){this.definitions={}}add(){let e=[...arguments].reduce(this._pullDefinitions,{});Object.keys(e).forEach(t=>{this.definitions[t]={...this.definitions[t]||{},...e[t]},tn(t,e[t]);let n=P[O][t];n&&tn(n,e[t]),mn()})}reset(){this.definitions={}}_pullDefinitions(e,t){let n=t.prefix&&t.iconName&&t.icon?{0:t}:t;return Object.keys(n).map(t=>{let{prefix:r,iconName:i,icon:a}=n[t],o=a[2];e[r]||(e[r]={}),o.length>0&&o.forEach(t=>{typeof t==`string`&&(e[r][t]=a)}),e[r][i]=a}),e}},wn=[],K={},q={},Tn=Object.keys(q);function En(e,t){let{mixoutsTo:n}=t;return wn=e,K={},Object.keys(q).forEach(e=>{Tn.indexOf(e)===-1&&delete q[e]}),wn.forEach(e=>{let t=e.mixout?e.mixout():{};if(Object.keys(t).forEach(e=>{typeof t[e]==`function`&&(n[e]=t[e]),typeof t[e]==`object`&&Object.keys(t[e]).forEach(r=>{n[e]||(n[e]={}),n[e][r]=t[e][r]})}),e.hooks){let t=e.hooks();Object.keys(t).forEach(e=>{K[e]||(K[e]=[]),K[e].push(t[e])})}e.provides&&e.provides(q)}),n}function Dn(e,t){var n=[...arguments].slice(2);return(K[e]||[]).forEach(e=>{t=e.apply(null,[t,...n])}),t}function J(e){var t=[...arguments].slice(1);(K[e]||[]).forEach(e=>{e.apply(null,t)})}function Y(){let e=arguments[0],t=Array.prototype.slice.call(arguments,1);return q[e]?q[e].apply(null,t):void 0}function On(e){e.prefix===`fa`&&(e.prefix=`fas`);let{iconName:t}=e,n=e.prefix||G();if(t)return t=W(n,t)||t,Jt(kn.definitions,n,t)||Jt(H.styles,n,t)}var kn=new Cn,X={noAuto:()=>{L.autoReplaceSvg=!1,L.observeMutations=!1,J(`noAuto`)},config:L,dom:{i2svg:function(){let e=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{};return D?(J(`beforeI2svg`,e),Y(`pseudoElements2svg`,e),Y(`i2svg`,e)):Promise.reject(Error(`Operation requires a DOM of some kind.`))},watch:function(){let e=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},{autoReplaceSvgRoot:t}=e;L.autoReplaceSvg===!1&&(L.autoReplaceSvg=!0),L.observeMutations=!0,Kt(()=>{An({autoReplaceSvgRoot:t}),J(`watch`,e)})}},parse:{icon:e=>{if(e===null)return null;if(typeof e==`object`&&e.prefix&&e.iconName)return{prefix:e.prefix,iconName:W(e.prefix,e.iconName)||e.iconName};if(Array.isArray(e)&&e.length===2){let t=e[1].indexOf(`fa-`)===0?e[1].slice(3):e[1],n=bn(e[0]);return{prefix:n,iconName:W(n,t)||t}}if(typeof e==`string`&&(e.indexOf(`${L.cssPrefix}-`)>-1||e.match(gt))){let t=Sn(e.split(` `),{skipLookups:!0});return{prefix:t.prefix||G(),iconName:W(t.prefix,t.iconName)||t.iconName}}if(typeof e==`string`){let t=G();return{prefix:t,iconName:W(t,e)||e}}}},library:kn,findIconDefinition:On,toHtml:qt},An=function(){let{autoReplaceSvgRoot:e=E}=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{};(Object.keys(H.styles).length>0||L.autoFetchSvg)&&D&&L.autoReplaceSvg&&X.dom.i2svg({node:e})};function jn(e,t){return Object.defineProperty(e,"abstract",{get:t}),Object.defineProperty(e,"html",{get:function(){return e.abstract.map(e=>qt(e))}}),Object.defineProperty(e,"node",{get:function(){if(!D)return;let t=E.createElement(`div`);return t.innerHTML=e.html,t.children}}),e}function Mn(e){let{children:t,main:n,mask:r,attributes:i,styles:a,transform:o}=e;if(Ft(o)&&n.found&&!r.found){let{width:e,height:t}=n,r={x:e/t/2,y:.5};i.style=Pt({...a,"transform-origin":`${r.x+o.x/16}em ${r.y+o.y/16}em`})}return[{tag:`svg`,attributes:i,children:t}]}function Nn(e){let{prefix:t,iconName:n,children:r,attributes:i,symbol:a}=e,o=a===!0?`${t}-${L.cssPrefix}-${n}`:a;return[{tag:`svg`,attributes:{style:`display: none;`},children:[{tag:`symbol`,attributes:{...i,id:o},children:r}]}]}function Pn(e){let{icons:{main:t,mask:n},prefix:r,iconName:i,transform:a,symbol:o,title:s,maskId:c,titleId:l,extra:u,watchable:d=!1}=e,{width:f,height:p}=n.found?n:t,m=r===`fak`,h=[L.replacementClass,i?`${L.cssPrefix}-${i}`:``].filter(e=>u.classes.indexOf(e)===-1).filter(e=>e!==``||!!e).concat(u.classes).join(` `),g={children:[],attributes:{...u.attributes,"data-prefix":r,"data-icon":i,class:h,role:u.attributes.role||`img`,xmlns:`http://www.w3.org/2000/svg`,viewBox:`0 0 ${f} ${p}`}},_=m&&!~u.classes.indexOf(`fa-fw`)?{width:`${f/p*16*.0625}em`}:{};d&&(g.attributes[M]=``),s&&(g.children.push({tag:`title`,attributes:{id:g.attributes[`aria-labelledby`]||`title-${l||At()}`},children:[s]}),delete g.attributes.title);let v={...g,prefix:r,iconName:i,main:t,mask:n,maskId:c,transform:a,symbol:o,styles:{..._,...u.styles}},{children:y,attributes:b}=n.found&&t.found?Y(`generateAbstractMask`,v)||{children:[],attributes:{}}:Y(`generateAbstractIcon`,v)||{children:[],attributes:{}};return v.children=y,v.attributes=b,o?Nn(v):Mn(v)}function Fn(e){let{content:t,width:n,height:r,transform:i,title:a,extra:o,watchable:s=!1}=e,c={...o.attributes,...a?{title:a}:{},class:o.classes.join(` `)};s&&(c[M]=``);let l={...o.styles};Ft(i)&&(l.transform=Lt({transform:i,startCentered:!0,width:n,height:r}),l[`-webkit-transform`]=l.transform);let u=Pt(l);u.length>0&&(c.style=u);let d=[];return d.push({tag:`span`,attributes:c,children:[t]}),a&&d.push({tag:`span`,attributes:{class:`sr-only`},children:[a]}),d}function In(e){let{content:t,title:n,extra:r}=e,i={...r.attributes,...n?{title:n}:{},class:r.classes.join(` `)},a=Pt(r.styles);a.length>0&&(i.style=a);let o=[];return o.push({tag:`span`,attributes:i,children:[t]}),n&&o.push({tag:`span`,attributes:{class:`sr-only`},children:[n]}),o}var{styles:Ln}=H;function Rn(e){let t=e[0],n=e[1],[r]=e.slice(4),i=null;return i=Array.isArray(r)?{tag:`g`,attributes:{class:`${L.cssPrefix}-${bt.GROUP}`},children:[{tag:`path`,attributes:{class:`${L.cssPrefix}-${bt.SECONDARY}`,fill:`currentColor`,d:r[0]}},{tag:`path`,attributes:{class:`${L.cssPrefix}-${bt.PRIMARY}`,fill:`currentColor`,d:r[1]}}]}:{tag:`path`,attributes:{fill:`currentColor`,d:r}},{found:!0,width:t,height:n,icon:i}}var zn={found:!1,width:512,height:512};function Bn(e,t){!st&&!L.showMissingIcons&&e&&console.error(`Icon with name "${e}" and prefix "${t}" is missing.`)}function Vn(e,t){let n=t;return t===`fa`&&L.styleDefault!==null&&(t=G()),new Promise((r,i)=>{if(n===`fa`){let n=_n(e)||{};e=n.iconName||e,t=n.prefix||t}if(e&&t&&Ln[t]&&Ln[t][e]){let n=Ln[t][e];return r(Rn(n))}Bn(e,t),r({...zn,icon:L.showMissingIcons&&e&&Y(`missingIconAbstract`)||{}})})}var Hn=()=>{},Un=L.measurePerformance&&Ee&&Ee.mark&&Ee.measure?Ee:{mark:Hn,measure:Hn},Wn=`FA "6.6.0"`,Gn=e=>(Un.mark(`${Wn} ${e} begins`),()=>Kn(e)),Kn=e=>{Un.mark(`${Wn} ${e} ends`),Un.measure(`${Wn} ${e}`,`${Wn} ${e} begins`,`${Wn} ${e} ends`)},qn={begin:Gn,end:Kn},Jn=()=>{};function Yn(e){return typeof(e.getAttribute?e.getAttribute(M):null)==`string`}function Xn(e){let t=e.getAttribute?e.getAttribute(nt):null,n=e.getAttribute?e.getAttribute(rt):null;return t&&n}function Zn(e){return e&&e.classList&&e.classList.contains&&e.classList.contains(L.replacementClass)}function Qn(){return L.autoReplaceSvg===!0?rr.replace:rr[L.autoReplaceSvg]||rr.replace}function $n(e){return E.createElementNS(`http://www.w3.org/2000/svg`,e)}function er(e){return E.createElement(e)}function tr(e){let{ceFn:t=e.tag===`svg`?$n:er}=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{};if(typeof e==`string`)return E.createTextNode(e);let n=t(e.tag);return Object.keys(e.attributes||[]).forEach(function(t){n.setAttribute(t,e.attributes[t])}),(e.children||[]).forEach(function(e){n.appendChild(tr(e,{ceFn:t}))}),n}function nr(e){let t=` ${e.outerHTML} `;return t=`${t}Font Awesome fontawesome.com `,t}var rr={replace:function(e){let t=e[0];if(t.parentNode)if(e[1].forEach(e=>{t.parentNode.insertBefore(tr(e),t)}),t.getAttribute(M)===null&&L.keepOriginalSource){let e=E.createComment(nr(t));t.parentNode.replaceChild(e,t)}else t.remove()},nest:function(e){let t=e[0],n=e[1];if(~jt(t).indexOf(L.replacementClass))return rr.replace(e);let r=RegExp(`${L.cssPrefix}-.*`);if(delete n[0].attributes.id,n[0].attributes.class){let e=n[0].attributes.class.split(` `).reduce((e,t)=>(t===L.replacementClass||t.match(r)?e.toSvg.push(t):e.toNode.push(t),e),{toNode:[],toSvg:[]});n[0].attributes.class=e.toSvg.join(` `),e.toNode.length===0?t.removeAttribute(`class`):t.setAttribute(`class`,e.toNode.join(` `))}let i=n.map(e=>qt(e)).join(`
`);t.setAttribute(M,``),t.innerHTML=i}};function ir(e){e()}function ar(e,t){let n=typeof t==`function`?t:Jn;if(e.length===0)n();else{let t=ir;L.mutateApproach===at&&(t=T.requestAnimationFrame||ir),t(()=>{let t=Qn(),r=qn.begin(`mutate`);e.map(t),r(),n()})}}var or=!1;function sr(){or=!0}function cr(){or=!1}var lr=null;function ur(e){if(!Te||!L.observeMutations)return;let{treeCallback:t=Jn,nodeCallback:n=Jn,pseudoElementsCallback:r=Jn,observeMutationsRoot:i=E}=e;lr=new Te(e=>{if(or)return;let i=G();B(e).forEach(e=>{if(e.type===`childList`&&e.addedNodes.length>0&&!Yn(e.addedNodes[0])&&(L.searchPseudoElements&&r(e.target),t(e.target)),e.type===`attributes`&&e.target.parentNode&&L.searchPseudoElements&&r(e.target.parentNode),e.type===`attributes`&&Yn(e.target)&&~yt.indexOf(e.attributeName))if(e.attributeName===`class`&&Xn(e.target)){let{prefix:t,iconName:n}=Sn(jt(e.target));e.target.setAttribute(nt,t||i),n&&e.target.setAttribute(rt,n)}else Zn(e.target)&&n(e.target)})}),D&&lr.observe(i,{childList:!0,attributes:!0,characterData:!0,subtree:!0})}function dr(){lr&&lr.disconnect()}function fr(e){let t=e.getAttribute(`style`),n=[];return t&&(n=t.split(`;`).reduce((e,t)=>{let n=t.split(`:`),r=n[0],i=n.slice(1);return r&&i.length>0&&(e[r]=i.join(`:`).trim()),e},{})),n}function pr(e){let t=e.getAttribute(`data-prefix`),n=e.getAttribute(`data-icon`),r=e.innerText===void 0?``:e.innerText.trim(),i=Sn(jt(e));return i.prefix||=G(),t&&n&&(i.prefix=t,i.iconName=n),i.iconName&&i.prefix?i:(i.prefix&&r.length>0&&(i.iconName=gn(i.prefix,e.innerText)||hn(i.prefix,Qt(e.innerText))),!i.iconName&&L.autoFetchSvg&&e.firstChild&&e.firstChild.nodeType===Node.TEXT_NODE&&(i.iconName=e.firstChild.data),i)}function mr(e){let t=B(e.attributes).reduce((e,t)=>(e.name!==`class`&&e.name!==`style`&&(e[t.name]=t.value),e),{}),n=e.getAttribute(`title`),r=e.getAttribute(`data-fa-title-id`);return L.autoA11y&&(n?t[`aria-labelledby`]=`${L.replacementClass}-title-${r||At()}`:(t[`aria-hidden`]=`true`,t.focusable=`false`)),t}function hr(){return{iconName:null,title:null,titleId:null,prefix:null,transform:z,symbol:!1,mask:{iconName:null,prefix:null,rest:[]},maskId:null,extra:{classes:[],styles:{},attributes:{}}}}function gr(e){let t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{styleParser:!0},{iconName:n,prefix:r,rest:i}=pr(e),a=mr(e),o=Dn(`parseNodeAttributes`,{},e),s=t.styleParser?fr(e):[];return{iconName:n,title:e.getAttribute(`title`),titleId:e.getAttribute(`data-fa-title-id`),prefix:r,transform:z,mask:{iconName:null,prefix:null,rest:[]},maskId:null,symbol:!1,extra:{classes:i,styles:s,attributes:a},...o}}var{styles:_r}=H;function vr(e){let t=L.autoReplaceSvg===`nest`?gr(e,{styleParser:!1}):gr(e);return~t.extra.classes.indexOf(_t)?Y(`generateLayersText`,e,t):Y(`generateSvgReplacementMutation`,e,t)}var Z=new Set;ct.map(e=>{Z.add(`fa-${e}`)}),Object.keys(N[O]).map(Z.add.bind(Z)),Object.keys(N[k]).map(Z.add.bind(Z)),Object.keys(N[A]).map(Z.add.bind(Z)),Z=[...Z];function yr(e){let t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:null;if(!D)return Promise.resolve();let n=E.documentElement.classList,r=e=>n.add(`${it}-${e}`),i=e=>n.remove(`${it}-${e}`),a=L.autoFetchSvg?Z:ct.map(e=>`fa-${e}`).concat(Object.keys(_r));a.includes(`fa`)||a.push(`fa`);let o=[`.${_t}:not([${M}])`].concat(a.map(e=>`.${e}:not([${M}])`)).join(`, `);if(o.length===0)return Promise.resolve();let s=[];try{s=B(e.querySelectorAll(o))}catch{}if(s.length>0)r(`pending`),i(`complete`);else return Promise.resolve();let c=qn.begin(`onTree`),l=s.reduce((e,t)=>{try{let n=vr(t);n&&e.push(n)}catch(e){st||e.name===`MissingIcon`&&console.error(e)}return e},[]);return new Promise((e,n)=>{Promise.all(l).then(n=>{ar(n,()=>{r(`active`),r(`complete`),i(`pending`),typeof t==`function`&&t(),c(),e()})}).catch(e=>{c(),n(e)})})}function br(e){let t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:null;vr(e).then(e=>{e&&ar([e],t)})}function xr(e){return function(t){let n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},r=(t||{}).icon?t:On(t||{}),{mask:i}=n;return i&&=(i||{}).icon?i:On(i||{}),e(r,{...n,mask:i})}}var Sr=function(e){let t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},{transform:n=z,symbol:r=!1,mask:i=null,maskId:a=null,title:o=null,titleId:s=null,classes:c=[],attributes:l={},styles:u={}}=t;if(!e)return;let{prefix:d,iconName:f,icon:p}=e;return jn({type:`icon`,...e},()=>(J(`beforeDOMElementCreation`,{iconDefinition:e,params:t}),L.autoA11y&&(o?l[`aria-labelledby`]=`${L.replacementClass}-title-${s||At()}`:(l[`aria-hidden`]=`true`,l.focusable=`false`)),Pn({icons:{main:Rn(p),mask:i?Rn(i.icon):{found:!1,width:null,height:null,icon:{}}},prefix:d,iconName:f,transform:{...z,...n},symbol:r,title:o,maskId:a,titleId:s,extra:{attributes:l,styles:u,classes:c}})))},Cr={mixout(){return{icon:xr(Sr)}},hooks(){return{mutationObserverCallbacks(e){return e.treeCallback=yr,e.nodeCallback=br,e}}},provides(e){e.i2svg=function(e){let{node:t=E,callback:n=()=>{}}=e;return yr(t,n)},e.generateSvgReplacementMutation=function(e,t){let{iconName:n,title:r,titleId:i,prefix:a,transform:o,symbol:s,mask:c,maskId:l,extra:u}=t;return new Promise((t,d)=>{Promise.all([Vn(n,a),c.iconName?Vn(c.iconName,c.prefix):Promise.resolve({found:!1,width:512,height:512,icon:{}})]).then(c=>{let[d,f]=c;t([e,Pn({icons:{main:d,mask:f},prefix:a,iconName:n,transform:o,symbol:s,maskId:l,title:r,titleId:i,extra:u,watchable:!0})])}).catch(d)})},e.generateAbstractIcon=function(e){let{children:t,attributes:n,main:r,transform:i,styles:a}=e,o=Pt(a);o.length>0&&(n.style=o);let s;return Ft(i)&&(s=Y(`generateAbstractTransformGrouping`,{main:r,transform:i,containerWidth:r.width,iconWidth:r.width})),t.push(s||r.icon),{children:t,attributes:n}}}},wr={mixout(){return{layer(e){let t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},{classes:n=[]}=t;return jn({type:`layer`},()=>{J(`beforeDOMElementCreation`,{assembler:e,params:t});let r=[];return e(e=>{Array.isArray(e)?e.map(e=>{r=r.concat(e.abstract)}):r=r.concat(e.abstract)}),[{tag:`span`,attributes:{class:[`${L.cssPrefix}-layers`,...n].join(` `)},children:r}]})}}}},Tr={mixout(){return{counter(e){let t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},{title:n=null,classes:r=[],attributes:i={},styles:a={}}=t;return jn({type:`counter`,content:e},()=>(J(`beforeDOMElementCreation`,{content:e,params:t}),In({content:e.toString(),title:n,extra:{attributes:i,styles:a,classes:[`${L.cssPrefix}-layers-counter`,...r]}})))}}}},Er={mixout(){return{text(e){let t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},{transform:n=z,title:r=null,classes:i=[],attributes:a={},styles:o={}}=t;return jn({type:`text`,content:e},()=>(J(`beforeDOMElementCreation`,{content:e,params:t}),Fn({content:e,transform:{...z,...n},title:r,extra:{attributes:a,styles:o,classes:[`${L.cssPrefix}-layers-text`,...i]}})))}}},provides(e){e.generateLayersText=function(e,t){let{title:n,transform:r,extra:i}=t,a=null,o=null;if(De){let t=parseInt(getComputedStyle(e).fontSize,10),n=e.getBoundingClientRect();a=n.width/t,o=n.height/t}return L.autoA11y&&!n&&(i.attributes[`aria-hidden`]=`true`),Promise.resolve([e,Fn({content:e.innerHTML,width:a,height:o,transform:r,title:n,extra:i,watchable:!0})])}}},Dr=RegExp(`"`,`ug`),Or=[1105920,1112319],kr={FontAwesome:{normal:`fas`,400:`fas`},...Ie,...Fe,...qe},Ar=Object.keys(kr).reduce((e,t)=>(e[t.toLowerCase()]=kr[t],e),{}),jr=Object.keys(Ar).reduce((e,t)=>{let n=Ar[t];return e[t]=n[900]||[...Object.entries(n)][0][1],e},{});function Mr(e){let t=e.replace(Dr,``),n=$t(t,0),r=n>=Or[0]&&n<=Or[1],i=t.length===2?t[0]===t[1]:!1;return{value:Qt(i?t[0]:t),isSecondary:r||i}}function Nr(e,t){let n=e.replace(/^['"]|['"]$/g,``).toLowerCase(),r=parseInt(t),i=isNaN(r)?`normal`:r;return(Ar[n]||{})[i]||jr[n]}function Pr(e,t){let n=`${tt}${t.replace(`:`,`-`)}`;return new Promise((r,i)=>{if(e.getAttribute(n)!==null)return r();let a=B(e.children).filter(e=>e.getAttribute(et)===t)[0],o=T.getComputedStyle(e,t),s=o.getPropertyValue(`font-family`),c=s.match(vt),l=o.getPropertyValue(`font-weight`),u=o.getPropertyValue(`content`);if(a&&!c)return e.removeChild(a),r();if(c&&u!==`none`&&u!==``){let u=o.getPropertyValue(`content`),d=Nr(s,l),{value:f,isSecondary:p}=Mr(u),m=c[0].startsWith(`FontAwesome`),h=hn(d,f),g=h;if(m){let e=vn(f);e.iconName&&e.prefix&&(h=e.iconName,d=e.prefix)}if(h&&!p&&(!a||a.getAttribute(nt)!==d||a.getAttribute(rt)!==g)){e.setAttribute(n,g),a&&e.removeChild(a);let o=hr(),{extra:s}=o;s.attributes[et]=t,Vn(h,d).then(i=>{let a=Pn({...o,icons:{main:i,mask:yn()},prefix:d,iconName:g,extra:s,watchable:!0}),c=E.createElementNS(`http://www.w3.org/2000/svg`,`svg`);t===`::before`?e.insertBefore(c,e.firstChild):e.appendChild(c),c.outerHTML=a.map(e=>qt(e)).join(`
`),e.removeAttribute(n),r()}).catch(i)}else r()}else r()})}function Fr(e){return Promise.all([Pr(e,`::before`),Pr(e,`::after`)])}function Ir(e){return e.parentNode!==document.head&&!~ot.indexOf(e.tagName.toUpperCase())&&!e.getAttribute(et)&&(!e.parentNode||e.parentNode.tagName!==`svg`)}function Lr(e){if(D)return new Promise((t,n)=>{let r=B(e.querySelectorAll(`*`)).filter(Ir).map(Fr),i=qn.begin(`searchPseudoElements`);sr(),Promise.all(r).then(()=>{i(),cr(),t()}).catch(()=>{i(),cr(),n()})})}var Rr={hooks(){return{mutationObserverCallbacks(e){return e.pseudoElementsCallback=Lr,e}}},provides(e){e.pseudoElements2svg=function(e){let{node:t=E}=e;L.searchPseudoElements&&Lr(t)}}},zr=!1,Br={mixout(){return{dom:{unwatch(){sr(),zr=!0}}}},hooks(){return{bootstrap(){ur(Dn(`mutationObserverCallbacks`,{}))},noAuto(){dr()},watch(e){let{observeMutationsRoot:t}=e;zr?cr():ur(Dn(`mutationObserverCallbacks`,{observeMutationsRoot:t}))}}}},Vr=e=>e.toLowerCase().split(` `).reduce((e,t)=>{let n=t.toLowerCase().split(`-`),r=n[0],i=n.slice(1).join(`-`);if(r&&i===`h`)return e.flipX=!0,e;if(r&&i===`v`)return e.flipY=!0,e;if(i=parseFloat(i),isNaN(i))return e;switch(r){case`grow`:e.size+=i;break;case`shrink`:e.size-=i;break;case`left`:e.x-=i;break;case`right`:e.x+=i;break;case`up`:e.y-=i;break;case`down`:e.y+=i;break;case`rotate`:e.rotate+=i;break}return e},{size:16,x:0,y:0,flipX:!1,flipY:!1,rotate:0}),Hr={mixout(){return{parse:{transform:e=>Vr(e)}}},hooks(){return{parseNodeAttributes(e,t){let n=t.getAttribute(`data-fa-transform`);return n&&(e.transform=Vr(n)),e}}},provides(e){e.generateAbstractTransformGrouping=function(e){let{main:t,transform:n,containerWidth:r,iconWidth:i}=e,a={outer:{transform:`translate(${r/2} 256)`},inner:{transform:`${`translate(${n.x*32}, ${n.y*32}) `} ${`scale(${n.size/16*(n.flipX?-1:1)}, ${n.size/16*(n.flipY?-1:1)}) `} ${`rotate(${n.rotate} 0 0)`}`},path:{transform:`translate(${i/2*-1} -256)`}};return{tag:`g`,attributes:{...a.outer},children:[{tag:`g`,attributes:{...a.inner},children:[{tag:t.icon.tag,children:t.icon.children,attributes:{...t.icon.attributes,...a.path}}]}]}}}},Ur={x:0,y:0,width:`100%`,height:`100%`};function Wr(e){let t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:!0;return e.attributes&&(e.attributes.fill||t)&&(e.attributes.fill=`black`),e}function Gr(e){return e.tag===`g`?e.children:[e]}En([Ht,Cr,wr,Tr,Er,Rr,Br,Hr,{hooks(){return{parseNodeAttributes(e,t){let n=t.getAttribute(`data-fa-mask`),r=n?Sn(n.split(` `).map(e=>e.trim())):yn();return r.prefix||=G(),e.mask=r,e.maskId=t.getAttribute(`data-fa-mask-id`),e}}},provides(e){e.generateAbstractMask=function(e){let{children:t,attributes:n,main:r,mask:i,maskId:a,transform:o}=e,{width:s,icon:c}=r,{width:l,icon:u}=i,d=It({transform:o,containerWidth:l,iconWidth:s}),f={tag:`rect`,attributes:{...Ur,fill:`white`}},p=c.children?{children:c.children.map(Wr)}:{},m={tag:`g`,attributes:{...d.inner},children:[Wr({tag:c.tag,attributes:{...c.attributes,...d.path},...p})]},h={tag:`g`,attributes:{...d.outer},children:[m]},g=`mask-${a||At()}`,_=`clip-${a||At()}`,v={tag:`mask`,attributes:{...Ur,id:g,maskUnits:`userSpaceOnUse`,maskContentUnits:`userSpaceOnUse`},children:[f,h]},y={tag:`defs`,children:[{tag:`clipPath`,attributes:{id:_},children:Gr(u)},v]};return t.push(y,{tag:`rect`,attributes:{fill:`currentColor`,"clip-path":`url(#${_})`,mask:`url(#${g})`,...Ur}}),{children:t,attributes:n}}}},{provides(e){let t=!1;T.matchMedia&&(t=T.matchMedia(`(prefers-reduced-motion: reduce)`).matches),e.missingIconAbstract=function(){let e=[],n={fill:`currentColor`},r={attributeType:`XML`,repeatCount:`indefinite`,dur:`2s`};e.push({tag:`path`,attributes:{...n,d:`M156.5,447.7l-12.6,29.5c-18.7-9.5-35.9-21.2-51.5-34.9l22.7-22.7C127.6,430.5,141.5,440,156.5,447.7z M40.6,272H8.5 c1.4,21.2,5.4,41.7,11.7,61.1L50,321.2C45.1,305.5,41.8,289,40.6,272z M40.6,240c1.4-18.8,5.2-37,11.1-54.1l-29.5-12.6 C14.7,194.3,10,216.7,8.5,240H40.6z M64.3,156.5c7.8-14.9,17.2-28.8,28.1-41.5L69.7,92.3c-13.7,15.6-25.5,32.8-34.9,51.5 L64.3,156.5z M397,419.6c-13.9,12-29.4,22.3-46.1,30.4l11.9,29.8c20.7-9.9,39.8-22.6,56.9-37.6L397,419.6z M115,92.4 c13.9-12,29.4-22.3,46.1-30.4l-11.9-29.8c-20.7,9.9-39.8,22.6-56.8,37.6L115,92.4z M447.7,355.5c-7.8,14.9-17.2,28.8-28.1,41.5 l22.7,22.7c13.7-15.6,25.5-32.9,34.9-51.5L447.7,355.5z M471.4,272c-1.4,18.8-5.2,37-11.1,54.1l29.5,12.6 c7.5-21.1,12.2-43.5,13.6-66.8H471.4z M321.2,462c-15.7,5-32.2,8.2-49.2,9.4v32.1c21.2-1.4,41.7-5.4,61.1-11.7L321.2,462z M240,471.4c-18.8-1.4-37-5.2-54.1-11.1l-12.6,29.5c21.1,7.5,43.5,12.2,66.8,13.6V471.4z M462,190.8c5,15.7,8.2,32.2,9.4,49.2h32.1 c-1.4-21.2-5.4-41.7-11.7-61.1L462,190.8z M92.4,397c-12-13.9-22.3-29.4-30.4-46.1l-29.8,11.9c9.9,20.7,22.6,39.8,37.6,56.9 L92.4,397z M272,40.6c18.8,1.4,36.9,5.2,54.1,11.1l12.6-29.5C317.7,14.7,295.3,10,272,8.5V40.6z M190.8,50 c15.7-5,32.2-8.2,49.2-9.4V8.5c-21.2,1.4-41.7,5.4-61.1,11.7L190.8,50z M442.3,92.3L419.6,115c12,13.9,22.3,29.4,30.5,46.1 l29.8-11.9C470,128.5,457.3,109.4,442.3,92.3z M397,92.4l22.7-22.7c-15.6-13.7-32.8-25.5-51.5-34.9l-12.6,29.5 C370.4,72.1,384.4,81.5,397,92.4z`}});let i={...r,attributeName:`opacity`},a={tag:`circle`,attributes:{...n,cx:`256`,cy:`364`,r:`28`},children:[]};return t||a.children.push({tag:`animate`,attributes:{...r,attributeName:`r`,values:`28;14;28;28;14;28;`}},{tag:`animate`,attributes:{...i,values:`1;0;1;1;0;1;`}}),e.push(a),e.push({tag:`path`,attributes:{...n,opacity:`1`,d:`M263.7,312h-16c-6.6,0-12-5.4-12-12c0-71,77.4-63.9,77.4-107.8c0-20-17.8-40.2-57.4-40.2c-29.1,0-44.3,9.6-59.2,28.7 c-3.9,5-11.1,6-16.2,2.4l-13.1-9.2c-5.6-3.9-6.9-11.8-2.6-17.2c21.2-27.2,46.4-44.7,91.2-44.7c52.3,0,97.4,29.8,97.4,80.2 c0,67.6-77.4,63.5-77.4,107.8C275.7,306.6,270.3,312,263.7,312z`},children:t?[]:[{tag:`animate`,attributes:{...i,values:`1;0;0;0;0;1;`}}]}),t||e.push({tag:`path`,attributes:{...n,opacity:`0`,d:`M232.5,134.5l7,168c0.3,6.4,5.6,11.5,12,11.5h9c6.4,0,11.7-5.1,12-11.5l7-168c0.3-6.8-5.2-12.5-12-12.5h-23 C237.7,122,232.2,127.7,232.5,134.5z`},children:[{tag:`animate`,attributes:{...i,values:`0;0;1;1;0;0;`}}]}),{tag:`g`,attributes:{class:`missing`},children:e}}}},{hooks(){return{parseNodeAttributes(e,t){let n=t.getAttribute(`data-fa-symbol`);return e.symbol=n===null?!1:n===``?!0:n,e}}}}],{mixoutsTo:X}),X.noAuto,X.config,X.library,X.dom;var Kr=X.parse;X.findIconDefinition,X.toHtml;var qr=X.icon;X.layer,X.text,X.counter;var Q=m(s());function Jr(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),n.push.apply(n,r)}return n}function $(e){for(var t=1;t<arguments.length;t++){var n=arguments[t]==null?{}:arguments[t];t%2?Jr(Object(n),!0).forEach(function(t){Xr(e,t,n[t])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Jr(Object(n)).forEach(function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))})}return e}function Yr(e){"@babel/helpers - typeof";return Yr=typeof Symbol==`function`&&typeof Symbol.iterator==`symbol`?function(e){return typeof e}:function(e){return e&&typeof Symbol==`function`&&e.constructor===Symbol&&e!==Symbol.prototype?`symbol`:typeof e},Yr(e)}function Xr(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function Zr(e,t){if(e==null)return{};var n={},r=Object.keys(e),i,a;for(a=0;a<r.length;a++)i=r[a],!(t.indexOf(i)>=0)&&(n[i]=e[i]);return n}function Qr(e,t){if(e==null)return{};var n=Zr(e,t),r,i;if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);for(i=0;i<a.length;i++)r=a[i],!(t.indexOf(r)>=0)&&Object.prototype.propertyIsEnumerable.call(e,r)&&(n[r]=e[r])}return n}function $r(e){return ei(e)||ti(e)||ni(e)||ii()}function ei(e){if(Array.isArray(e))return ri(e)}function ti(e){if(typeof Symbol<`u`&&e[Symbol.iterator]!=null||e[`@@iterator`]!=null)return Array.from(e)}function ni(e,t){if(e){if(typeof e==`string`)return ri(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);if(n===`Object`&&e.constructor&&(n=e.constructor.name),n===`Map`||n===`Set`)return Array.from(e);if(n===`Arguments`||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))return ri(e,t)}}function ri(e,t){(t==null||t>e.length)&&(t=e.length);for(var n=0,r=Array(t);n<t;n++)r[n]=e[n];return r}function ii(){throw TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}function ai(e){var t,n=e.beat,r=e.fade,i=e.beatFade,a=e.bounce,o=e.shake,s=e.flash,c=e.spin,l=e.spinPulse,u=e.spinReverse,d=e.pulse,f=e.fixedWidth,p=e.inverse,m=e.border,h=e.listItem,g=e.flip,_=e.size,v=e.rotation,y=e.pull,b=(t={"fa-beat":n,"fa-fade":r,"fa-beat-fade":i,"fa-bounce":a,"fa-shake":o,"fa-flash":s,"fa-spin":c,"fa-spin-reverse":u,"fa-spin-pulse":l,"fa-pulse":d,"fa-fw":f,"fa-inverse":p,"fa-border":m,"fa-li":h,"fa-flip":g===!0,"fa-flip-horizontal":g===`horizontal`||g===`both`,"fa-flip-vertical":g===`vertical`||g===`both`},Xr(t,`fa-${_}`,_!=null),Xr(t,`fa-rotate-${v}`,v!=null&&v!==0),Xr(t,`fa-pull-${y}`,y!=null),Xr(t,`fa-swap-opacity`,e.swapOpacity),t);return Object.keys(b).map(function(e){return b[e]?e:null}).filter(function(e){return e})}function oi(e){return e-=0,e===e}function si(e){return oi(e)?e:(e=e.replace(/[\-_\s]+(.)?/g,function(e,t){return t?t.toUpperCase():``}),e.substr(0,1).toLowerCase()+e.substr(1))}var ci=[`style`];function li(e){return e.charAt(0).toUpperCase()+e.slice(1)}function ui(e){return e.split(`;`).map(function(e){return e.trim()}).filter(function(e){return e}).reduce(function(e,t){var n=t.indexOf(`:`),r=si(t.slice(0,n)),i=t.slice(n+1).trim();return r.startsWith(`webkit`)?e[li(r)]=i:e[r]=i,e},{})}function di(e,t){var n=arguments.length>2&&arguments[2]!==void 0?arguments[2]:{};if(typeof t==`string`)return t;var r=(t.children||[]).map(function(t){return di(e,t)}),i=Object.keys(t.attributes||{}).reduce(function(e,n){var r=t.attributes[n];switch(n){case`class`:e.attrs.className=r,delete t.attributes.class;break;case`style`:e.attrs.style=ui(r);break;default:n.indexOf(`aria-`)===0||n.indexOf(`data-`)===0?e.attrs[n.toLowerCase()]=r:e.attrs[si(n)]=r}return e},{attrs:{}}),a=n.style,o=a===void 0?{}:a,s=Qr(n,ci);return i.attrs.style=$($({},i.attrs.style),o),e.apply(void 0,[t.tag,$($({},i.attrs),s)].concat($r(r)))}var fi=!1;try{fi=!0}catch{}function pi(){if(!fi&&console&&typeof console.error==`function`){var e;(e=console).error.apply(e,arguments)}}function mi(e){if(e&&Yr(e)===`object`&&e.prefix&&e.iconName&&e.icon)return e;if(Kr.icon)return Kr.icon(e);if(e===null)return null;if(e&&Yr(e)===`object`&&e.prefix&&e.iconName)return e;if(Array.isArray(e)&&e.length===2)return{prefix:e[0],iconName:e[1]};if(typeof e==`string`)return{prefix:`fas`,iconName:e}}function hi(e,t){return Array.isArray(t)&&t.length>0||!Array.isArray(t)&&t?Xr({},e,t):{}}var gi={border:!1,className:``,mask:null,maskId:null,fixedWidth:!1,inverse:!1,flip:!1,icon:null,listItem:!1,pull:null,pulse:!1,rotation:null,size:null,spin:!1,spinPulse:!1,spinReverse:!1,beat:!1,fade:!1,beatFade:!1,bounce:!1,shake:!1,symbol:!1,title:``,titleId:null,transform:null,swapOpacity:!1},_i=C.forwardRef(function(e,t){var n=$($({},gi),e),r=n.icon,i=n.mask,a=n.symbol,o=n.className,s=n.title,c=n.titleId,l=n.maskId,u=mi(r),d=hi(`classes`,[].concat($r(ai(n)),$r((o||``).split(` `)))),f=hi(`transform`,typeof n.transform==`string`?Kr.transform(n.transform):n.transform),p=hi(`mask`,mi(i)),m=qr(u,$($($($({},d),f),p),{},{symbol:a,title:s,titleId:c,maskId:l}));if(!m)return pi(`Could not find icon`,u),null;var h=m.abstract,g={ref:t};return Object.keys(n).forEach(function(e){gi.hasOwnProperty(e)||(g[e]=n[e])}),vi(h[0],g)});_i.displayName=`FontAwesomeIcon`,_i.propTypes={beat:Q.default.bool,border:Q.default.bool,beatFade:Q.default.bool,bounce:Q.default.bool,className:Q.default.string,fade:Q.default.bool,flash:Q.default.bool,mask:Q.default.oneOfType([Q.default.object,Q.default.array,Q.default.string]),maskId:Q.default.string,fixedWidth:Q.default.bool,inverse:Q.default.bool,flip:Q.default.oneOf([!0,!1,`horizontal`,`vertical`,`both`]),icon:Q.default.oneOfType([Q.default.object,Q.default.array,Q.default.string]),listItem:Q.default.bool,pull:Q.default.oneOf([`right`,`left`]),pulse:Q.default.bool,rotation:Q.default.oneOf([0,90,180,270]),shake:Q.default.bool,size:Q.default.oneOf([`2xs`,`xs`,`sm`,`lg`,`xl`,`2xl`,`1x`,`2x`,`3x`,`4x`,`5x`,`6x`,`7x`,`8x`,`9x`,`10x`]),spin:Q.default.bool,spinPulse:Q.default.bool,spinReverse:Q.default.bool,symbol:Q.default.oneOfType([Q.default.bool,Q.default.string]),title:Q.default.string,titleId:Q.default.string,transform:Q.default.oneOfType([Q.default.string,Q.default.object]),swapOpacity:Q.default.bool};var vi=di.bind(null,C.createElement),yi={prefix:`fas`,iconName:`trash-can`,icon:[448,512,[61460,`trash-alt`],`f2ed`,`M135.2 17.7C140.6 6.8 151.7 0 163.8 0L284.2 0c12.1 0 23.2 6.8 28.6 17.7L320 32l96 0c17.7 0 32 14.3 32 32s-14.3 32-32 32L32 96C14.3 96 0 81.7 0 64S14.3 32 32 32l96 0 7.2-14.3zM32 128l384 0 0 320c0 35.3-28.7 64-64 64L96 512c-35.3 0-64-28.7-64-64l0-320zm96 64c-8.8 0-16 7.2-16 16l0 224c0 8.8 7.2 16 16 16s16-7.2 16-16l0-224c0-8.8-7.2-16-16-16zm96 0c-8.8 0-16 7.2-16 16l0 224c0 8.8 7.2 16 16 16s16-7.2 16-16l0-224c0-8.8-7.2-16-16-16zm96 0c-8.8 0-16 7.2-16 16l0 224c0 8.8 7.2 16 16 16s16-7.2 16-16l0-224c0-8.8-7.2-16-16-16z`]},bi={prefix:`fas`,iconName:`xmark`,icon:[384,512,[128473,10005,10006,10060,215,`close`,`multiply`,`remove`,`times`],`f00d`,`M342.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192 210.7 86.6 105.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L146.7 256 41.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192 301.3 297.4 406.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.3 256 342.6 150.6z`]},xi=[`Progress Note`,`Discharge`,`Activities of Daily Living Tracking Form`,`Financial Transactions Record`,`ART Meeting`,`Authorization for Release of Information`,`Incident Report`,`Contact Note`,`Mars`,`Medication Reconciliation`,`Medication Count`,`Informed Consent for Medications`,`PRN Medication Log`,`Mental Status`,`Refusal of Medical Treatment Form`,`Appointment Tracking Log`],Si=C.memo(e=>{let[t,r]=(0,C.useState)(``),a=ie(),[o,s]=(0,C.useState)([]),[c,l]=(0,C.useState)(!1),[f,m]=(0,C.useState)(),g=(0,C.useCallback)((e,t)=>{h.deleteDocument(t._id),s(t=>t.filter((t,n)=>e!==n))},[]),_=(0,C.useCallback)(e=>{if(e.preventDefault(),!a.file){y({message:`Please select a file`,type:`danger`});return}let n=new FormData;n.append(`type`,t),n.append(`file`,a.file),h.uploadDocument({payload:n,setArr:s,setLoading:l})},[a.file,t]);(0,C.useEffect)(()=>{e?.show&&(e?.patitentId||h.getApiResident({url:i.GET_USER_DOCUMENTS,setResponse:m}))},[e?.show,e?.patitentId]);let b=(0,C.useCallback)(async e=>{try{if(!e)return;let t=encodeURI(`${p.CLOUDFRONT_URL}${e}`);window.open(t,`_blank`)}catch(e){v.error(`Error opening document URL`,e),y({message:`Failed to open document.`,type:`danger`})}},[]);(0,C.useEffect)(()=>{f&&f.data&&s(e=>[...e,...f.data])},[f]);let ne=(0,C.useCallback)(e=>r(e),[]);return(0,w.jsx)(ae,{...e,size:`xl`,"aria-labelledby":`contained-modal-title-vcenter`,centered:!0,children:(0,w.jsx)(ae.Body,{className:`file-upload-modal`,children:(0,w.jsxs)(n,{onSubmit:_,children:[(0,w.jsxs)(`div`,{className:`close-header`,children:[(0,w.jsx)(`h5`,{children:`File Upload `}),(0,w.jsx)(_i,{icon:bi,className:`fa-xmark`,onClick:e.onHide})]}),(0,w.jsxs)(S,{body:!0,className:`mb-3 mt-3`,children:[(0,w.jsxs)(x,{children:[(0,w.jsx)(u,{xs:12,md:4,children:(0,w.jsxs)(n.Group,{className:`mb-3`,children:[(0,w.jsx)(n.Label,{className:`fw-bold`,children:`File Name`}),(0,w.jsx)(re,{options:xi,filterOnType:!0,onChange:ne})]})}),(0,w.jsx)(u,{xs:12,md:4,children:(0,w.jsxs)(n.Group,{className:`mb-3`,children:[(0,w.jsx)(n.Label,{className:`fw-bold`,children:`Choose File`}),(0,w.jsx)(n.Control,{type:`file`,onChange:a.onSelectFile})]})}),(0,w.jsx)(u,{xs:12,md:4,children:(0,w.jsxs)(n.Group,{className:`mb-3`,children:[(0,w.jsx)(n.Label,{className:`fw-bold`,children:`Upload File`}),(0,w.jsx)(`div`,{className:`d-block`,children:(0,w.jsx)(te,{className:`theme-button w-100`,type:`submit`,children:c?(0,w.jsx)(ee,{color:`#fff`}):`Upload File`})})]})})]}),(0,w.jsx)(x,{children:(0,w.jsx)(u,{xs:12,children:(0,w.jsxs)(oe,{responsive:!0,bordered:!0,className:`mt-3`,children:[(0,w.jsx)(`thead`,{children:(0,w.jsxs)(`tr`,{children:[(0,w.jsx)(`th`,{className:`text-start`,children:`Type`}),(0,w.jsx)(`th`,{className:`text-start`,children:`File`}),(0,w.jsx)(`th`,{})]})}),(0,w.jsx)(`tbody`,{children:o?.map((e,t)=>(0,w.jsxs)(`tr`,{children:[(0,w.jsxs)(`td`,{className:`text-start`,children:[` `,e.type,` `]}),(0,w.jsx)(`td`,{className:`text-start`,children:(0,w.jsx)(te,{size:`sm`,onClick:t=>{t.preventDefault(),b(e.document)},className:`delete-btn`,children:`Download File`})}),(0,w.jsx)(`td`,{children:(0,w.jsx)(`div`,{className:`icon-joiner`,children:(0,w.jsx)(d,{className:`del-btn`,children:(0,w.jsx)(_i,{icon:yi,className:`fa-solid fa-trash-can`,onClick:()=>g(t,e)})})})})]},t))})]})})})]})]})})})}),Ci=se({Wcomponenet:()=>{let[n,i]=(0,C.useState)(!1),a=c(_),s=a?.hoursFormat===`24`?`HH:mm`:`h:mm A`,d=o(),[p,m]=(0,C.useState)([]),[v,y]=(0,C.useState)(!1);(0,C.useEffect)(()=>{h.getUpcomingAppointments(m)},[]);let b=(0,C.useCallback)(()=>i(!1),[]),ee=(0,C.useCallback)(()=>i(!0),[]),re=(0,C.useCallback)(()=>{d(a?.userType===e.GUARDIAN?`/bookappointment-resident`:`/booknewappointment`)},[a?.userType,d]),ie=(0,C.useCallback)(()=>{d(`/appointmenthistory`)},[d]),ae=(0,C.useCallback)(()=>{d(`/manageappointment`)},[d]);return(0,w.jsxs)(`div`,{className:`dashboard-stats`,children:[(0,w.jsx)(ne,{fluid:!0,children:(0,w.jsx)(x,{children:(0,w.jsx)(u,{xs:12,md:12,xl:12,className:`mb-3 mb-lg-4`,children:(0,w.jsx)(S,{"no-body":!0,className:`HomePageDashboard overflow-hidden border-0`,children:(0,w.jsxs)(x,{className:`align-items-center`,children:[(0,w.jsx)(u,{xs:12,md:4,lg:4,xl:4,children:(0,w.jsxs)(`div`,{className:`position-relative z-1 text-center text-lg-start card-body`,children:[(0,w.jsxs)(`h4`,{className:`text-white fw-semibold my-md-3 mb-3 fs-4`,children:[`Welcome Back`,` `,(0,w.jsxs)(`span`,{className:`fw-normal `,children:[a&&t(a),`!`]})]}),(0,w.jsx)(`h6`,{className:`opacity-75 fw-normal text-white mb-0 fs-6`,children:`How can we help you today?`})]})}),(0,w.jsx)(u,{xs:12,md:4,lg:4,xl:4,children:(0,w.jsx)(`div`,{className:`position-relative z-1 card-body`,children:(0,w.jsx)(`div`,{className:`text-center py-lg-7`,children:(0,w.jsx)(`h4`,{className:`text-white fw-semibold text-center my-md-3 mb-3 fs-4`,children:(0,w.jsx)(`span`,{children:`Welcome to CareNote!`})})})})}),(0,w.jsx)(u,{xs:12,md:4,xl:4,className:`align-self-end text-center text-lg-right`,children:(0,w.jsx)(`div`,{className:`position-relative z-1`,children:(0,w.jsx)(`img`,{src:`/doctor-appoint.svg`,className:`img-fluid d-none d-md-inline-block float-md-end max-h-[200px]`,alt:`welcome-patient`})})})]})})})})}),(0,w.jsxs)(ne,{fluid:!0,children:[(0,w.jsxs)(x,{className:`align-items-center mb-3`,children:[(0,w.jsx)(u,{xs:12,sm:12,md:5,lg:4,children:(0,w.jsx)(`div`,{className:`header-card-title`,children:(0,w.jsx)(`h5`,{className:`mb-md-0 page-name fw-bold`,children:`Upcoming Appointments`})})}),(0,w.jsx)(u,{xs:12,sm:12,md:7,lg:8,children:(0,w.jsxs)(`div`,{className:`d-sm-flex justify-content-sm-end align-items-center gap-2`,children:[(0,w.jsx)(te,{type:`button`,className:`appointment-btn m-1 my-sm-0`,onClick:re,children:(0,w.jsxs)(`span`,{className:`d-flex align-items-center gap-2`,children:[(0,w.jsx)(f,{}),(0,w.jsx)(`span`,{className:`d-inline-block`,children:`Book New Appointment`})]})}),(0,w.jsx)(te,{type:`button`,className:`blue-theme-btn m-1 my-sm-0`,onClick:ie,children:`Appointment History`}),(0,w.jsx)(te,{type:`button`,className:`success-theme-btn m-1 my-sm-0`,onClick:ae,children:`Manage Appointment`})]})})]}),(p?.data||p)?.length>0?(0,w.jsx)(S,{body:!0,className:`mb-3 mb-lg-4 border-0 relative shadow-sm d-none`,children:`Upcoming Appointments`}):(0,w.jsx)(S,{body:!0,className:`mb-3 mb-lg-4 border-0 relative shadow-sm`,children:`No Upcoming Appointments`}),(0,w.jsx)(x,{children:v?(p?.data||p)?.map((e,t)=>(0,w.jsx)(u,{xs:12,md:12,lg:4,children:(0,w.jsx)(le,{imageUrl:e?.adminId?.profilePic?e?.adminId?.profilePic:ce,date:l(e?.date),slot:g(e?.time,s),location:e?.address})},t)):(p?.data||p)?.slice(0,6)?.map((e,t)=>(0,w.jsx)(u,{xs:12,md:12,lg:4,children:(0,w.jsx)(le,{imageUrl:e?.adminId?.profilePic?e?.adminId?.profilePic:ce,date:l(e?.date),slot:g(e?.time,s),location:e?.address})},t))}),a?.userType===e.PATIENT&&(0,w.jsx)(ve,{}),a?.userType===e.PATIENT&&(0,w.jsxs)(`div`,{className:`default-shadow-box`,children:[(0,w.jsx)(`div`,{className:`header-card-title mb-3`,children:(0,w.jsx)(`h5`,{className:`mb-0 page-name fw-bold`,children:`Upload Document`})}),(0,w.jsx)(x,{children:(0,w.jsx)(u,{sm:12,md:6,lg:3,children:(0,w.jsxs)(`button`,{onClick:ee,className:`upload-document-btn py-md-4 w-100 card text-center`,children:[(0,w.jsx)(r,{className:`mx-auto`}),(0,w.jsx)(`span`,{className:`file-upload-text d-inline-block mt-3`,children:`File Upload`})]})})})]}),(0,w.jsx)(Si,{show:n,onHide:b})]})]})}});export{Ci as default};