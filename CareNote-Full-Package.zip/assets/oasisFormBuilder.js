/**
 * Oasis Notes - Interactive Form Builder & Clinical Form Engine
 * Handles "Create New Form", Custom Forms Management, Field Designer,
 * Real-time Validation, Preview, Submission, and Seamless Resident Chart Integration.
 */

(function () {
  // Global Oasis Form Engine state
  window.OasisFormEngine = {
    customForms: [],
    templates: [],
    residents: [],
    activeModal: null, // 'builder' | 'preview' | 'fill' | 'submissions' | 'templates'
    builderState: {
      id: null,
      name: '',
      type: 'Clinical Assessment',
      category: 'Clinical Assessment',
      description: '',
      fields: []
    },
    fillState: {
      form: null,
      residentId: '',
      values: {},
      errors: {}
    },
    submissionsState: {
      form: null,
      submissions: []
    }
  };

  const FORM_TYPES = [
    'Clinical Assessment',
    'Progress Note',
    'Intake & Assessment',
    'Treatment & Care Plan',
    'Vitals & Monitoring',
    'Safety & Incident Reporting',
    'Administrative & Consent',
    'Medication-Related'
  ];

  const FIELD_TYPES = [
    { value: 'text', label: 'Short Text Input' },
    { value: 'textarea', label: 'Multiline Text Area' },
    { value: 'date', label: 'Date Selector' },
    { value: 'number', label: 'Numeric Value' },
    { value: 'select', label: 'Dropdown Selection' },
    { value: 'radio', label: 'Single Choice (Radio Buttons)' },
    { value: 'checkbox', label: 'Multiple Choice (Checkboxes)' },
    { value: 'rating', label: 'Pain / Mood Scale (1 - 10)' }
  ];

  // Helper: Get API base URL
  function getApiBase() {
    return '/api/v1';
  }

  // Helper: Show floating toast notification
  function showToast(message, type = 'success') {
    let container = document.getElementById('oasis-toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'oasis-toast-container';
      container.style.cssText = 'position:fixed;top:24px;right:24px;z-index:99999999;display:flex;flex-direction:column;gap:10px;pointer-events:none;';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    const bg = type === 'success' ? '#0f766e' : type === 'error' ? '#b91c1c' : '#1a9fb2';
    const icon = type === 'success' ? '✓' : type === 'error' ? '⚠' : 'ℹ';
    toast.style.cssText = `background:${bg};color:#fff;padding:12px 20px;border-radius:8px;font-size:14px;font-family:Quicksand,sans-serif;font-weight:600;box-shadow:0 8px 24px rgba(0,0,0,0.25);display:flex;align-items:center;gap:10px;pointer-events:auto;transition:all 0.3s cubic-bezier(0.16, 1, 0.3, 1);transform:translateX(40px);opacity:0;`;
    toast.innerHTML = `<span style="font-size:16px;">${icon}</span><span>${message}</span>`;
    container.appendChild(toast);

    requestAnimationFrame(() => {
      toast.style.transform = 'translateX(0)';
      toast.style.opacity = '1';
    });

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(-10px)';
      setTimeout(() => toast.remove(), 300);
    }, 3800);
  }

  // Load forms and templates from backend
  async function loadData() {
    try {
      const [formsRes, tplRes, resRes] = await Promise.all([
        fetch(`${getApiBase()}/custom-forms`).then(r => r.json()).catch(() => ({ data: [] })),
        fetch(`${getApiBase()}/clinical-templates`).then(r => r.json()).catch(() => ({ data: [] })),
        fetch(`${getApiBase()}/patients`).then(r => r.json()).catch(() => ({ data: { docs: [] } }))
      ]);

      if (formsRes && formsRes.success) {
        window.OasisFormEngine.customForms = formsRes.data || [];
      }
      if (tplRes && tplRes.success) {
        window.OasisFormEngine.templates = tplRes.data || [];
      }
      if (resRes && resRes.success && resRes.data) {
        window.OasisFormEngine.residents = resRes.data.docs || [];
      }

      renderCustomCardsInChart();
    } catch (e) {
      console.warn('[OasisFormEngine] Failed to load data:', e);
    }
  }

  // Open Form Builder modal
  window.oasisOpenFormBuilder = function (existingForm = null) {
    if (existingForm) {
      window.OasisFormEngine.builderState = JSON.parse(JSON.stringify(existingForm));
    } else {
      window.OasisFormEngine.builderState = {
        id: null,
        name: '',
        type: 'Clinical Assessment',
        category: 'Clinical Assessment',
        description: '',
        fields: [
          {
            id: 'field_' + Date.now(),
            name: 'resident_status',
            label: 'Resident Current Clinical Status',
            type: 'textarea',
            required: true,
            placeholder: 'Detail current observations, behavior, and orientation...'
          },
          {
            id: 'field_' + (Date.now() + 1),
            name: 'observation_date',
            label: 'Date of Observation',
            type: 'date',
            required: true,
            placeholder: ''
          }
        ]
      };
    }
    renderBuilderModal();
  };

  // Render the interactive Form Builder modal
  function renderBuilderModal() {
    let modal = document.getElementById('oasis-form-builder-modal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'oasis-form-builder-modal';
      document.body.appendChild(modal);
    }

    modal.style.cssText = 'position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(15,23,42,0.65);backdrop-filter:blur(4px);z-index:9999999;display:flex;align-items:center;justify-content:center;font-family:Quicksand,sans-serif;padding:16px;box-sizing:border-box;';

    const s = window.OasisFormEngine.builderState;

    modal.innerHTML = `
      <div style="background:#fff;border-radius:14px;width:100%;max-width:880px;max-height:92vh;display:flex;flex-direction:column;box-shadow:0 20px 48px rgba(0,0,0,0.3);overflow:hidden;animation:oasisFadeIn 0.25s ease-out;">
        <!-- Header -->
        <div style="padding:18px 24px;border-bottom:1px solid #e2e8f0;display:flex;align-items:center;justify-content:space-between;background:#f8fafc;">
          <div style="display:flex;align-items:center;gap:12px;">
            <div style="width:38px;height:38px;border-radius:8px;background:#e0f2fe;display:flex;align-items:center;justify-content:center;color:#0284c7;font-size:18px;font-weight:700;">
              📝
            </div>
            <div>
              <h4 style="margin:0;font-size:18px;font-weight:700;color:#0f172a;">${s.id ? 'Edit Clinical Form' : 'Create New Clinical Form'}</h4>
              <p style="margin:2px 0 0;font-size:12px;color:#64748b;">Build custom clinical workflows, questionnaires, assessments, or choose a standard Oasis template</p>
            </div>
          </div>
          <button id="oasis-builder-close-btn" style="background:transparent;border:none;font-size:22px;color:#94a3b8;cursor:pointer;padding:4px 8px;line-height:1;">✕</button>
        </div>

        <!-- Body tabs -->
        <div style="display:flex;border-bottom:1px solid #e2e8f0;background:#f1f5f9;padding:0 24px;">
          <button id="tab-builder-designer" style="padding:12px 18px;border:none;background:transparent;border-bottom:2px solid #1a9fb2;color:#1a9fb2;font-weight:700;font-size:14px;cursor:pointer;">Custom Form Builder</button>
          <button id="tab-builder-templates" style="padding:12px 18px;border:none;background:transparent;border-bottom:2px solid transparent;color:#64748b;font-weight:600;font-size:14px;cursor:pointer;">Standard Clinical Templates (22)</button>
        </div>

        <!-- Main Form Config and Field List -->
        <div id="oasis-builder-tab-content" style="padding:22px 24px;overflow-y:auto;flex:1;">
          <div id="oasis-designer-view">
            <!-- Basic info -->
            <div style="display:grid;grid-template-columns:2fr 1fr;gap:16px;margin-bottom:18px;">
              <div>
                <label style="display:block;font-size:13px;font-weight:700;color:#1e293b;margin-bottom:6px;">Form Name <span style="color:#ef4444;">*</span></label>
                <input id="builder-form-name" type="text" placeholder="e.g. Shift Handoff, Physical Vitals, Fall Assessment" value="${escapeHtml(s.name)}" style="width:100%;box-sizing:border-box;padding:10px 14px;border:1px solid #cbd5e1;border-radius:8px;font-size:14px;outline:none;" />
                <div id="builder-name-error" style="color:#ef4444;font-size:12px;margin-top:4px;display:none;">Form name is required.</div>
              </div>
              <div>
                <label style="display:block;font-size:13px;font-weight:700;color:#1e293b;margin-bottom:6px;">Form Type / Category</label>
                <select id="builder-form-type" style="width:100%;box-sizing:border-box;padding:10px 12px;border:1px solid #cbd5e1;border-radius:8px;font-size:14px;background:#fff;outline:none;">
                  ${FORM_TYPES.map(t => `<option value="${t}" ${s.type === t ? 'selected' : ''}>${t}</option>`).join('')}
                </select>
              </div>
            </div>

            <div style="margin-bottom:20px;">
              <label style="display:block;font-size:13px;font-weight:700;color:#1e293b;margin-bottom:6px;">Clinical Description / Instructions</label>
              <input id="builder-form-desc" type="text" placeholder="Optional notes for clinicians completing this form..." value="${escapeHtml(s.description || '')}" style="width:100%;box-sizing:border-box;padding:10px 14px;border:1px solid #cbd5e1;border-radius:8px;font-size:13px;outline:none;" />
            </div>

            <!-- Fields Header -->
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;padding-bottom:8px;border-bottom:1px solid #e2e8f0;">
              <div>
                <span style="font-size:15px;font-weight:700;color:#0f172a;">Form Fields (${s.fields.length})</span>
                <span style="font-size:12px;color:#64748b;margin-left:8px;">Add, reorder, configure, and mark required fields</span>
              </div>
              <button id="builder-add-field-btn" style="background:#0f766e;color:#fff;border:none;padding:7px 14px;border-radius:6px;font-size:13px;font-weight:700;cursor:pointer;display:inline-flex;align-items:center;gap:6px;">
                <span>+ Add Field</span>
              </button>
            </div>

            <!-- Fields List Container -->
            <div id="builder-fields-container" style="display:flex;flex-direction:column;gap:12px;min-height:120px;">
              ${s.fields.length === 0 ? `
                <div style="padding:28px;text-align:center;background:#f8fafc;border:2px dashed #cbd5e1;border-radius:10px;color:#64748b;">
                  <div style="font-size:24px;margin-bottom:6px;">📋</div>
                  <div style="font-weight:600;font-size:14px;">No fields added yet</div>
                  <div style="font-size:12px;margin-top:2px;">Click "+ Add Field" above to insert your first clinical question or metric.</div>
                </div>
              ` : s.fields.map((field, idx) => renderFieldItemHtml(field, idx, s.fields.length)).join('')}
            </div>
          </div>

          <!-- Templates tab view -->
          <div id="oasis-templates-view" style="display:none;">
            <div style="margin-bottom:16px;">
              <p style="font-size:13px;color:#475569;margin:0;">Select any standard Oasis Notes clinical form to view its layout or clone it directly into your workspace:</p>
            </div>
            <div style="display:grid;grid-template-columns:repeat(auto-fill, minmax(240px, 1fr));gap:14px;">
              ${(window.OasisFormEngine.templates || []).map(tpl => `
                <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:14px;display:flex;flex-direction:column;justify-content:space-between;gap:8px;">
                  <div>
                    <span style="display:inline-block;padding:2px 8px;border-radius:12px;background:#e0f2fe;color:#0284c7;font-size:11px;font-weight:700;margin-bottom:6px;">${tpl.type}</span>
                    <h5 style="margin:0 0 4px;font-size:14px;font-weight:700;color:#0f172a;">${tpl.name}</h5>
                    <p style="margin:0;font-size:12px;color:#64748b;line-height:1.4;">${tpl.description || ''}</p>
                  </div>
                  <div style="display:flex;gap:8px;margin-top:10px;">
                    <a href="${tpl.link}" style="flex:1;text-align:center;padding:6px;border-radius:6px;background:#1a9fb2;color:#fff;text-decoration:none;font-size:12px;font-weight:700;">Open Form</a>
                    <button class="btn-clone-template" data-tpl-id="${tpl.id}" style="padding:6px 10px;border-radius:6px;border:1px solid #cbd5e1;background:#fff;color:#0f172a;font-size:12px;font-weight:600;cursor:pointer;">Clone</button>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>
        </div>

        <!-- Footer actions -->
        <div style="padding:16px 24px;border-top:1px solid #e2e8f0;background:#f8fafc;display:flex;align-items:center;justify-content:space-between;">
          <div style="display:flex;gap:10px;">
            <button id="builder-preview-btn" type="button" style="padding:9px 16px;border:1px solid #cbd5e1;background:#fff;border-radius:6px;color:#0f172a;font-size:13px;font-weight:600;cursor:pointer;display:flex;align-items:center;gap:6px;">
              👁 Preview Form
            </button>
            ${s.id ? `
              <button id="builder-delete-btn" type="button" style="padding:9px 14px;border:1px solid #fecaca;background:#fff;border-radius:6px;color:#ef4444;font-size:13px;font-weight:600;cursor:pointer;">
                🗑 Delete Form
              </button>
            ` : ''}
          </div>
          <div style="display:flex;gap:10px;">
            <button id="builder-cancel-btn" type="button" style="padding:9px 18px;border:1px solid #cbd5e1;background:#fff;border-radius:6px;color:#475569;font-size:13px;font-weight:600;cursor:pointer;">
              Cancel
            </button>
            <button id="builder-save-btn" type="button" style="padding:9px 24px;border:none;background:#1a9fb2;border-radius:6px;color:#fff;font-size:13px;font-weight:700;cursor:pointer;box-shadow:0 4px 12px rgba(26,159,178,0.3);">
              💾 Save Form
            </button>
          </div>
        </div>
      </div>
    `;

    // Bind Builder Event Listeners
    attachBuilderEvents(modal);
  }

  // HTML for an individual field row inside the builder
  function renderFieldItemHtml(field, idx, total) {
    const isOptionsType = ['select', 'radio', 'checkbox'].includes(field.type);
    const optionsText = Array.isArray(field.options) ? field.options.join(', ') : (field.options || '');

    return `
      <div class="oasis-field-row" data-field-id="${field.id}" style="background:#fff;border:1px solid #e2e8f0;border-radius:8px;padding:12px 14px;box-shadow:0 1px 3px rgba(0,0,0,0.03);">
        <div style="display:flex;align-items:center;gap:10px;justify-content:space-between;margin-bottom:8px;">
          <div style="display:flex;align-items:center;gap:8px;">
            <span style="width:22px;height:22px;border-radius:50%;background:#e0f2fe;color:#0284c7;font-size:11px;font-weight:700;display:flex;align-items:center;justify-content:center;">${idx + 1}</span>
            <input class="field-label-input" type="text" placeholder="Question / Field Label" value="${escapeHtml(field.label)}" style="font-weight:700;font-size:14px;border:1px solid #cbd5e1;border-radius:6px;padding:5px 8px;width:280px;color:#0f172a;" />
          </div>
          <div style="display:flex;align-items:center;gap:6px;">
            <!-- Move buttons -->
            <button class="field-move-up-btn" data-idx="${idx}" ${idx === 0 ? 'disabled style="opacity:0.3;cursor:not-allowed;"' : ''} title="Move Up" style="border:1px solid #cbd5e1;background:#fff;border-radius:4px;padding:4px 8px;cursor:pointer;font-size:11px;">▲</button>
            <button class="field-move-down-btn" data-idx="${idx}" ${idx === total - 1 ? 'disabled style="opacity:0.3;cursor:not-allowed;"' : ''} title="Move Down" style="border:1px solid #cbd5e1;background:#fff;border-radius:4px;padding:4px 8px;cursor:pointer;font-size:11px;">▼</button>
            <!-- Delete button -->
            <button class="field-delete-btn" data-idx="${idx}" title="Remove Field" style="border:1px solid #fecaca;background:#fff;border-radius:4px;padding:4px 8px;cursor:pointer;color:#ef4444;font-size:12px;font-weight:700;">✕</button>
          </div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr auto;gap:10px;align-items:center;">
          <div>
            <label style="font-size:11px;font-weight:600;color:#64748b;display:block;margin-bottom:3px;">Field Input Type</label>
            <select class="field-type-select" data-idx="${idx}" style="width:100%;padding:6px 10px;border:1px solid #cbd5e1;border-radius:6px;font-size:12px;background:#fff;">
              ${FIELD_TYPES.map(ft => `<option value="${ft.value}" ${field.type === ft.value ? 'selected' : ''}>${ft.label}</option>`).join('')}
            </select>
          </div>

          <div>
            <label style="font-size:11px;font-weight:600;color:#64748b;display:block;margin-bottom:3px;">Placeholder / Helper Hint</label>
            <input class="field-placeholder-input" type="text" placeholder="e.g. Enter details..." value="${escapeHtml(field.placeholder || '')}" style="width:100%;box-sizing:border-box;padding:6px 10px;border:1px solid #cbd5e1;border-radius:6px;font-size:12px;" />
          </div>

          <div style="padding-top:16px;">
            <label style="display:inline-flex;align-items:center;gap:6px;font-size:12px;font-weight:700;color:#334155;cursor:pointer;">
              <input class="field-required-checkbox" type="checkbox" ${field.required ? 'checked' : ''} style="cursor:pointer;" />
              <span>Required</span>
            </label>
          </div>
        </div>

        ${isOptionsType ? `
          <div style="margin-top:10px;padding-top:8px;border-top:1px dashed #e2e8f0;">
            <label style="font-size:11px;font-weight:700;color:#0f766e;display:block;margin-bottom:3px;">Choices / Options (comma-separated):</label>
            <input class="field-options-input" type="text" placeholder="e.g. Normal, Mild, Moderate, Severe" value="${escapeHtml(optionsText)}" style="width:100%;box-sizing:border-box;padding:6px 10px;border:1px solid #cbd5e1;border-radius:6px;font-size:12px;" />
          </div>
        ` : ''}
      </div>
    `;
  }

  // Event handlers for the builder
  function attachBuilderEvents(modal) {
    const s = window.OasisFormEngine.builderState;

    // Close
    modal.querySelector('#oasis-builder-close-btn').onclick = () => { modal.style.display = 'none'; };
    modal.querySelector('#builder-cancel-btn').onclick = () => { modal.style.display = 'none'; };

    // Tabs
    const tabDesigner = modal.querySelector('#tab-builder-designer');
    const tabTemplates = modal.querySelector('#tab-builder-templates');
    const viewDesigner = modal.querySelector('#oasis-designer-view');
    const viewTemplates = modal.querySelector('#oasis-templates-view');

    tabDesigner.onclick = () => {
      tabDesigner.style.borderBottomColor = '#1a9fb2';
      tabDesigner.style.color = '#1a9fb2';
      tabTemplates.style.borderBottomColor = 'transparent';
      tabTemplates.style.color = '#64748b';
      viewDesigner.style.display = 'block';
      viewTemplates.style.display = 'none';
    };

    tabTemplates.onclick = () => {
      tabTemplates.style.borderBottomColor = '#1a9fb2';
      tabTemplates.style.color = '#1a9fb2';
      tabDesigner.style.borderBottomColor = 'transparent';
      tabDesigner.style.color = '#64748b';
      viewDesigner.style.display = 'none';
      viewTemplates.style.display = 'block';
    };

    // Form name sync
    const nameInput = modal.querySelector('#builder-form-name');
    nameInput.oninput = (e) => {
      s.name = e.target.value;
      modal.querySelector('#builder-name-error').style.display = 'none';
    };

    // Form type sync
    const typeSelect = modal.querySelector('#builder-form-type');
    typeSelect.onchange = (e) => {
      s.type = e.target.value;
      s.category = e.target.value;
    };

    // Description sync
    const descInput = modal.querySelector('#builder-form-desc');
    descInput.oninput = (e) => {
      s.description = e.target.value;
    };

    // Add field
    modal.querySelector('#builder-add-field-btn').onclick = () => {
      s.fields.push({
        id: 'field_' + Date.now(),
        name: 'field_' + (s.fields.length + 1),
        label: `Clinical Assessment Item ${s.fields.length + 1}`,
        type: 'text',
        required: false,
        placeholder: ''
      });
      renderBuilderModal();
    };

    // Field row controls
    modal.querySelectorAll('.field-label-input').forEach((el, idx) => {
      el.oninput = (e) => { s.fields[idx].label = e.target.value; };
    });

    modal.querySelectorAll('.field-placeholder-input').forEach((el, idx) => {
      el.oninput = (e) => { s.fields[idx].placeholder = e.target.value; };
    });

    modal.querySelectorAll('.field-required-checkbox').forEach((el, idx) => {
      el.onchange = (e) => { s.fields[idx].required = e.target.checked; };
    });

    modal.querySelectorAll('.field-options-input').forEach((el, idx) => {
      el.oninput = (e) => {
        s.fields[idx].options = e.target.value.split(',').map(x => x.trim()).filter(Boolean);
      };
    });

    modal.querySelectorAll('.field-type-select').forEach((el, idx) => {
      el.onchange = (e) => {
        s.fields[idx].type = e.target.value;
        if (['select', 'radio', 'checkbox'].includes(e.target.value) && !s.fields[idx].options) {
          s.fields[idx].options = ['Option 1', 'Option 2', 'Option 3'];
        }
        renderBuilderModal();
      };
    });

    modal.querySelectorAll('.field-move-up-btn').forEach((btn) => {
      btn.onclick = () => {
        const idx = parseInt(btn.dataset.idx, 10);
        if (idx > 0) {
          const temp = s.fields[idx];
          s.fields[idx] = s.fields[idx - 1];
          s.fields[idx - 1] = temp;
          renderBuilderModal();
        }
      };
    });

    modal.querySelectorAll('.field-move-down-btn').forEach((btn) => {
      btn.onclick = () => {
        const idx = parseInt(btn.dataset.idx, 10);
        if (idx < s.fields.length - 1) {
          const temp = s.fields[idx];
          s.fields[idx] = s.fields[idx + 1];
          s.fields[idx + 1] = temp;
          renderBuilderModal();
        }
      };
    });

    modal.querySelectorAll('.field-delete-btn').forEach((btn) => {
      btn.onclick = () => {
        const idx = parseInt(btn.dataset.idx, 10);
        s.fields.splice(idx, 1);
        renderBuilderModal();
      };
    });

    // Clone template
    modal.querySelectorAll('.btn-clone-template').forEach((btn) => {
      btn.onclick = () => {
        const tplId = btn.dataset.tplId;
        const tpl = (window.OasisFormEngine.templates || []).find(t => t.id === tplId);
        if (tpl) {
          s.id = null;
          s.name = `${tpl.name} (Custom Copy)`;
          s.type = tpl.type;
          s.category = tpl.type;
          s.description = tpl.description || '';
          s.fields = [
            { id: 'f1', name: 'resident_status', label: 'Resident Observation / Assessment', type: 'textarea', required: true, placeholder: 'Clinical observations...' },
            { id: 'f2', name: 'assessment_date', label: 'Evaluation Date', type: 'date', required: true },
            { id: 'f3', name: 'severity_rating', label: 'Progress / Severity Level', type: 'select', options: ['Stable', 'Improving', 'Declining', 'Critical'], required: false }
          ];
          tabDesigner.click();
          renderBuilderModal();
          showToast(`Cloned template "${tpl.name}" into builder!`, 'info');
        }
      };
    });

    // Preview
    modal.querySelector('#builder-preview-btn').onclick = () => {
      if (!s.name.trim()) {
        modal.querySelector('#builder-name-error').style.display = 'block';
        modal.querySelector('#builder-form-name').focus();
        showToast('Please provide a form name before previewing.', 'error');
        return;
      }
      openPreviewModal(s);
    };

    // Save Form
    modal.querySelector('#builder-save-btn').onclick = async () => {
      if (!s.name.trim()) {
        modal.querySelector('#builder-name-error').style.display = 'block';
        modal.querySelector('#builder-form-name').focus();
        showToast('Please provide a form name.', 'error');
        return;
      }

      if (s.fields.length === 0) {
        showToast('Please add at least one field before saving.', 'error');
        return;
      }

      const payload = {
        name: s.name.trim(),
        type: s.type || 'Clinical Assessment',
        category: s.category || s.type || 'Clinical Assessment',
        description: s.description || '',
        fields: s.fields
      };

      const url = s.id ? `${getApiBase()}/custom-forms/${s.id}` : `${getApiBase()}/custom-forms`;
      const method = s.id ? 'PUT' : 'POST';

      try {
        const res = await fetch(url, {
          method,
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }).then(r => r.json());

        if (res.success) {
          showToast(s.id ? 'Clinical form updated successfully!' : 'New clinical form created and published!', 'success');
          modal.style.display = 'none';
          await loadData();
        } else {
          showToast(res.message || 'Error saving form.', 'error');
        }
      } catch (err) {
        showToast('Failed to save form. Check network or server.', 'error');
      }
    };

    // Delete Form
    const delBtn = modal.querySelector('#builder-delete-btn');
    if (delBtn) {
      delBtn.onclick = async () => {
        if (!confirm(`Are you sure you want to delete form "${s.name}"? This action cannot be undone.`)) return;

        try {
          const res = await fetch(`${getApiBase()}/custom-forms/${s.id}`, { method: 'DELETE' }).then(r => r.json());
          if (res.success) {
            showToast('Form deleted successfully.', 'success');
            modal.style.display = 'none';
            await loadData();
          } else {
            showToast(res.message || 'Error deleting form.', 'error');
          }
        } catch (err) {
          showToast('Failed to delete form.', 'error');
        }
      };
    }
  }

  // Open Preview Modal
  function openPreviewModal(form) {
    let modal = document.getElementById('oasis-preview-modal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'oasis-preview-modal';
      document.body.appendChild(modal);
    }

    modal.style.cssText = 'position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(15,23,42,0.7);backdrop-filter:blur(4px);z-index:99999999;display:flex;align-items:center;justify-content:center;font-family:Quicksand,sans-serif;padding:20px;box-sizing:border-box;';

    modal.innerHTML = `
      <div style="background:#fff;border-radius:14px;width:100%;max-width:720px;max-height:90vh;display:flex;flex-direction:column;box-shadow:0 20px 48px rgba(0,0,0,0.3);overflow:hidden;">
        <div style="padding:16px 24px;border-bottom:1px solid #e2e8f0;display:flex;align-items:center;justify-content:space-between;background:#f8fafc;">
          <div>
            <span style="font-size:11px;background:#e0f2fe;color:#0284c7;font-weight:700;padding:2px 8px;border-radius:10px;">PREVIEW MODE</span>
            <h4 style="margin:4px 0 0;font-size:18px;font-weight:700;color:#0f172a;">${escapeHtml(form.name)}</h4>
            <p style="margin:2px 0 0;font-size:12px;color:#64748b;">${escapeHtml(form.description || 'Test how this form looks and validates for clinicians.')}</p>
          </div>
          <button id="oasis-preview-close" style="background:transparent;border:none;font-size:22px;color:#94a3b8;cursor:pointer;">✕</button>
        </div>

        <div style="padding:24px;overflow-y:auto;flex:1;">
          <form id="oasis-preview-form" onsubmit="event.preventDefault();">
            <div style="display:flex;flex-direction:column;gap:18px;">
              ${form.fields.map(f => renderFieldInputHtml(f)).join('')}
            </div>
          </form>
        </div>

        <div style="padding:16px 24px;border-top:1px solid #e2e8f0;background:#f8fafc;display:flex;justify-content:flex-end;gap:10px;">
          <button id="oasis-preview-done" style="padding:9px 20px;background:#1a9fb2;color:#fff;border:none;border-radius:6px;font-weight:700;font-size:13px;cursor:pointer;">Done Previewing</button>
        </div>
      </div>
    `;

    modal.querySelector('#oasis-preview-close').onclick = () => { modal.style.display = 'none'; };
    modal.querySelector('#oasis-preview-done').onclick = () => { modal.style.display = 'none'; };
  }

  // Open Form Filling Modal
  window.oasisOpenFillForm = function (form) {
    window.OasisFormEngine.fillState = {
      form,
      residentId: '',
      values: {},
      errors: {}
    };

    let modal = document.getElementById('oasis-fill-modal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'oasis-fill-modal';
      document.body.appendChild(modal);
    }

    modal.style.cssText = 'position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(15,23,42,0.7);backdrop-filter:blur(4px);z-index:99999999;display:flex;align-items:center;justify-content:center;font-family:Quicksand,sans-serif;padding:20px;box-sizing:border-box;';

    const residents = window.OasisFormEngine.residents || [];

    modal.innerHTML = `
      <div style="background:#fff;border-radius:14px;width:100%;max-width:760px;max-height:92vh;display:flex;flex-direction:column;box-shadow:0 20px 48px rgba(0,0,0,0.3);overflow:hidden;">
        <div style="padding:16px 24px;border-bottom:1px solid #e2e8f0;display:flex;align-items:center;justify-content:space-between;background:#f8fafc;">
          <div>
            <span style="font-size:11px;background:#ccfbf1;color:#0f766e;font-weight:700;padding:2px 8px;border-radius:10px;">CLINICAL RECORDING</span>
            <h4 style="margin:4px 0 0;font-size:18px;font-weight:700;color:#0f172a;">${escapeHtml(form.name)}</h4>
            <p style="margin:2px 0 0;font-size:12px;color:#64748b;">Complete and sign this clinical form for a resident.</p>
          </div>
          <button id="oasis-fill-close" style="background:transparent;border:none;font-size:22px;color:#94a3b8;cursor:pointer;">✕</button>
        </div>

        <div style="padding:22px 24px;overflow-y:auto;flex:1;">
          <!-- Resident Selection -->
          <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:12px 16px;margin-bottom:20px;">
            <label style="display:block;font-size:13px;font-weight:700;color:#0f172a;margin-bottom:6px;">Select Resident <span style="color:#ef4444;">*</span></label>
            <select id="oasis-fill-resident-select" style="width:100%;box-sizing:border-box;padding:9px 12px;border:1px solid #cbd5e1;border-radius:6px;font-size:14px;background:#fff;outline:none;">
              <option value="">-- Choose Resident --</option>
              ${residents.map(r => `<option value="${r._id}">${r.firstName} ${r.lastName} (DOB: ${r.dob || 'N/A'}, Room: ${r.roomNumber || '101'})</option>`).join('')}
            </select>
            <div id="oasis-fill-resident-error" style="color:#ef4444;font-size:12px;margin-top:4px;display:none;">Please select a resident.</div>
          </div>

          <!-- Dynamic Form Fields -->
          <form id="oasis-fill-form-fields" onsubmit="event.preventDefault();">
            <div style="display:flex;flex-direction:column;gap:16px;">
              ${form.fields.map(f => renderFieldInputHtml(f, true)).join('')}
            </div>

            <!-- Clinician Sign-off -->
            <div style="margin-top:24px;padding-top:16px;border-top:1px dashed #cbd5e1;display:grid;grid-template-columns:1fr 1fr;gap:14px;">
              <div>
                <label style="display:block;font-size:12px;font-weight:700;color:#334155;margin-bottom:4px;">Clinician Name</label>
                <input id="oasis-fill-clinician" type="text" value="Sheku Swaray, Clinician" style="width:100%;box-sizing:border-box;padding:8px 12px;border:1px solid #cbd5e1;border-radius:6px;font-size:13px;" />
              </div>
              <div>
                <label style="display:block;font-size:12px;font-weight:700;color:#334155;margin-bottom:4px;">Date & Time</label>
                <input id="oasis-fill-timestamp" type="text" value="${new Date().toLocaleString()}" readonly style="width:100%;box-sizing:border-box;padding:8px 12px;border:1px solid #cbd5e1;border-radius:6px;font-size:13px;background:#f8fafc;" />
              </div>
            </div>
          </form>
        </div>

        <div style="padding:16px 24px;border-top:1px solid #e2e8f0;background:#f8fafc;display:flex;justify-content:space-between;align-items:center;">
          <button id="oasis-fill-view-subs-btn" style="padding:8px 14px;border:1px solid #cbd5e1;background:#fff;border-radius:6px;color:#0f766e;font-size:13px;font-weight:700;cursor:pointer;">
            📑 View Past Submissions (${form.submissionCount || 0})
          </button>
          <div style="display:flex;gap:10px;">
            <button id="oasis-fill-cancel" style="padding:9px 18px;border:1px solid #cbd5e1;background:#fff;border-radius:6px;color:#475569;font-size:13px;font-weight:600;cursor:pointer;">Cancel</button>
            <button id="oasis-fill-submit" style="padding:9px 24px;background:#0f766e;color:#fff;border:none;border-radius:6px;font-weight:700;font-size:13px;cursor:pointer;box-shadow:0 4px 12px rgba(15,118,110,0.3);">
              ✓ Submit & Save Record
            </button>
          </div>
        </div>
      </div>
    `;

    modal.querySelector('#oasis-fill-close').onclick = () => { modal.style.display = 'none'; };
    modal.querySelector('#oasis-fill-cancel').onclick = () => { modal.style.display = 'none'; };

    // View submissions
    modal.querySelector('#oasis-fill-view-subs-btn').onclick = () => {
      modal.style.display = 'none';
      openSubmissionsModal(form);
    };

    // Submit handler
    modal.querySelector('#oasis-fill-submit').onclick = async () => {
      const resSelect = modal.querySelector('#oasis-fill-resident-select');
      const residentId = resSelect.value;
      const resError = modal.querySelector('#oasis-fill-resident-error');

      if (!residentId) {
        resError.style.display = 'block';
        resSelect.focus();
        showToast('Please select a resident.', 'error');
        return;
      }
      resError.style.display = 'none';

      // Validate required fields and gather values
      const values = {};
      let hasError = false;

      form.fields.forEach(f => {
        const errorEl = modal.querySelector(`#field-err-${f.id}`);
        if (errorEl) errorEl.style.display = 'none';

        if (f.type === 'checkbox') {
          const checked = Array.from(modal.querySelectorAll(`input[name="input_${f.id}"]:checked`)).map(el => el.value);
          values[f.id] = checked;
          if (f.required && checked.length === 0) {
            if (errorEl) errorEl.style.display = 'block';
            hasError = true;
          }
        } else if (f.type === 'radio') {
          const selected = modal.querySelector(`input[name="input_${f.id}"]:checked`);
          values[f.id] = selected ? selected.value : '';
          if (f.required && !values[f.id]) {
            if (errorEl) errorEl.style.display = 'block';
            hasError = true;
          }
        } else {
          const input = modal.querySelector(`#input_${f.id}`);
          const val = input ? input.value.trim() : '';
          values[f.id] = val;
          if (f.required && !val) {
            if (errorEl) errorEl.style.display = 'block';
            hasError = true;
          }
        }
      });

      if (hasError) {
        showToast('Please complete all required fields.', 'error');
        return;
      }

      const clinician = modal.querySelector('#oasis-fill-clinician').value;

      try {
        const res = await fetch(`${getApiBase()}/custom-forms/${form._id || form.id}/submissions`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            residentId,
            values,
            completedBy: clinician
          })
        }).then(r => r.json());

        if (res.success) {
          showToast('Clinical record saved and archived to Resident Chart!', 'success');
          modal.style.display = 'none';
          await loadData();
        } else {
          showToast(res.message || 'Error saving submission.', 'error');
        }
      } catch (e) {
        showToast('Network error while saving submission.', 'error');
      }
    };
  };

  // Open Submissions Viewer modal
  async function openSubmissionsModal(form) {
    let modal = document.getElementById('oasis-submissions-modal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'oasis-submissions-modal';
      document.body.appendChild(modal);
    }

    modal.style.cssText = 'position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(15,23,42,0.7);backdrop-filter:blur(4px);z-index:99999999;display:flex;align-items:center;justify-content:center;font-family:Quicksand,sans-serif;padding:20px;box-sizing:border-box;';

    // Fetch submissions
    let submissions = [];
    try {
      const res = await fetch(`${getApiBase()}/custom-forms/${form._id || form.id}/submissions`).then(r => r.json());
      if (res && res.success) {
        submissions = res.data || [];
      }
    } catch (e) {}

    modal.innerHTML = `
      <div style="background:#fff;border-radius:14px;width:100%;max-width:840px;max-height:92vh;display:flex;flex-direction:column;box-shadow:0 20px 48px rgba(0,0,0,0.3);overflow:hidden;">
        <div style="padding:16px 24px;border-bottom:1px solid #e2e8f0;display:flex;align-items:center;justify-content:space-between;background:#f8fafc;">
          <div>
            <span style="font-size:11px;background:#e0f2fe;color:#0284c7;font-weight:700;padding:2px 8px;border-radius:10px;">RECORDS ARCHIVE</span>
            <h4 style="margin:4px 0 0;font-size:18px;font-weight:700;color:#0f172a;">${escapeHtml(form.name)} — Submissions</h4>
            <p style="margin:2px 0 0;font-size:12px;color:#64748b;">All completed clinical entries for this form.</p>
          </div>
          <button id="oasis-subs-close" style="background:transparent;border:none;font-size:22px;color:#94a3b8;cursor:pointer;">✕</button>
        </div>

        <div style="padding:20px 24px;overflow-y:auto;flex:1;">
          ${submissions.length === 0 ? `
            <div style="text-align:center;padding:40px;color:#64748b;background:#f8fafc;border-radius:8px;border:1px dashed #cbd5e1;">
              <div style="font-size:24px;margin-bottom:6px;">📭</div>
              <div style="font-weight:700;">No submissions yet</div>
              <div style="font-size:13px;margin-top:4px;">Click "Fill Out Form" to document clinical notes for a resident.</div>
            </div>
          ` : `
            <div style="display:flex;flex-direction:column;gap:14px;">
              ${submissions.map((sub, sIdx) => `
                <div style="border:1px solid #e2e8f0;border-radius:10px;padding:16px;background:#f8fafc;">
                  <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #e2e8f0;padding-bottom:10px;margin-bottom:12px;">
                    <div>
                      <strong style="font-size:15px;color:#0f172a;">${sub.resident ? `${sub.resident.firstName} ${sub.resident.lastName}` : 'Resident Record'}</strong>
                      <span style="font-size:12px;color:#64748b;margin-left:8px;">• ${new Date(sub.createdAt).toLocaleString()}</span>
                    </div>
                    <div style="display:flex;align-items:center;gap:8px;">
                      <span style="font-size:12px;background:#f1f5f9;color:#475569;padding:3px 8px;border-radius:6px;font-weight:600;">Signed: ${sub.completedBy || 'Clinician'}</span>
                      <button class="btn-delete-submission" data-sub-id="${sub._id}" style="border:none;background:transparent;color:#ef4444;font-size:12px;font-weight:700;cursor:pointer;padding:4px 8px;">Delete</button>
                    </div>
                  </div>

                  <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(220px, 1fr));gap:12px;">
                    ${(form.fields || []).map(f => {
                      const val = sub.values ? sub.values[f.id] : null;
                      const displayVal = Array.isArray(val) ? val.join(', ') : (val || '<span style="color:#94a3b8;font-style:italic;">None</span>');
                      return `
                        <div style="background:#fff;border:1px solid #e2e8f0;border-radius:6px;padding:8px 12px;">
                          <div style="font-size:11px;font-weight:700;color:#64748b;margin-bottom:2px;">${escapeHtml(f.label)}</div>
                          <div style="font-size:13px;color:#0f172a;word-break:break-word;">${displayVal}</div>
                        </div>
                      `;
                    }).join('')}
                  </div>
                </div>
              `).join('')}
            </div>
          `}
        </div>

        <div style="padding:14px 24px;border-top:1px solid #e2e8f0;background:#f8fafc;display:flex;justify-content:space-between;">
          <button id="oasis-subs-fill-new" style="padding:8px 16px;background:#0f766e;color:#fff;border:none;border-radius:6px;font-weight:700;font-size:13px;cursor:pointer;">
            + Fill Out Another Entry
          </button>
          <button id="oasis-subs-close-btn" style="padding:8px 18px;border:1px solid #cbd5e1;background:#fff;border-radius:6px;color:#475569;font-weight:600;font-size:13px;cursor:pointer;">
            Close
          </button>
        </div>
      </div>
    `;

    modal.querySelector('#oasis-subs-close').onclick = () => { modal.style.display = 'none'; };
    modal.querySelector('#oasis-subs-close-btn').onclick = () => { modal.style.display = 'none'; };
    modal.querySelector('#oasis-subs-fill-new').onclick = () => {
      modal.style.display = 'none';
      window.oasisOpenFillForm(form);
    };

    modal.querySelectorAll('.btn-delete-submission').forEach(btn => {
      btn.onclick = async () => {
        if (!confirm('Are you sure you want to delete this clinical submission?')) return;
        const subId = btn.dataset.subId;
        try {
          const res = await fetch(`${getApiBase()}/custom-form-submissions/${subId}`, { method: 'DELETE' }).then(r => r.json());
          if (res.success) {
            showToast('Submission deleted.', 'success');
            openSubmissionsModal(form);
            await loadData();
          }
        } catch (e) {
          showToast('Failed to delete submission.', 'error');
        }
      };
    });
  }

  // Helper to render input HTML according to field type
  function renderFieldInputHtml(field, isLive = false) {
    const reqStar = field.required ? '<span style="color:#ef4444;">*</span>' : '';
    const errDiv = isLive ? `<div id="field-err-${field.id}" style="color:#ef4444;font-size:12px;margin-top:4px;display:none;">This field is required.</div>` : '';

    let inputHtml = '';
    const inputId = `input_${field.id}`;

    switch (field.type) {
      case 'textarea':
        inputHtml = `<textarea id="${inputId}" rows="3" placeholder="${escapeHtml(field.placeholder || '')}" style="width:100%;box-sizing:border-box;padding:9px 12px;border:1px solid #cbd5e1;border-radius:6px;font-size:14px;outline:none;font-family:inherit;"></textarea>`;
        break;

      case 'date':
        inputHtml = `<input id="${inputId}" type="date" value="${new Date().toISOString().split('T')[0]}" style="width:100%;box-sizing:border-box;padding:9px 12px;border:1px solid #cbd5e1;border-radius:6px;font-size:14px;outline:none;" />`;
        break;

      case 'number':
        inputHtml = `<input id="${inputId}" type="number" placeholder="${escapeHtml(field.placeholder || '')}" style="width:100%;box-sizing:border-box;padding:9px 12px;border:1px solid #cbd5e1;border-radius:6px;font-size:14px;outline:none;" />`;
        break;

      case 'select':
        const opts = Array.isArray(field.options) ? field.options : (field.options ? field.options.split(',') : []);
        inputHtml = `
          <select id="${inputId}" style="width:100%;box-sizing:border-box;padding:9px 12px;border:1px solid #cbd5e1;border-radius:6px;font-size:14px;background:#fff;outline:none;">
            <option value="">-- Select an option --</option>
            ${opts.map(o => `<option value="${escapeHtml(o.trim())}">${escapeHtml(o.trim())}</option>`).join('')}
          </select>
        `;
        break;

      case 'radio':
        const rOpts = Array.isArray(field.options) ? field.options : (field.options ? field.options.split(',') : []);
        inputHtml = `
          <div style="display:flex;flex-wrap:wrap;gap:14px;padding-top:4px;">
            ${rOpts.map(o => `
              <label style="display:inline-flex;align-items:center;gap:6px;font-size:13px;cursor:pointer;">
                <input type="radio" name="${inputId}" value="${escapeHtml(o.trim())}" style="cursor:pointer;" />
                <span>${escapeHtml(o.trim())}</span>
              </label>
            `).join('')}
          </div>
        `;
        break;

      case 'checkbox':
        const cOpts = Array.isArray(field.options) ? field.options : (field.options ? field.options.split(',') : []);
        inputHtml = `
          <div style="display:flex;flex-wrap:wrap;gap:14px;padding-top:4px;">
            ${cOpts.map(o => `
              <label style="display:inline-flex;align-items:center;gap:6px;font-size:13px;cursor:pointer;">
                <input type="checkbox" name="${inputId}" value="${escapeHtml(o.trim())}" style="cursor:pointer;" />
                <span>${escapeHtml(o.trim())}</span>
              </label>
            `).join('')}
          </div>
        `;
        break;

      case 'rating':
        inputHtml = `
          <div style="display:flex;gap:6px;flex-wrap:wrap;">
            ${[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(n => `
              <label style="display:flex;flex-direction:column;align-items:center;justify-content:center;width:34px;height:34px;border:1px solid #cbd5e1;border-radius:6px;cursor:pointer;font-weight:700;font-size:13px;background:#f8fafc;">
                <input type="radio" name="${inputId}" value="${n}" style="display:none;" onchange="this.parentElement.parentElement.querySelectorAll('label').forEach(l=>l.style.background='#f8fafc');this.parentElement.style.background='#1a9fb2';this.parentElement.style.color='#fff';" />
                <span>${n}</span>
              </label>
            `).join('')}
          </div>
        `;
        break;

      case 'text':
      default:
        inputHtml = `<input id="${inputId}" type="text" placeholder="${escapeHtml(field.placeholder || '')}" style="width:100%;box-sizing:border-box;padding:9px 12px;border:1px solid #cbd5e1;border-radius:6px;font-size:14px;outline:none;" />`;
        break;
    }

    return `
      <div>
        <label style="display:block;font-size:13px;font-weight:700;color:#1e293b;margin-bottom:6px;">
          ${escapeHtml(field.label)} ${reqStar}
        </label>
        ${inputHtml}
        ${errDiv}
      </div>
    `;
  }

  // Render Custom Form cards into the Resident Chart grid
  function renderCustomCardsInChart() {
    // Look for the Resident Chart grid container
    const chartGrids = document.querySelectorAll('.dashboard_cont');
    if (!chartGrids || chartGrids.length === 0) return;

    // Check if custom section already exists
    let customSection = document.getElementById('oasis-custom-forms-container');
    const forms = window.OasisFormEngine.customForms || [];

    const parentRow = chartGrids[0].closest('.row') || chartGrids[0].parentElement;
    if (!parentRow) return;

    if (!customSection) {
      customSection = document.createElement('div');
      customSection.id = 'oasis-custom-forms-container';
      customSection.className = 'w-100 col-12 my-3';
      parentRow.appendChild(customSection);
    }

    if (forms.length === 0) {
      customSection.innerHTML = `
        <div style="margin-top:20px;padding:16px 20px;background:#f0fdfa;border:1px dashed #14b8a6;border-radius:10px;display:flex;justify-content:space-between;align-items:center;">
          <div>
            <h5 style="margin:0;font-size:15px;font-weight:700;color:#0f766e;">Custom Clinical Forms (0)</h5>
            <p style="margin:2px 0 0;font-size:12px;color:#0d9488;">Create tailor-made clinical questionnaires, shift notes, or assessments with the form builder.</p>
          </div>
          <button onclick="window.oasisOpenFormBuilder()" style="background:#1a9fb2;color:#fff;border:none;padding:8px 16px;border-radius:6px;font-size:13px;font-weight:700;cursor:pointer;">
            + Create New Form
          </button>
        </div>
      `;
      return;
    }

    customSection.innerHTML = `
      <div style="margin-top:24px;border-top:2px solid #e2e8f0;padding-top:16px;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;">
          <div style="display:flex;align-items:center;gap:10px;">
            <h4 style="margin:0;font-size:18px;font-weight:700;color:#0f172a;">Custom Clinical Forms (${forms.length})</h4>
            <span style="font-size:12px;background:#e0f2fe;color:#0284c7;font-weight:700;padding:2px 8px;border-radius:12px;">Active & Persistent</span>
          </div>
          <button onclick="window.oasisOpenFormBuilder()" style="background:#1a9fb2;color:#fff;border:none;padding:8px 16px;border-radius:6px;font-size:13px;font-weight:700;cursor:pointer;display:inline-flex;align-items:center;gap:6px;">
            <span>+ Create New Form</span>
          </button>
        </div>

        <div style="display:grid;grid-template-columns:repeat(auto-fill, minmax(250px, 1fr));gap:16px;">
          ${forms.map(form => `
            <div class="oasis-custom-form-card" data-form-id="${form._id || form.id}" style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:16px;box-shadow:0 2px 8px rgba(0,0,0,0.04);display:flex;flex-direction:column;justify-content:space-between;transition:transform 0.15s, box-shadow 0.15s;position:relative;">
              <div>
                <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px;">
                  <span style="font-size:11px;font-weight:700;background:#ccfbf1;color:#0f766e;padding:2px 8px;border-radius:10px;">${escapeHtml(form.type || 'Custom Form')}</span>
                  <span style="font-size:11px;color:#64748b;">${(form.fields || []).length} fields</span>
                </div>
                <h5 style="margin:0 0 4px;font-size:15px;font-weight:700;color:#0f172a;line-height:1.3;">${escapeHtml(form.name)}</h5>
                <p style="margin:0;font-size:12px;color:#64748b;line-height:1.4;">${escapeHtml(form.description || 'Custom healthcare form record.')}</p>
                <div style="margin-top:8px;font-size:11px;color:#0f766e;font-weight:600;">
                  📝 ${form.submissionCount || 0} Submissions recorded
                </div>
              </div>

              <div style="display:flex;gap:6px;margin-top:14px;border-top:1px solid #f1f5f9;padding-top:10px;">
                <button class="btn-fill-custom-form" data-form-id="${form._id || form.id}" style="flex:2;background:#1a9fb2;color:#fff;border:none;padding:7px;border-radius:6px;font-size:12px;font-weight:700;cursor:pointer;">
                  Fill Form
                </button>
                <button class="btn-view-custom-subs" data-form-id="${form._id || form.id}" style="flex:1;background:#f8fafc;border:1px solid #cbd5e1;color:#0f172a;padding:7px;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;">
                  Records
                </button>
                <button class="btn-edit-custom-form" data-form-id="${form._id || form.id}" style="background:#fff;border:1px solid #cbd5e1;color:#475569;padding:7px 10px;border-radius:6px;font-size:12px;cursor:pointer;" title="Edit Builder">
                  ✎
                </button>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;

    // Bind card actions
    customSection.querySelectorAll('.btn-fill-custom-form').forEach(btn => {
      btn.onclick = () => {
        const fId = btn.dataset.formId;
        const form = forms.find(f => (f._id || f.id) === fId);
        if (form) window.oasisOpenFillForm(form);
      };
    });

    customSection.querySelectorAll('.btn-view-custom-subs').forEach(btn => {
      btn.onclick = () => {
        const fId = btn.dataset.formId;
        const form = forms.find(f => (f._id || f.id) === fId);
        if (form) openSubmissionsModal(form);
      };
    });

    customSection.querySelectorAll('.btn-edit-custom-form').forEach(btn => {
      btn.onclick = () => {
        const fId = btn.dataset.formId;
        const form = forms.find(f => (f._id || f.id) === fId);
        if (form) window.oasisOpenFormBuilder(form);
      };
    });
  }

  // Inject header button into DOM if NavWrapper or top header bar exists
  function ensureHeaderButton() {
    if (document.getElementById('btn-create-new-form-header')) return;

    // Try finding inner-menu-toggle or page-title-bar
    const titleBar = document.querySelector('.page-title-bar');
    if (titleBar && !titleBar.querySelector('#btn-create-new-form-header')) {
      const rightCol = titleBar.querySelector('.inner-menu-toggle') || titleBar.querySelector('.col-xl-3:last-child') || titleBar.querySelector('.col-2:last-child');
      if (rightCol) {
        const btn = document.createElement('button');
        btn.id = 'btn-create-new-form-header';
        btn.type = 'button';
        btn.className = 'btn btn-sm btn-primary d-inline-flex align-items-center gap-1 shadow-sm px-3 py-1';
        btn.style.cssText = 'background-color:#1a9fb2;border-color:#1a9fb2;font-weight:600;border-radius:6px;font-size:13px;cursor:pointer;color:#fff;margin-right:8px;';
        btn.innerHTML = '<span>+</span><span>Create New Form</span>';
        btn.onclick = () => window.oasisOpenFormBuilder();
        rightCol.prepend(btn);
      }
    }
  }

  // Escape HTML helper
  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  // Initialize
  document.addEventListener('DOMContentLoaded', () => {
    loadData();
    setInterval(ensureHeaderButton, 800);
    setInterval(renderCustomCardsInChart, 1500);
  });

  // Also run immediately if script loaded dynamically
  loadData();
  setInterval(ensureHeaderButton, 800);
  setInterval(renderCustomCardsInChart, 1500);

})();
