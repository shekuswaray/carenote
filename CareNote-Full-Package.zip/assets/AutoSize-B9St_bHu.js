import{Go as e,Xo as t,ko as n}from"./authSlice-DgGx7gH_.js";var r=t(e()),i=n();function a({type:e,value:t,setValue:n,placeholder:a,disabled:o,fontFamily:s=`14px Quicksand, Arial, sans-serif`,widthPadding:c=10}){let l=(0,r.useRef)(null),u=(e=``)=>{let t=document.createElement(`canvas`).getContext(`2d`);return t.font=s,t.measureText(e).width+c};(0,r.useEffect)(()=>{l.current&&(l.current.style.width=`${u(t||``)}px`)},[t]);let d=e=>{n(e.target.value)},f={borderRadius:`4px`,padding:`5px`,fontSize:`14px`,width:`${t?.length?u(t):40}px`,minWidth:`25px`,maxWidth:`100%`,boxSizing:`border-box`,border:`none`,outline:`none`,whiteSpace:`nowrap`};return(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(`style`,{children:`
        .hide-spinners::-webkit-inner-spin-button,
        .hide-spinners::-webkit-outer-spin-button {
          -webkit-appearance: none;
          margin: 0;
        }
        .hide-spinners {
          -moz-appearance: textfield;
        }
      `}),(0,i.jsx)(`input`,{ref:l,className:`hide-spinners`,...e?{type:e}:{type:`text`},style:f,placeholder:a,value:t??``,onChange:d,disabled:o})]})}export{a as t};