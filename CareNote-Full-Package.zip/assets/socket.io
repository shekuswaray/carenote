<!-- @format -->

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="theme-color" content="#000000" />
    <meta
      name="description"
      content="Oasis Notes Client and Employee Portal - Streamlined electronic health records, scheduling, and patient chart management."
    />
    <link rel="icon" type="image/png" href="/Logo/fav.png" />
    <link rel="apple-touch-icon" href="/favicon.ico?v=2" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300&family=Poppins:wght@300&display=swap"
      rel="stylesheet"
    />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Quicksand:wght@500&display=swap"
      rel="stylesheet"
    />
    <!-- Site24x7 Real User Monitoring (RUM) — loads beacon asynchronously, no render blocking -->
    <script type="text/javascript">
      (function (w, d, s, r, k, h, m) {
        if (
          w.performance &&
          w.performance.timing &&
          w.performance.navigation &&
          !w.s247r
        ) {
          w[r] =
            w[r] ||
            function () {
              (w[r].q = w[r].q || []).push(arguments);
            };
          h = d.createElement("script");
          h.async = true;
          h.setAttribute("src", s + k);
          d.getElementsByTagName("head")[0].appendChild(h);
          ((m = window.onerror),
            (window.onerror = function (b, c, d, f, g) {
              (m && m(b, c, d, f, g),
                g || (g = new Error(b)),
                (w[r].q = w[r].q || []).push(["captureException", g]));
            }));
        }
      })(
        window,
        document,
        "//static.site24x7rum.com/beacon/site24x7rum-min.js?appKey=",
        "s247r",
        "1441941d6af7150f435ca0c544ad1408",
      );
    </script>

    <title>Oasis Notes</title>
    <script type="module" crossorigin src="/assets/index-CBt-Uili.js"></script>
    <link rel="modulepreload" crossorigin href="/assets/queryClient-D0DeX4nj.js">
    <link rel="modulepreload" crossorigin href="/assets/authSlice-DgGx7gH_.js">
    <link rel="modulepreload" crossorigin href="/assets/Row-DeJt2hhu.js">
    <link rel="modulepreload" crossorigin href="/assets/Table-63g8S91d.js">
    <link rel="modulepreload" crossorigin href="/assets/Modal-DJGr1nh6.js">
    <link rel="stylesheet" crossorigin href="/assets/Modal-BLpCLV9Q.css">
    <link rel="stylesheet" crossorigin href="/assets/index-BIckmujQ.css">
  </head>

  <body>
    <noscript>You need to enable JavaScript to run this app.</noscript>
    <div id="root"></div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script
      src="https://kit.fontawesome.com/b533b351e4.js"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
