import { DatabaseSync } from 'node:sqlite';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.join(__dirname, 'data');
const DB_PATH = path.join(DATA_DIR, 'oasis.db');
const JSON_BACKUP_PATH = path.join(DATA_DIR, 'oasis_db.json');

// Ensure data folder exists
fs.mkdirSync(DATA_DIR, { recursive: true });

// Initialize SQLite database
const db = new DatabaseSync(DB_PATH);

// Wrap db.prepare to safely handle `undefined` values for node:sqlite
const _origPrepare = db.prepare.bind(db);
db.prepare = function(sql) {
  const stmt = _origPrepare(sql);
  const _origRun = stmt.run.bind(stmt);
  const _origGet = stmt.get.bind(stmt);
  const _origAll = stmt.all.bind(stmt);

  stmt.run = function(...args) {
    const safeArgs = args.map(a => a === undefined ? null : a);
    return _origRun(...safeArgs);
  };
  stmt.get = function(...args) {
    const safeArgs = args.map(a => a === undefined ? null : a);
    return _origGet(...safeArgs);
  };
  stmt.all = function(...args) {
    const safeArgs = args.map(a => a === undefined ? null : a);
    return _origAll(...safeArgs);
  };
  return stmt;
};

// Enable WAL mode for high performance & concurrency
db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA synchronous = NORMAL;');
db.exec('PRAGMA foreign_keys = ON;');

// Create tables
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  _id TEXT PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  password TEXT,
  name TEXT,
  firstName TEXT,
  lastName TEXT,
  userType TEXT,
  accountType TEXT,
  companyName TEXT,
  position TEXT,
  phone TEXT,
  tier TEXT DEFAULT 'Growth',
  facilityId TEXT,
  activeOrganizationId TEXT,
  organizations TEXT,
  userPermissions TEXT,
  unreadNotifications INTEGER DEFAULT 0,
  totalUnreadMessages INTEGER DEFAULT 0,
  createdAt TEXT,
  updatedAt TEXT
);

CREATE TABLE IF NOT EXISTS facilities (
  _id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  companyName TEXT,
  address TEXT,
  location TEXT,
  phone TEXT,
  capacity INTEGER DEFAULT 20,
  isActive INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS patients (
  _id TEXT PRIMARY KEY,
  Id TEXT,
  firstName TEXT,
  lastName TEXT,
  name TEXT,
  email TEXT,
  mobileNumber TEXT,
  dob TEXT,
  gender TEXT,
  admitDate TEXT,
  roomNumber TEXT,
  ahcccsId TEXT,
  diagnosis TEXT,
  allergies TEXT,
  diet TEXT,
  psychiatricProvider TEXT,
  pcpProvider TEXT,
  admissionStatus TEXT,
  facilityId TEXT,
  isActive INTEGER DEFAULT 1,
  dataJson TEXT,
  createdAt TEXT
);

CREATE TABLE IF NOT EXISTS vitals (
  _id TEXT PRIMARY KEY,
  patientId TEXT NOT NULL,
  temp REAL,
  bp TEXT,
  pulse INTEGER,
  resp INTEGER,
  weight REAL,
  pulseOx INTEGER,
  bloodGlucose INTEGER,
  notes TEXT,
  recordedBy TEXT,
  date TEXT,
  time TEXT,
  createdAt TEXT
);

CREATE TABLE IF NOT EXISTS notes (
  _id TEXT PRIMARY KEY,
  patientId TEXT NOT NULL,
  title TEXT,
  type TEXT,
  author TEXT,
  content TEXT,
  shift TEXT,
  status TEXT DEFAULT 'Completed',
  date TEXT,
  notesData TEXT,
  createdAt TEXT
);

CREATE TABLE IF NOT EXISTS shifts (
  _id TEXT PRIMARY KEY,
  facility_id TEXT,
  label TEXT,
  start_time TEXT,
  end_time TEXT,
  type TEXT,
  timeTaken INTEGER DEFAULT 8
);

CREATE TABLE IF NOT EXISTS shift_progress_notes (
  _id TEXT PRIMARY KEY,
  resident_id TEXT,
  facility_id TEXT,
  shift_id TEXT,
  note_date TEXT,
  shift_start TEXT,
  shift_end TEXT,
  appointment TEXT,
  appointment_other TEXT,
  mood TEXT,
  mood_other TEXT,
  speech TEXT,
  speech_other TEXT,
  behaviors TEXT,
  behaviors_other TEXT,
  redirected INTEGER,
  outing INTEGER,
  therapy TEXT,
  meal_preparation TEXT,
  meals_taken TEXT,
  snacks TEXT,
  awol INTEGER,
  health_welfare_checks INTEGER,
  medication_administered TEXT,
  adls_completed INTEGER,
  prompted_meds INTEGER,
  prompted_adls INTEGER,
  water_temp_adjusted INTEGER,
  clothing_assisted INTEGER,
  activities TEXT,
  activities_other TEXT,
  summary TEXT,
  status TEXT DEFAULT 'Completed',
  signers TEXT,
  notesData TEXT,
  created_by TEXT,
  created_at TEXT,
  updated_at TEXT
);

CREATE TABLE IF NOT EXISTS appointments (
  _id TEXT PRIMARY KEY,
  patientId TEXT,
  title TEXT,
  provider TEXT,
  serviceType TEXT,
  date TEXT,
  time TEXT,
  status TEXT DEFAULT 'Scheduled',
  notes TEXT,
  createdAt TEXT
);

CREATE TABLE IF NOT EXISTS medications (
  _id TEXT PRIMARY KEY,
  patientId TEXT NOT NULL,
  name TEXT NOT NULL,
  dosage TEXT,
  frequency TEXT,
  route TEXT,
  prescriber TEXT,
  status TEXT DEFAULT 'Active',
  startDate TEXT,
  endDate TEXT,
  createdAt TEXT
);

CREATE TABLE IF NOT EXISTS mars_records (
  _id TEXT PRIMARY KEY,
  patientId TEXT NOT NULL,
  medicationId TEXT,
  date TEXT,
  timeSlot TEXT,
  status TEXT DEFAULT 'Administered',
  administeredBy TEXT,
  notes TEXT,
  createdAt TEXT
);

CREATE TABLE IF NOT EXISTS forms (
  _id TEXT PRIMARY KEY,
  patientId TEXT,
  formType TEXT,
  title TEXT,
  status TEXT DEFAULT 'Submitted',
  formData TEXT,
  submittedBy TEXT,
  createdAt TEXT
);

CREATE TABLE IF NOT EXISTS transactions (
  _id TEXT PRIMARY KEY,
  userId TEXT,
  email TEXT,
  name TEXT,
  planName TEXT,
  amount REAL,
  status TEXT DEFAULT 'succeeded',
  cardLast4 TEXT,
  cardBrand TEXT,
  date TEXT,
  receiptId TEXT
);

CREATE TABLE IF NOT EXISTS system_state (
  key TEXT PRIMARY KEY,
  value TEXT
);

CREATE TABLE IF NOT EXISTS custom_forms (
  _id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  type TEXT,
  category TEXT,
  description TEXT,
  fields TEXT,
  submissionsCount INTEGER DEFAULT 0,
  createdAt TEXT,
  updatedAt TEXT
);

CREATE TABLE IF NOT EXISTS form_submissions (
  _id TEXT PRIMARY KEY,
  formId TEXT NOT NULL,
  residentId TEXT,
  residentName TEXT,
  submittedBy TEXT,
  submissionData TEXT,
  status TEXT DEFAULT 'Submitted',
  createdAt TEXT
);
`);

// Prepared statement helpers
export const DBService = {
  // Database instance
  db,

  // Seed from JSON if empty
  seedIfEmpty() {
    const userCount = db.prepare('SELECT count(*) as count FROM users').get().count;
    if (userCount > 0) {
      console.log(`[SQLite] Database verified at ${DB_PATH} with ${userCount} existing users.`);
      return;
    }

    console.log('[SQLite] Database empty. Initializing and migrating seed data...');
    let seedData = null;
    if (fs.existsSync(JSON_BACKUP_PATH)) {
      try {
        seedData = JSON.parse(fs.readFileSync(JSON_BACKUP_PATH, 'utf8'));
      } catch (e) {
        console.error('Error parsing oasis_db.json for seed:', e.message);
      }
    }

    const ALL_PERMISSIONS = "PI:offl:app:f23:lrc1031a:jd:rc:tc:binf:fw4:aps:fw9:i9:onsfov:st:etracking:ic:asam:fprt:et:tr:staffsch:timesheet:perf:iass:nass:tp:fs:sp:ri:pn:discharge:sn:asamc:dp:ron:bhpn:spn:tn:aschedule:cn:ml:ari:rt:mppr:ft:dtf:cft:cf:df:uf:rv:em:mars:mr:ms:rmt:mc:icm:prn:ba:va:ma:ahis:co:inr:reassessment";

    // 1. Facilities
    const facilities = (seedData?.facilities && seedData.facilities.length > 0) ? seedData.facilities : [
      {
        _id: "660000000000000000000002",
        name: "CareNote Main Behavioral Health Care Facility",
        companyName: "CareNote Healthcare System",
        address: "100 Healthcare Blvd, Suite 200, Phoenix, AZ",
        location: "100 Healthcare Blvd, Suite 200, Phoenix, AZ",
        phone: "(555) 234-5678",
        capacity: 24,
        isActive: 1
      },
      {
        _id: "660000000000000000000003",
        name: "CareNote Mountain View Residential Campus",
        companyName: "CareNote Healthcare System",
        address: "450 Valley Way, Scottsdale, AZ",
        location: "450 Valley Way, Scottsdale, AZ",
        phone: "(555) 987-6543",
        capacity: 16,
        isActive: 1
      }
    ];

    const insertFacility = db.prepare(`
      INSERT OR REPLACE INTO facilities (_id, name, companyName, address, location, phone, capacity, isActive)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const f of facilities) {
      insertFacility.run(
        f._id,
        f.name,
        f.companyName || "CareNote Healthcare System",
        f.address || "",
        f.location || f.address || "",
        f.phone || "",
        f.capacity || 20,
        f.isActive !== false ? 1 : 0
      );
    }

    // 2. Users
    const users = (seedData?.users && seedData.users.length > 0) ? seedData.users : [
      {
        _id: "660000000000000000000003",
        name: "Sheku Swaray",
        firstName: "Sheku",
        lastName: "Swaray",
        email: "swaraysheku12@gmail.com",
        password: "Abu@10054",
        userType: "Admin",
        accountType: "adminstrator",
        companyName: "CareNote Healthcare System",
        position: "Clinical Director & Administrator",
        phone: "(555) 345-6789",
        tier: "Growth"
      },
      {
        _id: "660000000000000000000001",
        name: "CareNote Administrator",
        firstName: "Admin",
        lastName: "User",
        email: "admin@carenote.com",
        password: "admin123",
        userType: "Admin",
        accountType: "adminstrator",
        companyName: "CareNote Healthcare System",
        position: "Chief Medical Officer",
        phone: "(555) 234-5678",
        tier: "Growth"
      },
      {
        _id: "660000000000000000000002",
        name: "Charles Smith",
        firstName: "Charles",
        lastName: "Smith",
        email: "charles.smith@carenote.com",
        password: "emp123",
        userType: "Employee",
        accountType: "adminstrator",
        companyName: "CareNote Healthcare System",
        position: "Behavioral Health Technician (BHT)",
        phone: "(555) 345-6789",
        tier: "Growth"
      }
    ];

    const insertUser = db.prepare(`
      INSERT OR REPLACE INTO users (_id, email, password, name, firstName, lastName, userType, accountType, companyName, position, phone, tier, facilityId, activeOrganizationId, organizations, userPermissions, createdAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    for (const u of users) {
      const facilityJson = JSON.stringify(Array.isArray(u.facilityId) ? u.facilityId : facilities);
      const orgsJson = JSON.stringify(u.organizations || [{ _id: facilities[0]._id, name: facilities[0].name, companyName: facilities[0].companyName, address: facilities[0].address }]);
      const permsJson = JSON.stringify(u.userPermissions || { view: ALL_PERMISSIONS, edit: ALL_PERMISSIONS, delete: ALL_PERMISSIONS });
      insertUser.run(
        u._id,
        u.email.toLowerCase().trim(),
        u.password || "password123",
        u.name || `${u.firstName || ''} ${u.lastName || ''}`.trim(),
        u.firstName || u.name?.split(' ')[0] || "User",
        u.lastName || u.name?.split(' ').slice(1).join(' ') || "",
        u.userType || "Employee",
        u.accountType || "adminstrator",
        u.companyName || "CareNote Healthcare System",
        u.position || "Staff Clinician",
        u.phone || "(555) 234-5678",
        u.tier || "Growth",
        facilityJson,
        u.activeOrganizationId || facilities[0]._id,
        orgsJson,
        permsJson,
        u.createdAt || new Date().toISOString()
      );
    }

    // Set default current user in system_state
    db.prepare('INSERT OR REPLACE INTO system_state (key, value) VALUES (?, ?)').run('currentUserEmail', 'swaraysheku12@gmail.com');

    // 3. Patients
    const patients = (seedData?.patients && seedData.patients.length > 0) ? seedData.patients : [
      {
        _id: "660000000000000000000101",
        Id: "RES-1001",
        firstName: "Sarah",
        lastName: "Connor",
        name: "Sarah Connor",
        email: "sarah.connor@oasiscare.org",
        mobileNumber: "(555) 234-5678",
        dob: "1985-05-12",
        gender: "Female",
        admitDate: "2024-01-15",
        roomNumber: "101-A",
        ahcccsId: "A84729103",
        diagnosis: "Post-Traumatic Stress Disorder (PTSD)",
        allergies: "Penicillin, Latex",
        diet: "Regular, Low Sodium",
        psychiatricProvider: "Dr. Evelyn Reed, MD",
        pcpProvider: "Dr. Robert Vance, MD",
        admissionStatus: "Admitted",
        facilityId: facilities[0]._id,
        isActive: 1,
        createdAt: "2024-01-15T09:00:00.000Z"
      },
      {
        _id: "660000000000000000000102",
        Id: "RES-1002",
        firstName: "Michael",
        lastName: "Scott",
        name: "Michael Scott",
        email: "michael.scott@oasiscare.org",
        mobileNumber: "(555) 876-5432",
        dob: "1972-03-15",
        gender: "Male",
        admitDate: "2024-02-01",
        roomNumber: "102-B",
        ahcccsId: "A93847219",
        diagnosis: "Generalized Anxiety Disorder & Mood Regulation",
        allergies: "None",
        diet: "Regular",
        psychiatricProvider: "Dr. Evelyn Reed, MD",
        pcpProvider: "Dr. Robert Vance, MD",
        admissionStatus: "Admitted",
        facilityId: facilities[0]._id,
        isActive: 1,
        createdAt: "2024-02-01T10:30:00.000Z"
      },
      {
        _id: "660000000000000000000103",
        Id: "RES-1003",
        firstName: "Elena",
        lastName: "Rostova",
        name: "Elena Rostova",
        email: "elena.rostova@oasiscare.org",
        mobileNumber: "(555) 432-8765",
        dob: "1994-11-20",
        gender: "Female",
        admitDate: "2024-03-10",
        roomNumber: "201-A",
        ahcccsId: "A74639201",
        diagnosis: "Major Depressive Disorder, Recurrent",
        allergies: "Sulfa Drugs",
        diet: "Vegetarian",
        psychiatricProvider: "Dr. Marcus Brody, DO",
        pcpProvider: "Dr. Robert Vance, MD",
        admissionStatus: "Admitted",
        facilityId: facilities[1]._id,
        isActive: 1,
        createdAt: "2024-03-10T14:15:00.000Z"
      },
      {
        _id: "660000000000000000000104",
        Id: "RES-1004",
        firstName: "David",
        lastName: "Miller",
        name: "David Miller",
        email: "david.miller@oasiscare.org",
        mobileNumber: "(555) 345-9876",
        dob: "1988-08-04",
        gender: "Male",
        admitDate: "2024-03-22",
        roomNumber: "202-B",
        ahcccsId: "A65849204",
        diagnosis: "Bipolar I Disorder & Substance Use Remission",
        allergies: "Aspirin",
        diet: "Diabetic / Controlled Carb",
        psychiatricProvider: "Dr. Evelyn Reed, MD",
        pcpProvider: "Dr. Lisa Wong, MD",
        admissionStatus: "Admitted",
        facilityId: facilities[0]._id,
        isActive: 1,
        createdAt: "2024-03-22T11:00:00.000Z"
      }
    ];

    const insertPatient = db.prepare(`
      INSERT OR REPLACE INTO patients (_id, Id, firstName, lastName, name, email, mobileNumber, dob, gender, admitDate, roomNumber, ahcccsId, diagnosis, allergies, diet, psychiatricProvider, pcpProvider, admissionStatus, facilityId, isActive, dataJson, createdAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    for (const p of patients) {
      insertPatient.run(
        p._id,
        p.Id || `RES-${Date.now().toString().slice(-4)}`,
        p.firstName || p.name?.split(' ')[0] || "Resident",
        p.lastName || p.name?.split(' ').slice(1).join(' ') || "",
        p.name || `${p.firstName || ''} ${p.lastName || ''}`.trim(),
        p.email || "",
        p.mobileNumber || "",
        p.dob || "1990-01-01",
        p.gender || "Other",
        p.admitDate || new Date().toISOString().split('T')[0],
        p.roomNumber || "101",
        p.ahcccsId || "",
        p.diagnosis || "Behavioral Health Observation",
        p.allergies || "None Known",
        p.diet || "Regular",
        p.psychiatricProvider || "Dr. Evelyn Reed, MD",
        p.pcpProvider || "Dr. Robert Vance, MD",
        p.admissionStatus || "Admitted",
        p.facilityId || facilities[0]._id,
        p.isActive !== false ? 1 : 0,
        JSON.stringify(p),
        p.createdAt || new Date().toISOString()
      );
    }

    // 4. Vitals
    const vitals = (seedData?.vitals && seedData.vitals.length > 0) ? seedData.vitals : [
      {
        _id: "vit_001",
        patientId: patients[0]._id,
        temp: 98.6,
        bp: "120/80",
        pulse: 72,
        resp: 16,
        weight: 145.0,
        pulseOx: 99,
        bloodGlucose: 95,
        notes: "Morning routine vitals stable. Resident in good spirits.",
        recordedBy: "Charles Smith, BHT",
        date: new Date().toISOString().split('T')[0],
        time: "08:00 AM",
        createdAt: new Date().toISOString()
      },
      {
        _id: "vit_002",
        patientId: patients[1]._id,
        temp: 98.4,
        bp: "124/82",
        pulse: 76,
        resp: 18,
        weight: 178.5,
        pulseOx: 98,
        bloodGlucose: 102,
        notes: "Vitals normal, no acute distress noted.",
        recordedBy: "Charles Smith, BHT",
        date: new Date().toISOString().split('T')[0],
        time: "08:15 AM",
        createdAt: new Date().toISOString()
      }
    ];

    const insertVital = db.prepare(`
      INSERT OR REPLACE INTO vitals (_id, patientId, temp, bp, pulse, resp, weight, pulseOx, bloodGlucose, notes, recordedBy, date, time, createdAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const v of vitals) {
      insertVital.run(
        v._id,
        v.patientId,
        v.temp || 98.6,
        v.bp || "120/80",
        v.pulse || 72,
        v.resp || 16,
        v.weight || 150.0,
        v.pulseOx || 98,
        v.bloodGlucose || 100,
        v.notes || "",
        v.recordedBy || "Staff Clinician",
        v.date || new Date().toISOString().split('T')[0],
        v.time || "08:00 AM",
        v.createdAt || new Date().toISOString()
      );
    }

    // 5. Notes
    const notes = (seedData?.notes && seedData.notes.length > 0) ? seedData.notes : [
      {
        _id: "note_001",
        patientId: patients[0]._id,
        title: "Shift Progress Note - Morning",
        type: "progressNote",
        author: "Charles Smith, BHT",
        content: "Resident alert, oriented x4, and cooperative throughout morning shift. Participated in morning community meeting and completed personal ADLs independently. Took prescribed breakfast medications without hesitation. Vitals remained stable within normal limits.",
        shift: "07:00 - 15:00",
        status: "Completed",
        date: new Date().toISOString().split('T')[0],
        notesData: JSON.stringify({
          patientId: patients[0]._id,
          residentName: patients[0].name,
          dateOfBirth: patients[0].dob,
          ahcccsId: patients[0].ahcccsId,
          diagnosis: patients[0].diagnosis,
          admitDate: patients[0].admitDate,
          date: new Date().toISOString().split('T')[0],
          facilityId: facilities[0]._id,
          shift: "07:00 - 15:00",
          shiftBeginning: "07:00",
          shiftEnd: "15:00",
          appointment: ["NO"],
          mood: ["Appropriate"],
          speech: ["Appropriate"],
          behaviors: ["Appropriate"],
          residentRedirectedOnBehaviors: false,
          communityOutings: true,
          participatedInGroupIndividualTherapySession: "Yes",
          mealPreparation: "I",
          mealOffered: ["Breakfast eaten", "Lunch eaten"],
          snacksOffered: "Yes",
          awolElopement: false,
          HealthAndWelfareChecks: true,
          medicationAdministered: "Yes",
          adlsCompleted: true,
          promptedToTakeMedications: true,
          promptedToCompleteADLS: true,
          waterTemperature: true,
          appropriateClothing: true,
          activities: ["Socializing", "Coloring"],
          noteSummary: "Resident alert, oriented x4, and cooperative throughout morning shift. Participated in morning community meeting and completed personal ADLs independently. Took prescribed breakfast medications without hesitation. Vitals remained stable within normal limits.",
          bhtSignature: "Charles Smith, BHT",
          dateSigned: new Date().toISOString().split('T')[0],
          signedTime: "02:45 PM",
          saveAsDraft: false,
          signers: [
            { signerId: users[0]._id, name: users[0].name, signature: users[0].name, dateSigned: new Date().toISOString().split('T')[0], signedTime: "02:50 PM" }
          ]
        }),
        createdAt: new Date().toISOString()
      },
      {
        _id: "note_002",
        patientId: patients[1]._id,
        title: "Shift Progress Note - Evening",
        type: "progressNote",
        author: "Charles Smith, BHT",
        content: "Resident engaged in evening recreational therapy and board games with peers. Refused dessert snack but ate full dinner meal. No behavioral escalation noted.",
        shift: "15:00 - 23:00",
        status: "Draft",
        date: new Date().toISOString().split('T')[0],
        notesData: JSON.stringify({
          patientId: patients[1]._id,
          residentName: patients[1].name,
          dateOfBirth: patients[1].dob,
          ahcccsId: patients[1].ahcccsId,
          diagnosis: patients[1].diagnosis,
          admitDate: patients[1].admitDate,
          date: new Date().toISOString().split('T')[0],
          facilityId: facilities[1]._id,
          shift: "15:00 - 23:00",
          shiftBeginning: "15:00",
          shiftEnd: "23:00",
          appointment: ["NO"],
          mood: ["Appropriate"],
          speech: ["Appropriate"],
          behaviors: ["Appropriate"],
          residentRedirectedOnBehaviors: false,
          communityOutings: false,
          participatedInGroupIndividualTherapySession: "Yes",
          mealPreparation: "PA",
          mealOffered: ["Dinner eaten"],
          snacksOffered: "Snacks refused",
          awolElopement: false,
          HealthAndWelfareChecks: true,
          medicationAdministered: "Yes",
          adlsCompleted: true,
          promptedToTakeMedications: true,
          promptedToCompleteADLS: true,
          waterTemperature: true,
          appropriateClothing: true,
          activities: ["Board games"],
          noteSummary: "Resident engaged in evening recreational therapy and board games with peers. Refused dessert snack but ate full dinner meal. No behavioral escalation noted.",
          bhtSignature: "Charles Smith, BHT",
          dateSigned: new Date().toISOString().split('T')[0],
          signedTime: "09:15 PM",
          saveAsDraft: true,
          signers: []
        }),
        createdAt: new Date().toISOString()
      }
    ];

    const insertNote = db.prepare(`
      INSERT OR REPLACE INTO notes (_id, patientId, title, type, author, content, shift, status, date, notesData, createdAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const n of notes) {
      insertNote.run(
        n._id,
        n.patientId,
        n.title || "Clinical Note",
        n.type || "progressNote",
        n.author || "Staff Clinician",
        n.content || "",
        n.shift || "Day Shift",
        n.status || "Completed",
        n.date || new Date().toISOString().split('T')[0],
        typeof n.notesData === 'string' ? n.notesData : JSON.stringify(n.notesData || {}),
        n.createdAt || new Date().toISOString()
      );
    }

    // 6. Medications
    const medications = (seedData?.medications && seedData.medications.length > 0) ? seedData.medications : [
      {
        _id: "med_001",
        patientId: patients[0]._id,
        name: "Sertraline (Zoloft)",
        dosage: "50 mg",
        frequency: "Once Daily in Morning",
        route: "Oral",
        prescriber: "Dr. Evelyn Reed, MD",
        status: "Active",
        startDate: "2024-01-16",
        endDate: "",
        createdAt: "2024-01-16T08:00:00.000Z"
      },
      {
        _id: "med_002",
        patientId: patients[0]._id,
        name: "Prazosin",
        dosage: "2 mg",
        frequency: "Bedtime",
        route: "Oral",
        prescriber: "Dr. Evelyn Reed, MD",
        status: "Active",
        startDate: "2024-01-16",
        endDate: "",
        createdAt: "2024-01-16T08:00:00.000Z"
      },
      {
        _id: "med_003",
        patientId: patients[1]._id,
        name: "Buspirone",
        dosage: "10 mg",
        frequency: "Twice Daily",
        route: "Oral",
        prescriber: "Dr. Evelyn Reed, MD",
        status: "Active",
        startDate: "2024-02-02",
        endDate: "",
        createdAt: "2024-02-02T08:00:00.000Z"
      }
    ];

    const insertMed = db.prepare(`
      INSERT OR REPLACE INTO medications (_id, patientId, name, dosage, frequency, route, prescriber, status, startDate, endDate, createdAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const m of medications) {
      insertMed.run(
        m._id,
        m.patientId,
        m.name,
        m.dosage || "",
        m.frequency || "",
        m.route || "Oral",
        m.prescriber || "Staff Physician",
        m.status || "Active",
        m.startDate || new Date().toISOString().split('T')[0],
        m.endDate || "",
        m.createdAt || new Date().toISOString()
      );
    }

    // 7. Transactions
    const txns = (seedData?.transactions && seedData.transactions.length > 0) ? seedData.transactions : [
      {
        _id: "txn_init_001",
        userId: users[0]._id,
        email: users[0].email,
        name: users[0].name,
        planName: "Growth",
        amount: 99.00,
        status: "succeeded",
        cardLast4: "4242",
        cardBrand: "Visa",
        date: new Date().toISOString(),
        receiptId: "CARENOTE-INIT-001"
      }
    ];

    const insertTxn = db.prepare(`
      INSERT OR REPLACE INTO transactions (_id, userId, email, name, planName, amount, status, cardLast4, cardBrand, date, receiptId)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const tx of txns) {
      insertTxn.run(
        tx._id,
        tx.userId,
        tx.email || "",
        tx.name || "",
        tx.planName || "Growth",
        tx.amount || 99.00,
        tx.status || "succeeded",
        tx.cardLast4 || "4242",
        tx.cardBrand || "Visa",
        tx.date || new Date().toISOString(),
        tx.receiptId || `REC-${Date.now()}`
      );
    }

    console.log('[SQLite] Seed data population completed successfully.');
  },

  // Users
  getUserByEmail(email) {
    if (!email) return null;
    const row = db.prepare('SELECT * FROM users WHERE lower(email) = lower(?)').get(email.trim());
    if (!row) return null;
    return this._formatUser(row);
  },

  getUserById(id) {
    if (!id) return null;
    const row = db.prepare('SELECT * FROM users WHERE _id = ?').get(id);
    if (!row) return null;
    return this._formatUser(row);
  },

  getAllUsers() {
    const rows = db.prepare('SELECT * FROM users ORDER BY createdAt DESC').all();
    return rows.map(r => this._formatUser(r));
  },

  getCurrentUser() {
    const stateRow = db.prepare("SELECT value FROM system_state WHERE key = 'currentUserEmail'").get();
    const email = stateRow ? stateRow.value : 'swaraysheku12@gmail.com';
    let user = this.getUserByEmail(email);
    if (!user) {
      const all = this.getAllUsers();
      user = all[0] || null;
    }
    return user;
  },

  setCurrentUser(email) {
    db.prepare("INSERT OR REPLACE INTO system_state (key, value) VALUES ('currentUserEmail', ?)").run(email);
  },

  upsertUser(u) {
    const existing = this.getUserByEmail(u.email);
    const id = existing ? existing._id : (u._id || `user_${Date.now()}`);
    const email = u.email.toLowerCase().trim();
    const name = u.name || `${u.firstName || ''} ${u.lastName || ''}`.trim() || 'User';
    const firstName = u.firstName || name.split(' ')[0] || 'User';
    const lastName = u.lastName || name.split(' ').slice(1).join(' ') || '';
    const facilities = this.getAllFacilities();
    const facilityJson = JSON.stringify(Array.isArray(u.facilityId) ? u.facilityId : facilities);
    const orgsJson = JSON.stringify(u.organizations || [{ _id: facilities[0]?._id, name: facilities[0]?.name, companyName: facilities[0]?.companyName, address: facilities[0]?.address }]);
    const ALL_PERMISSIONS = "PI:offl:app:f23:lrc1031a:jd:rc:tc:binf:fw4:aps:fw9:i9:onsfov:st:etracking:ic:asam:fprt:et:tr:staffsch:timesheet:perf:iass:nass:tp:fs:sp:ri:pn:discharge:sn:asamc:dp:ron:bhpn:spn:tn:aschedule:cn:ml:ari:rt:mppr:ft:dtf:cft:cf:df:uf:rv:em:mars:mr:ms:rmt:mc:icm:prn:ba:va:ma:ahis:co:inr:reassessment";
    const permsJson = JSON.stringify(u.userPermissions || { view: ALL_PERMISSIONS, edit: ALL_PERMISSIONS, delete: ALL_PERMISSIONS });

    db.prepare(`
      INSERT OR REPLACE INTO users (_id, email, password, name, firstName, lastName, userType, accountType, companyName, position, phone, tier, facilityId, activeOrganizationId, organizations, userPermissions, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      id,
      email,
      u.password || existing?.password || "password123",
      name,
      firstName,
      lastName,
      u.userType || existing?.userType || "Employee",
      u.accountType || existing?.accountType || "adminstrator",
      u.companyName || existing?.companyName || "CareNote Healthcare System",
      u.position || existing?.position || "Staff Clinician",
      u.phone || existing?.phone || "(555) 234-5678",
      u.tier || existing?.tier || "Growth",
      facilityJson,
      u.activeOrganizationId || existing?.activeOrganizationId || facilities[0]?._id || "",
      orgsJson,
      permsJson,
      existing?.createdAt || new Date().toISOString(),
      new Date().toISOString()
    );

    this.setCurrentUser(email);
    return this.getUserById(id);
  },

  _formatUser(row) {
    return {
      _id: row._id,
      id: row._id,
      name: row.name,
      firstName: row.firstName,
      lastName: row.lastName,
      email: row.email,
      password: row.password,
      userType: row.userType,
      accountType: row.accountType,
      companyName: row.companyName,
      position: row.position,
      phone: row.phone,
      tier: row.tier,
      permissionNoteLibrary: true,
      facilityId: JSON.parse(row.facilityId || '[]'),
      activeOrganizationId: row.activeOrganizationId,
      organizations: JSON.parse(row.organizations || '[]'),
      userPermissions: JSON.parse(row.userPermissions || '{}'),
      unreadNotifications: row.unreadNotifications || 0,
      totalUnreadMessages: row.totalUnreadMessages || 0,
      createdAt: row.createdAt
    };
  },

  // Facilities
  getAllFacilities() {
    return db.prepare('SELECT * FROM facilities WHERE isActive = 1').all().map(f => ({
      ...f,
      isActive: Boolean(f.isActive)
    }));
  },

  // Patients / Residents
  getAllPatients(search = '', limit = 50, page = 1) {
    let query = 'SELECT * FROM patients WHERE isActive = 1';
    const params = [];
    if (search && search.trim()) {
      query += ' AND (name LIKE ? OR firstName LIKE ? OR lastName LIKE ? OR Id LIKE ? OR ahcccsId LIKE ?)';
      const s = `%${search.trim()}%`;
      params.push(s, s, s, s, s);
    }
    query += ' ORDER BY createdAt DESC';
    const all = db.prepare(query).all(...params);
    const totalDocs = all.length;
    const offset = (page - 1) * limit;
    const docs = all.slice(offset, offset + limit).map(p => this._formatPatient(p));
    return {
      docs,
      totalDocs,
      limit,
      page,
      totalPages: Math.ceil(totalDocs / limit) || 1
    };
  },

  getPatientById(id) {
    if (!id) return null;
    const row = db.prepare('SELECT * FROM patients WHERE _id = ? OR Id = ?').get(id, id);
    if (!row) return null;
    return this._formatPatient(row);
  },

  upsertPatient(p) {
    const id = p._id || `patient_${Date.now()}`;
    const name = p.name || `${p.firstName || ''} ${p.lastName || ''}`.trim() || 'Resident';
    const firstName = p.firstName || name.split(' ')[0] || 'Resident';
    const lastName = p.lastName || name.split(' ').slice(1).join(' ') || '';

    db.prepare(`
      INSERT OR REPLACE INTO patients (_id, Id, firstName, lastName, name, email, mobileNumber, dob, gender, admitDate, roomNumber, ahcccsId, diagnosis, allergies, diet, psychiatricProvider, pcpProvider, admissionStatus, facilityId, isActive, dataJson, createdAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      id,
      p.Id || `RES-${Date.now().toString().slice(-4)}`,
      firstName,
      lastName,
      name,
      p.email || '',
      p.mobileNumber || '',
      p.dob || '1990-01-01',
      p.gender || 'Other',
      p.admitDate || new Date().toISOString().split('T')[0],
      p.roomNumber || '101',
      p.ahcccsId || '',
      p.diagnosis || 'Behavioral Health Observation',
      p.allergies || 'None Known',
      p.diet || 'Regular',
      p.psychiatricProvider || 'Dr. Evelyn Reed, MD',
      p.pcpProvider || 'Dr. Robert Vance, MD',
      p.admissionStatus || 'Admitted',
      p.facilityId || '',
      p.isActive !== false ? 1 : 0,
      JSON.stringify(p),
      p.createdAt || new Date().toISOString()
    );

    return this.getPatientById(id);
  },

  _formatPatient(row) {
    let custom = {};
    try {
      if (row.dataJson) custom = JSON.parse(row.dataJson);
    } catch {}
    return {
      ...custom,
      _id: row._id,
      id: row._id,
      Id: row.Id,
      name: row.name,
      firstName: row.firstName,
      lastName: row.lastName,
      email: row.email,
      mobileNumber: row.mobileNumber,
      dob: row.dob,
      dateOfBirth: row.dob,
      gender: row.gender,
      admitDate: row.admitDate,
      dateOfAdmit: row.admitDate,
      roomNumber: row.roomNumber,
      ahcccsId: row.ahcccsId,
      diagnosis: row.diagnosis,
      allergies: row.allergies,
      diet: row.diet,
      psychiatricProvider: row.psychiatricProvider,
      pcpProvider: row.pcpProvider,
      primaryCareProvider: row.pcpProvider,
      admissionStatus: row.admissionStatus,
      facilityId: row.facilityId,
      isActive: Boolean(row.isActive),
      createdAt: row.createdAt
    };
  },

  // Vitals
  getVitalsByPatient(patientId) {
    let query = 'SELECT * FROM vitals';
    const params = [];
    if (patientId) {
      query += ' WHERE patientId = ?';
      params.push(patientId);
    }
    query += ' ORDER BY date DESC, time DESC';
    return db.prepare(query).all(...params);
  },

  addVital(v) {
    const id = v._id || `vit_${Date.now()}`;
    const pId = v.patientId || this.getAllPatients().docs[0]?._id || "res_1001";
    db.prepare(`
      INSERT INTO vitals (_id, patientId, temp, bp, pulse, resp, weight, pulseOx, bloodGlucose, notes, recordedBy, date, time, createdAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      id,
      pId,
      v.temp || 98.6,
      v.bp || "120/80",
      v.pulse || 72,
      v.resp || 16,
      v.weight || 150.0,
      v.pulseOx || 98,
      v.bloodGlucose || 100,
      v.notes || "",
      v.recordedBy || "Staff Clinician",
      v.date || new Date().toISOString().split('T')[0],
      v.time || "08:00 AM",
      v.createdAt || new Date().toISOString()
    );
    return db.prepare('SELECT * FROM vitals WHERE _id = ?').get(id);
  },

  // Notes
  _formatNote(n) {
    let data = {};
    try {
      if (typeof n.notesData === 'string' && n.notesData) {
        data = JSON.parse(n.notesData);
      } else if (n.notesData && typeof n.notesData === 'object') {
        data = n.notesData;
      }
    } catch {}

    const patient = this.getPatientById(n.patientId);
    const pObj = patient ? {
      _id: patient._id,
      id: patient._id,
      firstName: patient.firstName || "Resident",
      lastName: patient.lastName || "",
      name: patient.name || `${patient.firstName || ''} ${patient.lastName || ''}`.trim(),
      dob: patient.dob,
      dateOfBirth: patient.dob,
      admitDate: patient.admitDate,
      ahcccsId: patient.ahcccsId || "",
      diagnosis: patient.diagnosis || "",
      roomNumber: patient.roomNumber || "",
      facilityId: patient.facilityId || ""
    } : {
      _id: n.patientId || "patient_unknown",
      id: n.patientId || "patient_unknown",
      firstName: "Resident",
      lastName: "",
      name: "Resident",
      dob: "1990-01-01",
      dateOfBirth: "1990-01-01",
      admitDate: n.date || new Date().toISOString().split('T')[0],
      ahcccsId: "",
      diagnosis: ""
    };

    return {
      ...n,
      ...data,
      _id: n._id,
      id: n._id,
      patientId: pObj,
      residentName: data.residentName || pObj.name,
      dateOfBirth: data.dateOfBirth || pObj.dob,
      admitDate: data.admitDate || pObj.admitDate,
      ahcccsId: data.ahcccsId || pObj.ahcccsId,
      diagnosis: data.diagnosis || pObj.diagnosis,
      facilityId: data.facilityId || pObj.facilityId || (this.getAllFacilities()[0]?._id || ""),
      shiftBeginning: data.shiftBeginning || "07:00",
      shiftEnd: data.shiftEnd || "15:00",
      shift: data.shift || n.shift || "07:00-15:00",
      date: n.date || data.date || new Date().toISOString().split('T')[0],
      status: n.status || (data.saveAsDraft ? "Draft" : "Completed"),
      saveAsDraft: Boolean(n.status === "Draft" || data.saveAsDraft === true),
      appointment: data.appointment || ["NO"],
      mood: data.mood || ["Appropriate"],
      speech: data.speech || ["Appropriate"],
      behaviors: data.behaviors || ["Appropriate"],
      residentRedirectedOnBehaviors: data.residentRedirectedOnBehaviors !== undefined ? data.residentRedirectedOnBehaviors : true,
      communityOutings: data.communityOutings !== undefined ? data.communityOutings : true,
      participatedInGroupIndividualTherapySession: data.participatedInGroupIndividualTherapySession || "Yes",
      mealPreparation: data.mealPreparation || "I",
      mealOffered: data.mealOffered || ["Breakfast eaten", "Lunch eaten"],
      snacksOffered: data.snacksOffered || "Yes",
      awolElopement: data.awolElopement !== undefined ? data.awolElopement : false,
      HealthAndWelfareChecks: data.HealthAndWelfareChecks !== undefined ? data.HealthAndWelfareChecks : true,
      medicationAdministered: data.medicationAdministered || "Yes",
      adlsCompleted: data.adlsCompleted !== undefined ? data.adlsCompleted : true,
      promptedToTakeMedications: data.promptedToTakeMedications !== undefined ? data.promptedToTakeMedications : true,
      promptedToCompleteADLS: data.promptedToCompleteADLS !== undefined ? data.promptedToCompleteADLS : true,
      waterTemperature: data.waterTemperature !== undefined ? data.waterTemperature : true,
      appropriateClothing: data.appropriateClothing !== undefined ? data.appropriateClothing : true,
      activities: data.activities || ["Socializing"],
      noteSummary: data.noteSummary || n.content || "",
      bhtSignature: data.bhtSignature || "",
      dateSigned: data.dateSigned || "",
      signedTime: data.signedTime || "",
      adminSignature: data.adminSignature || "",
      adminDateSigned: data.adminDateSigned || "",
      adminSignedTime: data.adminSignedTime || "",
      signers: data.signers || [],
      notesData: data
    };
  },

  getNotes(patientId = null, type = null) {
    let query = 'SELECT * FROM notes WHERE 1=1';
    const params = [];
    if (patientId) {
      query += ' AND patientId = ?';
      params.push(patientId);
    }
    if (type) {
      query += ' AND type = ?';
      params.push(type);
    }
    query += ' ORDER BY createdAt DESC';
    return db.prepare(query).all(...params).map(n => this._formatNote(n));
  },

  getNoteById(id) {
    if (!id) return null;
    const row = db.prepare('SELECT * FROM notes WHERE _id = ?').get(id);
    if (!row) return null;
    return this._formatNote(row);
  },

  getShifts(facilityId = null) {
    // Seed shifts if table is empty
    const count = db.prepare('SELECT count(*) as count FROM shifts').get().count;
    if (count === 0) {
      const defaultShifts = [
        { _id: "shift_morning", label: "Morning (7:00 AM - 3:00 PM)", start_time: "07:00", end_time: "15:00", type: "Morning (7:00 AM - 3:00 PM)", timeTaken: 8 },
        { _id: "shift_evening", label: "Evening (3:00 PM - 11:00 PM)", start_time: "15:00", end_time: "23:00", type: "Evening (3:00 PM - 11:00 PM)", timeTaken: 8 },
        { _id: "shift_night", label: "Night (11:00 PM - 7:00 AM)", start_time: "23:00", end_time: "07:00", type: "Night (11:00 PM - 7:00 AM)", timeTaken: 8 }
      ];
      const insertShift = db.prepare(`
        INSERT OR REPLACE INTO shifts (_id, facility_id, label, start_time, end_time, type, timeTaken)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `);
      for (const s of defaultShifts) {
        insertShift.run(s._id, facilityId || "all", s.label, s.start_time, s.end_time, s.type, s.timeTaken);
      }
    }

    let rows;
    if (facilityId) {
      rows = db.prepare("SELECT * FROM shifts WHERE facility_id = ? OR facility_id = 'all'").all(facilityId);
    } else {
      rows = db.prepare('SELECT * FROM shifts').all();
    }
    return rows.map(r => ({
      _id: r._id,
      id: r._id,
      facility_id: r.facility_id,
      label: r.label,
      start: r.start_time,
      end: r.end_time,
      type: r.type || r.label,
      timeTaken: r.timeTaken || 8
    }));
  },

  addNote(n) {
    const id = n._id || `note_${Date.now()}`;
    const pId = typeof n.patientId === 'object' ? (n.patientId._id || n.patientId.id) : (n.patientId || this.getAllPatients().docs[0]?._id);
    const dataStr = typeof n.notesData === 'string' ? n.notesData : JSON.stringify(n.notesData || n || {});
    const now = new Date().toISOString();
    const status = n.saveAsDraft ? "Draft" : (n.status || "Completed");

    // 1. Insert into notes table
    db.prepare(`
      INSERT INTO notes (_id, patientId, title, type, author, content, shift, status, date, notesData, createdAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      id,
      pId || "",
      n.title || (n.shift ? `Shift Progress Note - ${n.shift}` : "Daily Shift Progress Note"),
      n.type || "progressNote",
      n.author || (this.getCurrentUser()?.name || "Charles Smith, BHT"),
      n.noteSummary || n.content || "",
      n.shiftTiming || n.shift || "Day Shift (07:00 - 15:00)",
      status,
      n.date || n.noteDate || now.split('T')[0],
      dataStr,
      n.createdAt || now
    );

    // 2. Insert into dedicated shift_progress_notes table
    try {
      db.prepare(`
        INSERT OR REPLACE INTO shift_progress_notes (
          _id, resident_id, facility_id, shift_id, note_date, shift_start, shift_end,
          appointment, appointment_other, mood, mood_other, speech, speech_other,
          behaviors, behaviors_other, redirected, outing, therapy, meal_preparation,
          meals_taken, snacks, awol, health_welfare_checks, medication_administered,
          adls_completed, prompted_meds, prompted_adls, water_temp_adjusted,
          clothing_assisted, activities, activities_other, summary, status, signers,
          notesData, created_by, created_at, updated_at
        ) VALUES (
          ?, ?, ?, ?, ?, ?, ?,
          ?, ?, ?, ?, ?, ?,
          ?, ?, ?, ?, ?, ?,
          ?, ?, ?, ?, ?,
          ?, ?, ?, ?,
          ?, ?, ?, ?, ?, ?,
          ?, ?, ?, ?
        )
      `).run(
        id,
        pId || "",
        n.facilityId || "",
        n.shiftId || "",
        n.date || n.noteDate || now.split('T')[0],
        n.shiftBeginning || "",
        n.shiftEnd || "",
        JSON.stringify(n.appointment || []),
        n.appointmentOther || "",
        JSON.stringify(n.mood || []),
        n.moodOther || "",
        JSON.stringify(n.speech || []),
        n.speechOther || "",
        JSON.stringify(n.behaviors || []),
        n.behaviorsOther || "",
        n.residentRedirectedOnBehaviors ? 1 : 0,
        n.communityOutings ? 1 : 0,
        n.participatedInGroupIndividualTherapySession || "Yes",
        n.mealPreparation || "I",
        JSON.stringify(n.mealOffered || []),
        n.snacksOffered || "Yes",
        n.awolElopement ? 1 : 0,
        n.HealthAndWelfareChecks ? 1 : 0,
        n.medicationAdministered || "Yes",
        n.adlsCompleted ? 1 : 0,
        n.promptedToTakeMedications ? 1 : 0,
        n.promptedToCompleteADLS ? 1 : 0,
        n.waterTemperature ? 1 : 0,
        n.appropriateClothing ? 1 : 0,
        JSON.stringify(n.activities || []),
        n.activitiesOther || "",
        n.noteSummary || n.content || "",
        status,
        JSON.stringify(n.signers || []),
        dataStr,
        n.author || (this.getCurrentUser()?.name || "Charles Smith, BHT"),
        n.createdAt || now,
        now
      );
    } catch (err) {
      console.error('[DB] Error inserting into shift_progress_notes:', err.message);
    }

    return this.getNoteById(id);
  },

  updateNote(id, n) {
    if (!id) return null;
    const existing = db.prepare('SELECT * FROM notes WHERE _id = ?').get(id);
    if (!existing) return null;
    const prevData = JSON.parse(existing.notesData || '{}');
    const mergedData = { ...prevData, ...n };
    const dataStr = JSON.stringify(mergedData);
    const title = n.title || existing.title;
    const author = n.author || existing.author;
    const content = n.noteSummary || n.content || existing.content;
    const shift = n.shiftTiming || n.shift || existing.shift;
    const status = n.saveAsDraft ? "Draft" : (n.status || existing.status);
    const date = n.date || n.noteDate || existing.date;
    const now = new Date().toISOString();

    db.prepare(`
      UPDATE notes
      SET title = ?, author = ?, content = ?, shift = ?, status = ?, date = ?, notesData = ?
      WHERE _id = ?
    `).run(title, author, content, shift, status, date, dataStr, id);

    try {
      db.prepare(`
        UPDATE shift_progress_notes
        SET summary = ?, status = ?, note_date = ?, shift_start = ?, shift_end = ?, notesData = ?, updated_at = ?
        WHERE _id = ?
      `).run(content, status, date, n.shiftBeginning || "", n.shiftEnd || "", dataStr, now, id);
    } catch (err) {
      // Ignore if table updated
    }

    return this.getNoteById(id);
  },

  deleteNote(id) {
    if (!id) return false;
    db.prepare('DELETE FROM notes WHERE _id = ?').run(id);
    try {
      db.prepare('DELETE FROM shift_progress_notes WHERE _id = ?').run(id);
    } catch (e) {}
    return true;
  },

  // Medications
  getMedications(patientId = null) {
    let query = 'SELECT * FROM medications WHERE status != "Discontinue"';
    const params = [];
    if (patientId) {
      query += ' AND patientId = ?';
      params.push(patientId);
    }
    query += ' ORDER BY createdAt DESC';
    return db.prepare(query).all(...params);
  },

  // Transactions
  getTransactions(userId = null) {
    let query = 'SELECT * FROM transactions';
    const params = [];
    if (userId) {
      query += ' WHERE userId = ?';
      params.push(userId);
    }
    query += ' ORDER BY date DESC';
    return db.prepare(query).all(...params);
  },

  addTransaction(tx) {
    const id = tx._id || `txn_${Date.now()}`;
    db.prepare(`
      INSERT INTO transactions (_id, userId, email, name, planName, amount, status, cardLast4, cardBrand, date, receiptId)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      id,
      tx.userId || "",
      tx.email || "",
      tx.name || "",
      tx.planName || "Growth",
      tx.amount || 99.00,
      tx.status || "succeeded",
      tx.cardLast4 || "4242",
      tx.cardBrand || "Visa",
      tx.date || new Date().toISOString(),
      tx.receiptId || `REC-${Date.now().toString().slice(-8)}`
    );
    return db.prepare('SELECT * FROM transactions WHERE _id = ?').get(id);
  },

  // Custom Clinical Forms & Templates
  getCustomForms() {
    const rows = db.prepare('SELECT * FROM custom_forms ORDER BY createdAt DESC').all();
    return rows.map(r => ({
      ...r,
      fields: JSON.parse(r.fields || '[]')
    }));
  },

  upsertCustomForm(f) {
    const id = f._id || f.id || `cform_${Date.now()}`;
    const fieldsStr = typeof f.fields === 'string' ? f.fields : JSON.stringify(f.fields || []);
    const now = new Date().toISOString();

    const existing = db.prepare('SELECT _id FROM custom_forms WHERE _id = ?').get(id);
    if (existing) {
      db.prepare(`
        UPDATE custom_forms
        SET name = ?, type = ?, category = ?, description = ?, fields = ?, updatedAt = ?
        WHERE _id = ?
      `).run(f.name || 'Custom Clinical Form', f.type || 'Clinical Assessment', f.category || 'General', f.description || '', fieldsStr, now, id);
    } else {
      db.prepare(`
        INSERT INTO custom_forms (_id, name, type, category, description, fields, submissionsCount, createdAt, updatedAt)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(id, f.name || 'Custom Clinical Form', f.type || 'Clinical Assessment', f.category || 'General', f.description || '', fieldsStr, 0, now, now);
    }

    const row = db.prepare('SELECT * FROM custom_forms WHERE _id = ?').get(id);
    return row ? { ...row, fields: JSON.parse(row.fields || '[]') } : null;
  },

  deleteCustomForm(id) {
    if (!id) return false;
    db.prepare('DELETE FROM custom_forms WHERE _id = ?').run(id);
    db.prepare('DELETE FROM form_submissions WHERE formId = ?').run(id);
    return true;
  },

  getClinicalTemplates() {
    return [
      {
        id: 'tpl_pain_scale',
        name: 'Comprehensive Pain & Comfort Scale',
        type: 'Vitals & Monitoring',
        category: 'Vitals & Monitoring',
        description: 'Standardized numeric and visual rating scale for pain intensity, location, and relief interventions.',
        fields: [
          { id: 'f1', type: 'rating', label: 'Pain Level (0 = No Pain, 10 = Severe)', required: true },
          { id: 'f2', type: 'text', label: 'Pain Location / Body Area', required: true },
          { id: 'f3', type: 'select', label: 'Pain Character', options: 'Throbbing, Dull ache, Sharp, Burning, Tingling', required: true },
          { id: 'f4', type: 'textarea', label: 'Interventions Provided & Resident Response', required: true }
        ]
      },
      {
        id: 'tpl_fall_risk',
        name: 'Rapid Fall Risk & Safety Assessment',
        type: 'Safety & Incident Reporting',
        category: 'Safety & Incident Reporting',
        description: 'Quick check of gait, balance, assistive device usage, and mental awareness.',
        fields: [
          { id: 'f1', type: 'radio', label: 'History of Falls within last 3 months', options: 'Yes, No', required: true },
          { id: 'f2', type: 'radio', label: 'Assistive Device in Use', options: 'None, Cane, Walker, Wheelchair', required: true },
          { id: 'f3', type: 'select', label: 'Gait / Transferring Ability', options: 'Normal/Independent, Weak/Needs Cueing, Impaired/2-person assist', required: true },
          { id: 'f4', type: 'checkbox', label: 'Safety Precautions Deployed', options: 'Non-skid socks, Bed low position, Call light within reach, Clear pathway', required: true },
          { id: 'f5', type: 'textarea', label: 'Staff Safety Actions / Recommendations' }
        ]
      },
      {
        id: 'tpl_nutrition',
        name: 'Dietary Intake & Meal Hydration Log',
        type: 'Intake & Assessment',
        category: 'Intake & Assessment',
        description: 'Track meal percentages, hydration fluid intake, and appetite changes.',
        fields: [
          { id: 'f1', type: 'select', label: 'Meal Observed', options: 'Breakfast, Lunch, Dinner, Snack', required: true },
          { id: 'f2', type: 'select', label: 'Percentage of Meal Consumed', options: '0 - 25%, 26 - 50%, 51 - 75%, 76 - 100%', required: true },
          { id: 'f3', type: 'number', label: 'Fluid Intake (in oz or mL)', required: true },
          { id: 'f4', type: 'textarea', label: 'Special Diet Adherence & Nutritional Notes' }
        ]
      }
    ];
  },

  addFormSubmission(sub) {
    const id = sub._id || `sub_${Date.now()}`;
    const dataStr = typeof sub.submissionData === 'string' ? sub.submissionData : JSON.stringify(sub.submissionData || sub.values || {});
    const now = new Date().toISOString();

    db.prepare(`
      INSERT INTO form_submissions (_id, formId, residentId, residentName, submittedBy, submissionData, status, createdAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      id,
      sub.formId,
      sub.residentId || "",
      sub.residentName || "Resident",
      sub.submittedBy || "Staff Clinician",
      dataStr,
      sub.status || "Submitted",
      now
    );

    // Increment submission count
    try {
      db.prepare('UPDATE custom_forms SET submissionsCount = submissionsCount + 1 WHERE _id = ?').run(sub.formId);
    } catch (e) {}

    return db.prepare('SELECT * FROM form_submissions WHERE _id = ?').get(id);
  },

  getFormSubmissions(formId) {
    let query = 'SELECT * FROM form_submissions';
    const params = [];
    if (formId) {
      query += ' WHERE formId = ?';
      params.push(formId);
    }
    query += ' ORDER BY createdAt DESC';
    const rows = db.prepare(query).all(...params);
    return rows.map(r => ({
      ...r,
      values: JSON.parse(r.submissionData || '{}')
    }));
  }
};

// Auto-seed on load
DBService.seedIfEmpty();

export default DBService;
