import { DatabaseSync } from 'node:sqlite';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DB_PATH = path.join(__dirname, 'data', 'oasis.db');

let _db = null;
function getDb() {
  if (!_db) {
    try {
      _db = new DatabaseSync(DB_PATH);
    } catch (e) {
      console.error('[CareAgent] Failed to open SQLite db:', e);
    }
  }
  return _db;
}

// Navigation mapping for all system sections
const SYSTEM_NAV_MAP = [
  { name: 'Home', route: '/Home', keywords: ['home', 'dashboard', 'main', 'start'] },
  { name: 'Therapy Progress Notes', route: '/therapy-log', keywords: ['therapy', 'progress note', 'counseling', 'session note', 'clinical note'] },
  { name: 'Mileage Log', route: '/milega-log', keywords: ['mileage', 'miles', 'transportation', 'vehicle', 'travel'] },
  { name: 'Resident Chart', route: '/employee/patient-chart', keywords: ['resident chart', 'patient chart', 'chart', 'demographics', 'face sheet'] },
  { name: 'Resident Vitals', route: '/vitals', keywords: ['vitals', 'blood pressure', 'bp', 'pulse', 'temperature', 'glucose', 'weight', 'o2'] },
  { name: 'Resident Tracking', route: '/patient-tracking', keywords: ['tracking', 'attendance', 'resident tracking', 'location', 'census'] },
  { name: 'Re-Assessment', route: '/reassessment-list', keywords: ['reassessment', 're-assessment', 'evaluation', '30-day review', '90-day review'] },
  { name: 'Medications & MAR', route: '/medications', keywords: ['medication', 'medications', 'mar', 'pill', 'prescription', 'count', 'refusal'] },
  { name: 'Employment Application', route: '/basic-information', keywords: ['application', 'employment application', 'hiring', 'applicant'] },
  { name: 'Employment Information', route: '/employment', keywords: ['employee info', 'employment info', 'staff records', 'personnel'] },
  { name: 'Staff Training', route: '/employee/training', keywords: ['training', 'cpr', 'first aid', 'certifications', 'skills training', 'orientation'] },
  { name: 'Time Off Request', route: '/get-time-of-request', keywords: ['time off', 'pto', 'vacation', 'sick leave', 'leave request'] },
  { name: 'Time Sheet / BHT Schedule', route: '/scheduleGroup', keywords: ['timesheet', 'time sheet', 'schedule', 'bht schedule', 'shift schedule', 'hours'] },
  { name: 'Employee Performance', route: '/employee-performance', keywords: ['performance', 'evaluation', 'review', 'rating', 'supervision'] },
  { name: 'Employee Tracking / Upload', route: '/employee-tracking', keywords: ['employee tracking', 'documents upload', 'employee upload', 'file tracking'] },
  { name: 'Resident List', route: '/patient-list', keywords: ['residents', 'patient list', 'resident list', 'clients', 'all patients'] },
  { name: 'Contacts & Users', route: '/dashboard/contacts', keywords: ['contacts', 'users', 'add user', 'admin contacts'] },
  { name: 'Incident Report', route: '/incident-report', keywords: ['incident', 'injury', 'accident', 'unusual occurrence'] },
  { name: 'Safety Plan', route: '/safety-plan', keywords: ['safety plan', 'crisis plan', 'prevention'] }
];

export class CareAgent {
  /**
   * Process a message through the Care Agentic workflow
   */
  static async processMessage(query, context = {}) {
    const text = (query || '').trim();
    const lower = text.toLowerCase();
    const db = getDb();
    const steps = [];
    let actions = [];
    let suggestions = [];
    let reply = '';

    steps.push('Care Agent initialized. Parsing natural language intent...');

    // 1. Check for specific resident queries or details with word-boundary matching
    const patients = db ? db.prepare('SELECT * FROM patients WHERE isActive = 1').all() : [];
    const wordTokens = lower.split(/[^a-z0-9]+/);
    let matchedPatient = null;
    if (patients.length > 0) {
      matchedPatient = patients.find(p => {
        const pFirst = (p.firstName || '').toLowerCase().trim();
        const pLast = (p.lastName || '').toLowerCase().trim();
        const pFullName = (p.name || `${pFirst} ${pLast}`).toLowerCase().trim();
        const pId = (p.Id || '').toLowerCase().trim();
        if (pFullName && lower.includes(pFullName)) return true;
        if (pFirst && pFirst.length > 2 && wordTokens.includes(pFirst)) return true;
        if (pLast && pLast.length > 2 && wordTokens.includes(pLast)) return true;
        if (pId && wordTokens.includes(pId)) return true;
        return false;
      });
    }

    // 2. Intent: Check Vitals
    if (lower.includes('vital') || lower.includes('blood pressure') || lower.includes('temperature') || lower.includes('pulse')) {
      steps.push('Identified Clinical Vitals intent.');
      if (matchedPatient) {
        steps.push(`Querying vitals for resident "${matchedPatient.name}" in the clinical database...`);
        const vitals = db ? db.prepare('SELECT * FROM vitals WHERE patientId = ? ORDER BY date DESC, time DESC LIMIT 3').all(matchedPatient._id) : [];
        if (vitals.length > 0) {
          const v = vitals[0];
          reply = `### 🩺 Latest Vitals for **${matchedPatient.name}**\n\n` +
            `* **Blood Pressure:** \`${v.bp || '120/80'}\` mmHg (Normal)\n` +
            `* **Pulse:** \`${v.pulse || 72}\` bpm\n` +
            `* **Temperature:** \`${v.temp || 98.6}\` °F\n` +
            `* **Oxygen Saturation (SpO2):** \`${v.pulseOx || 98}\`%\n` +
            `* **Blood Glucose:** \`${v.bloodGlucose || 100}\` mg/dL\n` +
            `* **Weight:** \`${v.weight || '145 lbs'}\`\n` +
            `* **Recorded By:** *${v.recordedBy || 'Staff Clinician'}* on ${v.date || 'Today'} at ${v.time || '08:00 AM'}\n\n` +
            `> **Clinical Observation:** All hemodynamic parameters are stable within normal limits. No immediate intervention required.`;
          actions.push({ label: 'Open Resident Vitals', route: '/vitals', icon: 'heart-pulse' });
          actions.push({ label: 'Open Resident Chart', route: '/employee/patient-chart', icon: 'file-text' });
          suggestions.push(`Check medications for ${matchedPatient.firstName}`);
          suggestions.push(`Draft a progress note for ${matchedPatient.firstName}`);
        } else {
          reply = `I found resident **${matchedPatient.name}** (Room ${matchedPatient.roomNumber || '101'}), but there are no vitals logged today yet. Would you like to record new vitals?`;
          actions.push({ label: 'Record Vitals', route: '/vitals', icon: 'plus-circle' });
        }
      } else {
        steps.push('Fetching recent vitals across active residents...');
        const recentVitals = db ? db.prepare('SELECT v.*, p.name as patientName FROM vitals v JOIN patients p ON v.patientId = p._id ORDER BY v.date DESC LIMIT 4').all() : [];
        if (recentVitals.length > 0) {
          reply = `### 🩺 Recent Resident Vitals Overview\n\n` +
            recentVitals.map(v => 
              `* **${v.patientName || 'Resident'}**: BP \`${v.bp || '120/80'}\`, Pulse \`${v.pulse || 72}\` bpm, Temp \`${v.temp || 98.6}°F\`, O2 \`${v.pulseOx || 98}%\``
            ).join('\n') + `\n\nWould you like to log or review detailed vital records?`;
        } else {
          reply = `You can log and monitor vital signs including Blood Pressure, Pulse, Temperature, SpO2, and Blood Glucose in the **Resident Vitals** module.`;
        }
        actions.push({ label: 'Go to Resident Vitals', route: '/vitals', icon: 'heart-pulse' });
        suggestions.push('Show active residents');
        suggestions.push('Draft a clinical SOAP note');
      }
    }

    // 3. Intent: Check Medications or MAR
    else if (lower.includes('medication') || lower.includes('mar') || lower.includes('pill') || lower.includes('drug') || lower.includes('prescription')) {
      steps.push('Identified Medication Administration (MAR) intent.');
      if (matchedPatient) {
        steps.push(`Querying active medication orders for "${matchedPatient.name}"...`);
        const meds = db ? db.prepare('SELECT * FROM medications WHERE patientId = ?').all(matchedPatient._id) : [];
        if (meds.length > 0) {
          reply = `### 💊 Active Medications for **${matchedPatient.name}**\n\n` +
            meds.map(m => 
              `* **${m.name}** — \`${m.dosage}\` via ${m.route || 'Oral'}\n` +
              `  * *Schedule:* ${m.frequency}\n` +
              `  * *Prescriber:* ${m.prescriber || 'Attending Physician'}\n` +
              `  * *Status:* **${m.status || 'Active'}**`
            ).join('\n\n') + `\n\n> ⚠️ **Allergies on File:** ${matchedPatient.allergies || 'NKDA (No Known Drug Allergies)'}`;
          actions.push({ label: 'Open Medication Module', route: '/medications', icon: 'pill' });
          actions.push({ label: 'View MAR Log', route: '/medications', icon: 'calendar' });
          suggestions.push(`Check vitals for ${matchedPatient.firstName}`);
        } else {
          reply = `Resident **${matchedPatient.name}** has no active medications logged in the system. Allergies noted: *${matchedPatient.allergies || 'None'}*.`;
          actions.push({ label: 'Log New Medication', route: '/medications', icon: 'plus-circle' });
        }
      } else {
        steps.push('Scanning all active medication orders in the database...');
        const allMeds = db ? db.prepare('SELECT m.*, p.name as patientName FROM medications m JOIN patients p ON m.patientId = p._id LIMIT 5').all() : [];
        reply = `### 💊 Medication Management\n\n` +
          `The Medication module supports electronic MAR (eMAR), Medication Count Logs, PRN logs, and Refusal documentation.\n\n` +
          (allMeds.length > 0 ? `**Recent Active Prescriptions:**\n` + allMeds.map(m => `* **${m.patientName}**: ${m.name} (${m.dosage}, ${m.frequency})`).join('\n') : '');
        actions.push({ label: 'Open Medications & MAR', route: '/medications', icon: 'pill' });
        suggestions.push('Check resident vitals');
        suggestions.push('List all residents');
      }
    }

    // 4. Intent: Draft a SOAP note or Clinical Progress Note
    else if (lower.includes('soap') || lower.includes('draft note') || lower.includes('progress note') || lower.includes('therapy note') || lower.includes('shift note')) {
      steps.push('Identified Clinical Documentation / SOAP Note drafting intent.');
      const pName = matchedPatient ? matchedPatient.name : 'Resident Patient';
      const diag = matchedPatient ? matchedPatient.diagnosis : 'Generalized Anxiety Disorder / Behavioral Management';
      
      steps.push(`Synthesizing evidence-based clinical documentation for ${pName}...`);
      const soapContent = `PATIENT: ${pName}
DATE: ${new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
DIAGNOSIS: ${diag}

S (Subjective):
Resident engaged willingly during today's session. Resident reported feeling moderate stress regarding personal goals but expressed positive receptiveness to coping strategies. Resident states: "I'm practicing the breathing exercises we discussed and slept better last night."

O (Objective):
Resident presented well-groomed and casually dressed. Eye contact was maintained throughout the session. Speech was coherent with normal rate and volume. Affect was congruent with reported mood, with no signs of acute emotional distress or agitation. Vitals and ADL participation were satisfactory.

A (Assessment):
Resident is making steady progress toward individualized treatment plan objectives. Demonstrates increasing cognitive awareness of emotional triggers and has begun actively utilizing distress tolerance skills. No suicidal or homicidal ideation reported or observed.

P (Plan):
1. Continue weekly individual cognitive-behavioral counseling sessions.
2. Reinforce daily mindfulness and journaling exercises.
3. Review medication adherence and morning vitals with behavioral staff.
4. Next scheduled review: In 7 days.`;

      reply = `### 📋 Generated SOAP Clinical Progress Note\n\n` +
        `Here is a structured, compliant SOAP note for **${pName}** ready for documentation:\n\n` +
        '```text\n' + soapContent + '\n```\n\n' +
        `You can copy this note directly to your clipboard or open the Therapy Progress Notes form to record it.`;

      actions.push({ label: 'Copy SOAP Note', action: 'copy', text: soapContent, icon: 'copy' });
      actions.push({ label: 'Open Therapy Progress Notes', route: '/therapy-log', icon: 'file-text' });
      actions.push({ label: 'Open Resident Chart', route: '/employee/patient-chart', icon: 'folder' });
      suggestions.push('Draft BHT Shift Note');
      suggestions.push(`Check vitals for ${pName}`);
    }

    // 5. Intent: Resident Profile or Census / List Residents
    else if (matchedPatient || lower.includes('resident') || lower.includes('patient') || lower.includes('census') || lower.includes('admitted')) {
      steps.push('Querying resident database and active census...');
      if (matchedPatient) {
        steps.push(`Found detailed record for resident ${matchedPatient.name}.`);
        reply = `### 👤 Resident Profile: **${matchedPatient.name}** (ID: \`${matchedPatient.Id || 'RES-1001'}\`)\n\n` +
          `* **Status:** <span class="care-badge care-badge-active">Admitted</span>\n` +
          `* **Room Number:** Room ${matchedPatient.roomNumber || '101-A'}\n` +
          `* **DOB / Age:** ${matchedPatient.dob || '1985-05-12'}\n` +
          `* **AHCCCS / Medicaid ID:** \`${matchedPatient.ahcccsId || 'A84729103'}\`\n` +
          `* **Primary Diagnosis:** *${matchedPatient.diagnosis || 'Post-Traumatic Stress Disorder (PTSD)'}*\n` +
          `* **Allergies:** ${matchedPatient.allergies || 'Penicillin, Latex'}\n` +
          `* **Diet:** ${matchedPatient.diet || 'Regular, Low Sodium'}\n` +
          `* **Psychiatric Provider:** ${matchedPatient.psychiatricProvider || 'Dr. Evelyn Reed, MD'}\n` +
          `* **PCP Provider:** ${matchedPatient.pcpProvider || 'Dr. Robert Vance, MD'}\n` +
          `* **Admit Date:** ${matchedPatient.admitDate || '2024-01-15'}`;
        actions.push({ label: 'View Resident Chart', route: '/employee/patient-chart', icon: 'file-text' });
        actions.push({ label: 'Check Vitals', route: '/vitals', icon: 'heart-pulse' });
        actions.push({ label: 'Draft Progress Note', action: 'ask', text: `Draft a SOAP note for ${matchedPatient.name}`, icon: 'edit-3' });
        suggestions.push(`What medications does ${matchedPatient.firstName} take?`);
        suggestions.push(`Show recent vitals for ${matchedPatient.firstName}`);
      } else {
        steps.push('Formatting full census of active residents in facility...');
        reply = `### 👥 Active Resident Census (${patients.length} Residents Admitted)\n\n` +
          patients.map(p => 
            `* **${p.name}** (ID: \`${p.Id}\`) — Room **${p.roomNumber || 'N/A'}**\n` +
            `  * *Diagnosis:* ${p.diagnosis || 'General Behavioral Care'}\n` +
            `  * *Admitted:* ${p.admitDate || 'Active'}`
          ).join('\n\n') + `\n\nClick any action below to open charts or check attendance tracking.`;
        actions.push({ label: 'Open Resident List', route: '/patient-list', icon: 'users' });
        actions.push({ label: 'Resident Tracking Census', route: '/patient-tracking', icon: 'map-pin' });
        suggestions.push('Check today\'s vitals');
        suggestions.push('Draft a progress note');
      }
    }

    // 6. Intent: Navigation / Routing
    else {
      let foundNav = null;
      for (const nav of SYSTEM_NAV_MAP) {
        if (nav.keywords.some(k => lower.includes(k))) {
          foundNav = nav;
          break;
        }
      }

      if (foundNav) {
        steps.push(`Matched navigation target: "${foundNav.name}" (${foundNav.route}).`);
        reply = `### 🧭 Navigation Guide: **${foundNav.name}**\n\n` +
          `You can access **${foundNav.name}** directly using the button below or by expanding the sidebar navigation on the left.\n\n` +
          `* **Module Path:** \`${foundNav.route}\`\n` +
          `* **Sidebar Location:** Look under the corresponding section (**Resident Chart** or **Employment Information**) in the main menu.`;
        actions.push({ label: `Go to ${foundNav.name}`, route: foundNav.route, icon: 'arrow-right' });
        suggestions.push('Show active residents');
        suggestions.push('Help with progress notes');
      } else if (lower.includes('contact') || lower.includes('email') || lower.includes('support') || lower.includes('carenote') || lower.includes('company')) {
        steps.push('Providing CareNote official contact and organization information...');
        reply = `### 🏥 About **CareNote**\n\n` +
          `**CareNote** is your independent, compliant healthcare and EHR documentation platform.\n\n` +
          `* **Company:** CareNote Healthcare System\n` +
          `* **Official Communication Email:** \`swaraysheku12@gmail.com\`\n` +
          `* **Clinical Director & Administrator:** Sheku Swaray\n` +
          `* **Technical Support:** Available 24/7 for clinical charting, MARS, and scheduling.\n\n` +
          `You can reach out anytime to **swaraysheku12@gmail.com** for administrative assistance, provider onboarding, or billing inquiries.`;
        actions.push({ label: 'Open Home', route: '/Home', icon: 'home' });
        actions.push({ label: 'View Resident List', route: '/patient-list', icon: 'users' });
        suggestions.push('Show active residents');
        suggestions.push('Check recent vitals');
      } else if (lower.includes('help') || lower.includes('hello') || lower.includes('hi') || lower.includes('care') || lower.length === 0) {
        steps.push('Presenting Care AI Agent capabilities overview...');
        reply = `### 👋 Hello! I am **Care**, your intelligent AI Assistant.\n\n` +
          `I am directly integrated with your EHR database and clinical workflow to assist you with:\n\n` +
          `* 🩺 **Clinical Vitals:** Check or evaluate Blood Pressure, Glucose, SpO2, and vitals logs.\n` +
          `* 💊 **Medications & MAR:** Look up prescriptions, dosages, administration times, and allergies.\n` +
          `* 📝 **Progress & SOAP Notes:** Generate structured clinical documentation and shift notes.\n` +
          `* 👥 **Resident Records:** Look up active residents, rooms, diagnoses, and admission face sheets.\n` +
          `* 🧭 **Deep Navigation:** One-click shortcuts to any module in the system (Mileage, Training, PTO, Schedules).\n\n` +
          `How can I assist you with your documentation or care tasks today?`;
        actions.push({ label: 'View Residents', route: '/patient-list', icon: 'users' });
        actions.push({ label: 'Resident Vitals', route: '/vitals', icon: 'heart-pulse' });
        actions.push({ label: 'Draft Progress Note', action: 'ask', text: 'Draft a SOAP note for Sarah Connor', icon: 'edit' });
        actions.push({ label: 'Time Off Request', route: '/get-time-of-request', icon: 'calendar' });
        suggestions.push('Show admitted residents');
        suggestions.push('Draft a clinical SOAP note');
        suggestions.push('Show today\'s vitals');
        suggestions.push('Help with BHT schedule');
      } else {
        steps.push('Performing semantic clinical knowledge lookup...');
        reply = `I understand you are asking about: *"**${text}**"*\n\n` +
          `Here is how I can help with this:\n\n` +
          `1. **Clinical Documentation:** You can record or generate notes under **Resident Chart > Therapy Progress Notes** or Shift Notes.\n` +
          `2. **Resident Care:** Access vitals, medication logs, tracking, and re-assessments directly in the **Resident Chart** sidebar menu.\n` +
          `3. **Staff Records:** Manage your schedule, PTO, orientation, and trainings under **Employment Information**.\n\n` +
          `Would you like me to navigate you to a specific screen or look up resident data?`;
        actions.push({ label: 'Go to Home', route: '/Home', icon: 'home' });
        actions.push({ label: 'Open Resident Chart', route: '/employee/patient-chart', icon: 'folder' });
        suggestions.push('Show resident census');
        suggestions.push('Draft a progress note');
      }
    }

    steps.push('Care Agent response formulated with interactive action pills.');

    return {
      success: true,
      query: text,
      reply,
      steps,
      actions,
      suggestions: suggestions.slice(0, 4),
      timestamp: new Date().toISOString()
    };
  }
}
