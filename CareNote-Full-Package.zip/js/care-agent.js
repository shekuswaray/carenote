/**
 * =========================================================================
 * CARE CHATBOT - CLEAN STANDARD CHAT WIDGET
 * =========================================================================
 */

(function () {
  'use strict';

  if (window.__CARE_AGENT_INITIALIZED__) return;
  window.__CARE_AGENT_INITIALIZED__ = true;

  const STORAGE_KEY = 'care_chat_v4';

  const DEFAULT_MESSAGES = [
    {
      role: 'assistant',
      text: `Hello! I'm **Care**, your assistant.\n\nHow can I help you today? You can ask me to check resident vitals, find active residents, draft progress notes, or navigate to any page.`,
      actions: [
        { label: '👥 Residents List', action: 'ask', text: 'Who are the admitted residents?' },
        { label: '🩺 Check Vitals', action: 'ask', text: 'Show recent vitals' },
        { label: '📝 Draft Progress Note', action: 'ask', text: 'Draft a SOAP progress note for Sarah Connor' }
      ]
    }
  ];

  let messages = loadMessages();

  function loadMessages() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {}
    return [...DEFAULT_MESSAGES];
  }

  function saveMessages() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(messages.slice(-25)));
    } catch (e) {}
  }

  function parseMarkdown(md) {
    if (!md) return '';
    let html = md;

    // Code blocks
    html = html.replace(/```([a-z0-9]*)\n([\s\S]*?)```/g, (match, lang, code) => {
      return `<pre><code>${escapeHtml(code.trim())}</code></pre>`;
    });

    // Inline code
    html = html.replace(/`([^`]+)`/g, (match, code) => {
      return `<code>${escapeHtml(code)}</code>`;
    });

    // Headers
    html = html.replace(/^### (.*$)/gim, '<h3>$1</h3>');
    html = html.replace(/^## (.*$)/gim, '<h3>$1</h3>');
    html = html.replace(/^# (.*$)/gim, '<h3>$1</h3>');

    // Bold & italic
    html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/\*(.*?)\*/g, '<em>$1</em>');

    // Bullet lists
    html = html.replace(/^\* (.*$)/gim, '<li>$1</li>');
    html = html.replace(/^- (.*$)/gim, '<li>$1</li>');
    html = html.replace(/(<li>[\s\S]*?<\/li>)/g, '<ul>$1</ul>');
    html = html.replace(/<\/ul>\s*<ul>/g, '');

    // Paragraphs & breaks
    html = html.replace(/\n{2,}/g, '</p><p>');
    html = html.replace(/\n/g, '<br/>');

    return `<p>${html}</p>`;
  }

  function escapeHtml(str) {
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function initUI() {
    // 1. Floating Round Launcher
    const launcher = document.createElement('button');
    launcher.id = 'care-agent-launcher';
    launcher.setAttribute('aria-label', 'Open chat');
    launcher.innerHTML = `
      <svg viewBox="0 0 24 24">
        <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H6l-2 2V4h16v12z"/>
      </svg>
      <div class="care-launcher-badge"></div>
    `;
    document.body.appendChild(launcher);

    // 2. Chat Window
    const win = document.createElement('div');
    win.id = 'care-chat-window';
    win.className = 'minimized';
    win.innerHTML = `
      <!-- Header -->
      <div class="care-header">
        <div class="care-header-user">
          <div class="care-header-avatar">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M12 2v20M2 12h20"></path>
              <circle cx="12" cy="12" r="9"></circle>
            </svg>
            <div class="care-header-dot"></div>
          </div>
          <div class="care-header-info">
            <h4>Care</h4>
            <p>Online</p>
          </div>
        </div>
        <button class="care-header-close" id="care-close-btn" title="Close chat">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
      </div>

      <!-- Messages -->
      <div class="care-messages" id="care-messages"></div>

      <!-- Quick suggestions -->
      <div class="care-quick-bar" id="care-quick-bar">
        <button class="care-quick-btn" data-ask="Who are the admitted residents?">👥 Residents</button>
        <button class="care-quick-btn" data-ask="Show vitals for Sarah Connor">🩺 Sarah's Vitals</button>
        <button class="care-quick-btn" data-ask="Draft a SOAP progress note for Sarah Connor">📝 Draft Note</button>
        <button class="care-quick-btn" data-ask="Where is the mileage log?">🚗 Mileage Log</button>
      </div>

      <!-- Input -->
      <form class="care-input-form" id="care-form">
        <input type="text" class="care-input" id="care-input" placeholder="Type a message..." autocomplete="off" />
        <button type="submit" class="care-send-btn" id="care-send" title="Send">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <line x1="22" y1="2" x2="11" y2="13"></line>
            <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
          </svg>
        </button>
      </form>
    `;
    document.body.appendChild(win);

    // Event listeners
    launcher.addEventListener('click', toggleChat);
    document.getElementById('care-close-btn').addEventListener('click', toggleChat);

    const form = document.getElementById('care-form');
    const input = document.getElementById('care-input');

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const text = (input.value || '').trim();
      if (!text) return;
      input.value = '';
      sendMessage(text);
    });

    document.getElementById('care-quick-bar').addEventListener('click', (e) => {
      const btn = e.target.closest('.care-quick-btn');
      if (btn && btn.dataset.ask) {
        sendMessage(btn.dataset.ask);
      }
    });

    renderMessages();
  }

  function toggleChat() {
    const win = document.getElementById('care-chat-window');
    const launcher = document.getElementById('care-agent-launcher');
    win.classList.toggle('minimized');
    if (!win.classList.contains('minimized')) {
      launcher.style.display = 'none';
      setTimeout(() => {
        document.getElementById('care-input').focus();
        scrollToBottom();
      }, 100);
    } else {
      launcher.style.display = 'flex';
    }
  }

  function scrollToBottom() {
    const container = document.getElementById('care-messages');
    if (container) {
      container.scrollTop = container.scrollHeight;
    }
  }

  function renderMessages() {
    const container = document.getElementById('care-messages');
    if (!container) return;

    container.innerHTML = '';
    messages.forEach((msg) => {
      const row = document.createElement('div');
      row.className = `care-msg ${msg.role}`;

      let actionsHtml = '';
      if (msg.actions && msg.actions.length > 0) {
        actionsHtml = `
          <div class="care-actions">
            ${msg.actions.map(act => {
              if (act.action === 'copy') {
                return `<button class="care-action-btn copy" data-copy="${encodeURIComponent(act.text || '')}">📋 ${escapeHtml(act.label)}</button>`;
              } else if (act.action === 'ask') {
                return `<button class="care-action-btn" data-ask="${encodeURIComponent(act.text || '')}">💬 ${escapeHtml(act.label)}</button>`;
              } else if (act.route) {
                return `<a href="${act.route}" class="care-action-btn">🔗 ${escapeHtml(act.label)}</a>`;
              }
              return '';
            }).join('')}
          </div>
        `;
      }

      row.innerHTML = `
        <div class="care-bubble">
          ${parseMarkdown(msg.text || '')}
          ${actionsHtml}
        </div>
      `;
      container.appendChild(row);
    });

    // Attach click handlers
    container.querySelectorAll('[data-copy]').forEach(btn => {
      btn.onclick = (e) => {
        e.preventDefault();
        const text = decodeURIComponent(btn.getAttribute('data-copy'));
        navigator.clipboard.writeText(text);
        btn.textContent = '✓ Copied';
        setTimeout(() => { btn.textContent = '📋 Copy'; }, 2000);
      };
    });

    container.querySelectorAll('[data-ask]').forEach(btn => {
      btn.onclick = (e) => {
        e.preventDefault();
        const text = decodeURIComponent(btn.getAttribute('data-ask'));
        sendMessage(text);
      };
    });

    scrollToBottom();
  }

  async function sendMessage(text) {
    messages.push({ role: 'user', text });
    renderMessages();
    saveMessages();

    // Typing indicator
    const container = document.getElementById('care-messages');
    const typing = document.createElement('div');
    typing.className = 'care-msg assistant';
    typing.id = 'care-typing';
    typing.innerHTML = `
      <div class="care-bubble" style="padding: 8px 12px;">
        <div class="care-typing">
          <div class="care-dot"></div>
          <div class="care-dot"></div>
          <div class="care-dot"></div>
        </div>
      </div>
    `;
    container.appendChild(typing);
    scrollToBottom();

    try {
      const res = await fetch('/api/v1/care/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text })
      });
      const data = await res.json();
      const t = document.getElementById('care-typing');
      if (t) t.remove();

      if (data && data.success) {
        messages.push({
          role: 'assistant',
          text: data.reply,
          actions: data.actions || []
        });
      } else {
        messages.push({
          role: 'assistant',
          text: 'Sorry, I had trouble answering that. Can I help you find something else?'
        });
      }
    } catch (e) {
      const t = document.getElementById('care-typing');
      if (t) t.remove();
      messages.push({
        role: 'assistant',
        text: 'Sorry, I could not connect. Please try again in a moment.'
      });
    }

    renderMessages();
    saveMessages();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initUI);
  } else {
    initUI();
  }

})();
